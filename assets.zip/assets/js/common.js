var auto_refresh = setInterval(
        function ()
        {
            $("#refresh-notification").load(location.href + " #refresh-notification");
            var nid = $('#nitufyid').val(); //alert(nid);
            if (nid != "" && nid != undefined) {
                notifyMe()
                $('#nitufyid').val("")
            }

        }, 10000); // refresh every 10000 milliseconds
$(document).ready(function () {

});
function notifyMe() {
    // Let's check if the browser supports notifications
    if (!("Notification" in window)) {
        alert("This browser does not support desktop notification");
    }

    // Let's check if the user is okay to get some notification
    else if (Notification.permission === "granted") {
        // If it's okay let's create a notification
        var options = {
            body: "Researcher given your question answer, please check your Sokrates.",
            icon: "",
            dir: "ltr"
        };
        var notification = new Notification("Sokrates", options);
    }

    // Otherwise, we need to ask the user for permission
    // Note, Chrome does not implement the permission static property
    // So we have to check for NOT 'denied' instead of 'default'
    else if (Notification.permission !== 'denied') {
        Notification.requestPermission(function (permission) {
            // Whatever the user answers, we make sure we store the information
            if (!('permission' in Notification)) {
                Notification.permission = permission;
            }

            // If the user is okay, let's create a notification
            if (permission === "granted") {
                var options = {
                    body: "This is the body of the notification",
                    icon: "",
                            dir: "ltr"
                };
                var notification = new Notification("Hi there", options);
            }
        });
    }

    // At last, if the user already denied any notification, and you
    // want to be respectful there is no need to bother them any more.
}
function openNav(val) {
    if (val == 'My_Questions') {

        $.ajax({
            url: '<?php echo site_url("ask_questions/get_my_question/"); ?>',
            type: "POST",
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            {
                $("#data-div").html(data);
            }
        });
    }
    document.getElementById("mySidenav").style.width = "85%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function serQuestion(val) {
    var formData = new FormData();
    formData.append('ser', val);
    $.ajax({
        url: '<?php echo site_url("ask_questions/serQuestion/"); ?>',
        type: "POST",
        data: formData,
        contentType: false,
        cache: false,
        processData: false,
        success: function (data1)
        {
            $("#iMyQList").html(data1);
        }
    });
}