
var st_val = $('#iStopwatchValue').val();

var st_colums = st_val.split(":");
//alert(st_colums[0]); 

//alert(st_colums[1].charAt(0)); 
if (st_colums[2] == '00') {
    sec = 0;
} else {
    sec = st_colums[2];
}
if (st_colums[1] == '00') {
    min = 0;
} else {
    min = st_colums[1];
    if (st_colums[1].charAt(0) == '0') {
        min = st_colums[1].slice(1);
    }
}
if (st_colums[0] == '00') {
    hrs = 0;
} else {
    hrs = st_colums[0];    
    if (st_colums[0].charAt(0) == '0') {
        hrs = st_colums[0].slice(1);        
    }
}

var spn = document.getElementsByTagName('spn')[0],
        //start = document.getElementById('start'),
        //stop = document.getElementById('stop'),
        //clear = document.getElementById('clear'),
        seconds = sec, minutes = min, hours = hrs,
        t;

function clearWatch() {
    spn.textContent = "00:00:00";

    seconds = 0;
    minutes = 0;
    hours = 0;
}
function add() {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }

    spn.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);

    timer();
}
function timer() {
    t = setTimeout(add, 1000);
}

//timer();
if (st_val != '0:0:0') {
    timer();
}
/* Start button */
//start.onclick = timer;

/* Stop button */
//stop.onclick = function () {
//    clearTimeout(t);
//}

$('#timerButtonsstop').click(function () {
    $('#timerButtonsstop').hide();
    $('#timerButtonsstart').show();
    //ss();
    clearTimeout(t);
});
$('#timerButtonsstart').click(function () {
    $('#timerButtonsstart').hide();
    $('#timerButtonsstop').show();
    //ss();
    timer();
});



/* Clear button */
//clear.onclick = function() {
//    spn.textContent = "00:00:00";
//    seconds = 0; minutes = 0; hours = 0;
//}
