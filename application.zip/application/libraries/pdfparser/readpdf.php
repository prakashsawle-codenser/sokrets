<?php
error_reporting(0);
include 'vendor/autoload.php';
 
// Parse pdf file and build necessary objects.
$parser = new \Smalot\PdfParser\Parser();
$pdf    = $parser->parseFile('http://localhost/sokrets/uploads/files/Sokrates_development_-_RESEARCHER_feedback_v.3.pdf');
 
$text = $pdf->getText();
echo $text;


 ?>