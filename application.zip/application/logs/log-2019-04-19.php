<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-19 11:17:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 13:43:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 13:46:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 13:48:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 14:22:36 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/sokrets/application/controllers/Login_c.php 158
ERROR - 2019-04-19 14:23:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 14:24:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 14:25:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 14:25:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/sokrets/application/controllers/Login_c.php 158
ERROR - 2019-04-19 14:34:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 14:34:41 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/sokrets/application/controllers/Login_c.php 158
ERROR - 2019-04-19 14:35:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array /var/www/html/sokrets/application/controllers/Login_c.php 159
ERROR - 2019-04-19 15:01:59 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sokrets/application/controllers/Ask_questions.php 1039
ERROR - 2019-04-19 15:10:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-19 15:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-19 15:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-19 15:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 15:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-19 18:50:21 --> Severity: error --> Exception: syntax error, unexpected '$ch' (T_VARIABLE) /var/www/html/sokrets/application/controllers/Ask_questions.php 1185
ERROR - 2019-04-19 18:50:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-19 18:50:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-19 18:50:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-19 18:50:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-19 18:50:47 --> Severity: error --> Exception: Too few arguments to function Ask_questions::getUrltoPdf(), 0 passed in /var/www/html/sokrets/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/sokrets/application/controllers/Ask_questions.php 1182
