<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 11:18:21 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-08 11:21:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 11:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:21:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:21:59 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 11:21:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:22:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:22:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:22:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:23:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:28:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 11:58:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 11:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:58:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 11:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:00:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 12:49:14 --> Severity: error --> Exception: Too few arguments to function Login_c::answerFromApi(), 0 passed in /var/www/html/sokrets/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/sokrets/application/controllers/Login_c.php 132
ERROR - 2019-04-08 13:29:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 13:29:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:29:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 13:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 13:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 13:33:50 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 14:32:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:32:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:03 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:05 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:12 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:19 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:20 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:22 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:25 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:28 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:30 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:33:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:03 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:05 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:12 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:19 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:20 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:22 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:25 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:28 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:30 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:34:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:03 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:05 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:12 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:19 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:20 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:22 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:25 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:28 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:30 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:35:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:03 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:05 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:12 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:19 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:20 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:22 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:25 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:28 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:30 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:58 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:36:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:02 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:03 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:04 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:05 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:07 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:08 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:12 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:19 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:20 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:21 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:22 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:23 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 599
ERROR - 2019-04-08 14:37:24 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:25 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:28 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:29 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:30 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:31 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:32 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:37 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:39 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:47 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:50 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:51 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:52 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:53 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:54 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:55 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:56 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:37:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /var/www/html/sokrets/application/controllers/Ask_questions.php 602
ERROR - 2019-04-08 14:38:58 --> Severity: Notice --> Undefined variable: argv /var/www/html/sokrets/application/controllers/Login_c.php 133
ERROR - 2019-04-08 14:38:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND questions.answer_source='A' AND tbl_researcher_current_questions.isCompleted' at line 1 - Invalid query: SELECT * FROM questions INNER JOIN tbl_researcher_current_questions ON questions.id=tbl_researcher_current_questions.questionID WHERE questions.userID= AND questions.answer_source='A' AND tbl_researcher_current_questions.isCompleted=0
ERROR - 2019-04-08 14:53:18 --> Not Found: Login_c/answerFromApi2
ERROR - 2019-04-08 14:53:42 --> Severity: Notice --> Undefined variable: argv /var/www/html/sokrets/application/controllers/Login_c.php 133
ERROR - 2019-04-08 14:54:08 --> Severity: Notice --> Undefined variable: argv /var/www/html/sokrets/application/controllers/Login_c.php 133
ERROR - 2019-04-08 14:55:28 --> Severity: Notice --> Undefined variable: argv /var/www/html/sokrets/application/controllers/Login_c.php 133
ERROR - 2019-04-08 15:00:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 15:06:22 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 15:06:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 15:06:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 15:06:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 15:15:42 --> Severity: error --> Exception: Too few arguments to function Login_c::answerFromApi(), 0 passed in /var/www/html/sokrets/system/core/CodeIgniter.php on line 532 and exactly 1 expected /var/www/html/sokrets/application/controllers/Login_c.php 132
ERROR - 2019-04-08 17:18:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:19:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:28:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 17:39:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-08 17:39:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '==NULL ORDER BY a.id DESC' at line 1 - Invalid query: SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '12' AND a.isDeleted = 0 AND a.followUpQuestionsID==NULL ORDER BY a.id DESC 
ERROR - 2019-04-08 17:39:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:39:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:15 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 17:40:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 17:40:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 17:40:16 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 17:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:21 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 17:40:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:41:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:41:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:42:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:43:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:43:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:44:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    a.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:54:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    a.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:54:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    a.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:54:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:54:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    a.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:54:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    b.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:55:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'a.questionID = b.id' at line 23 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = 12 AND 
                                    b.followUpQuestionsID=NULL
                                    a.questionID = b.id 
                                                                
                                
                                
ERROR - 2019-04-08 17:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:55:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:56:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:57:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 17:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:58:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 17:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:00:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:03:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:04:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:05:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:06:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:07:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:07:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:08:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:30 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-08 18:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 18:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 18:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-08 18:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:34 --> Severity: Notice --> Undefined variable: exe_follup /var/www/html/sokrets/application/views/my_answer_v.php 118
ERROR - 2019-04-08 18:09:34 --> Severity: error --> Exception: Call to a member function first_row() on null /var/www/html/sokrets/application/views/my_answer_v.php 118
ERROR - 2019-04-08 18:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:09:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:10:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:35 --> Severity: Notice --> Undefined variable: exe_follup /var/www/html/sokrets/application/views/my_answer_v.php 117
ERROR - 2019-04-08 18:11:35 --> Severity: error --> Exception: Call to a member function first_row() on null /var/www/html/sokrets/application/views/my_answer_v.php 117
ERROR - 2019-04-08 18:11:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:36 --> Severity: Notice --> Undefined variable: exe_follup /var/www/html/sokrets/application/views/my_answer_v.php 117
ERROR - 2019-04-08 18:11:36 --> Severity: error --> Exception: Call to a member function first_row() on null /var/www/html/sokrets/application/views/my_answer_v.php 117
ERROR - 2019-04-08 18:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:11:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:12:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:13:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:17:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:55 --> Severity: error --> Exception: Call to a member function first_row() on null /var/www/html/sokrets/application/views/my_answer_v.php 122
ERROR - 2019-04-08 18:21:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:22:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:49 --> Severity: Notice --> Undefined variable: exe_follup /var/www/html/sokrets/application/views/my_answer_v.php 76
ERROR - 2019-04-08 18:22:49 --> Severity: error --> Exception: Call to a member function first_row() on null /var/www/html/sokrets/application/views/my_answer_v.php 76
ERROR - 2019-04-08 18:22:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:22:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:23:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:25:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:27:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:29:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:29:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:30:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:31:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:33:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:34:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:36:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:36:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:36:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INNER JOIN 
                                    questions b  ON a.questionID = b' at line 15 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a,  INNER JOIN 
                                    questions b  ON a.questionID = b.id
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    b.followUpQuestionsID=9
ERROR - 2019-04-08 18:38:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INNER JOIN 
                                    questions b  ON a.questionID = b' at line 15 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a,  INNER JOIN 
                                    questions b  ON a.questionID = b.id
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    b.followUpQuestionsID=9
ERROR - 2019-04-08 18:38:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INNER JOIN 
                                    questions b  ON a.questionID = b' at line 15 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a,  INNER JOIN 
                                    questions b  ON a.questionID = b.id
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    b.followUpQuestionsID=9
ERROR - 2019-04-08 18:38:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:38:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:38:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:38:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:39:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INNER JOIN 
                                    questions b  ON a.questionID = b' at line 15 - Invalid query: SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept  
                                FROM 
                                    answer a,  INNER JOIN 
                                    questions b  ON a.questionID = b.id
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    b.followUpQuestionsID=9
ERROR - 2019-04-08 18:39:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:39:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-08 18:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-08 18:41:00 --> 404 Page Not Found: Assets/css
