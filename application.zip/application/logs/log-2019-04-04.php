<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-04 11:34:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 11:34:56 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-04 11:36:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 11:47:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-04 11:47:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-04 11:47:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-04-04 11:48:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 11:56:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 14:39:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 14:39:16 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 12 AND messageBy != 12 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-04 14:54:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 14:54:00 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 12 AND messageBy != 12 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-04 14:54:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-04 15:01:34 --> 404 Page Not Found: GetUrltoPdf/index
ERROR - 2019-04-04 15:14:36 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1113
ERROR - 2019-04-04 15:14:43 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1113
ERROR - 2019-04-04 15:14:46 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1113
ERROR - 2019-04-04 15:18:32 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1128
ERROR - 2019-04-04 15:19:21 --> Severity: Notice --> Undefined variable: query /var/www/html/sokrets/application/controllers/Ask_questions.php 1119
ERROR - 2019-04-04 15:19:22 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:19:34 --> Severity: Warning --> curl_setopt() expects exactly 3 parameters, 2 given /var/www/html/sokrets/application/controllers/Ask_questions.php 1119
ERROR - 2019-04-04 15:19:35 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:19:57 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1131
ERROR - 2019-04-04 15:20:09 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:22:12 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:22:13 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:22:16 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1130
ERROR - 2019-04-04 15:23:29 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1133
ERROR - 2019-04-04 15:23:31 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1133
ERROR - 2019-04-04 15:24:27 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 15:24:42 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 15:24:44 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 15:24:46 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 15:25:51 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 15:25:53 --> Severity: Warning --> file_get_contents(http://104.40.153.156:8001/getthumbnail/http://cmldemo.com/new_sokrets/uploads/files/env.pdf): failed to open stream: HTTP request failed! HTTP/1.1 500 INTERNAL SERVER ERROR
 /var/www/html/sokrets/application/controllers/Ask_questions.php 1134
ERROR - 2019-04-04 18:54:44 --> 404 Page Not Found: GetUrltoPdf/index
ERROR - 2019-04-04 18:54:49 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-04 18:55:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sokrets/application/controllers/Ask_questions.php 902
ERROR - 2019-04-04 18:55:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sokrets/application/controllers/Ask_questions.php 908
ERROR - 2019-04-04 18:55:06 --> Query error: Column 'answer' cannot be null - Invalid query: INSERT INTO `answer` (`questionID`, `questionBy`, `answerBy`, `answer`, `progress_status`, `sourceURL`, `replyType`) VALUES ('3', '2', 0, NULL, 4, 'https://presidentofindia.nic.in/', 'Answer')
ERROR - 2019-04-04 18:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:55:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:56:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:56:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:56:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-04-04 18:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:57:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:58:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-04-04 18:59:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sokrets/application/controllers/Ask_questions.php 902
ERROR - 2019-04-04 18:59:19 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sokrets/application/controllers/Ask_questions.php 908
ERROR - 2019-04-04 18:59:19 --> Query error: Column 'answer' cannot be null - Invalid query: INSERT INTO `answer` (`questionID`, `questionBy`, `answerBy`, `answer`, `progress_status`, `sourceURL`, `replyType`) VALUES ('2', '2', 0, NULL, 4, 'https://en.wikipedia.org/wiki/Prime_Minister_of_India', 'Answer')
