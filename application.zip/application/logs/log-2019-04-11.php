<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-11 15:28:50 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-11 15:29:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-11 15:33:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-11 18:35:37 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-11 19:11:15 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 234
ERROR - 2019-04-11 19:37:54 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 233
ERROR - 2019-04-11 19:57:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sokrets/application/controllers/Ask_questions.php 1015
ERROR - 2019-04-11 19:57:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sokrets/application/controllers/Ask_questions.php 1015
