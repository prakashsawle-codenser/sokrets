<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-29 14:19:19 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-03-29 14:20:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-29 14:23:57 --> 404 Page Not Found: AnswerFromApi/index
ERROR - 2019-03-29 14:24:06 --> Severity: error --> Exception: Too few arguments to function Ask_question_m::getQuestionforApi(), 0 passed in /var/www/html/sokrets/application/controllers/Ask_questions.php on line 799 and exactly 1 expected /var/www/html/sokrets/application/models/Ask_question_m.php 523
