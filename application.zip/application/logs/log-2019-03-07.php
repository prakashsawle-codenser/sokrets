<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 08:06:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'content like '% wanted %' OR content like '% criminal %' OR content like '% indi' at line 1 - Invalid query: SELECT * FROM `library_documents` WHERE uid=2AND content like '% wanted %' OR content like '% criminal %' OR content like '% india %' 
ERROR - 2019-03-07 08:10:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-03-07 08:10:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-03-07 08:10:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2019-03-07 08:10:29 --> Severity: error --> Exception: Class 'Imagick' not found C:\xampp\htdocs\sokrets\application\controllers\My_files.php 153
ERROR - 2019-03-07 08:24:35 --> Query error: Unknown column 'bookshelf' in 'where clause' - Invalid query: SELECT * FROM question_search_result WHERE qid =127&type=bookshelf
ERROR - 2019-03-07 08:24:53 --> Query error: Unknown column 'bookshelf' in 'where clause' - Invalid query: SELECT * FROM question_search_result WHERE qid =127 AND type=bookshelf
ERROR - 2019-03-07 08:32:28 --> Severity: error --> Exception: Too few arguments to function Researcher_m::library_search(), 1 passed in C:\xampp\htdocs\sokrets\application\controllers\Researcher.php on line 226 and exactly 2 expected C:\xampp\htdocs\sokrets\application\models\Researcher_m.php 175
ERROR - 2019-03-07 08:32:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 08:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 838
ERROR - 2019-03-07 08:55:04 --> Query error: Column 'content' cannot be null - Invalid query: INSERT INTO `question_search_result` (`count`, `content`, `qid`, `type`, `status`, `created_at`, `update_at`) VALUES (2, NULL, '127', 'internet', 'pending', '2019-03-07 08:55:04', '2019-03-07 08:55:04')
ERROR - 2019-03-07 13:01:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:02:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:03:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 13:04:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:04:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 13:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:12:27 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 807
ERROR - 2019-03-07 14:12:28 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 859
ERROR - 2019-03-07 14:19:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:19:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:29 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 807
ERROR - 2019-03-07 14:19:31 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 859
ERROR - 2019-03-07 14:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:29:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:30:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:31:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:33:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:34:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:36:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:37:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:38:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:38:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:39:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:40:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:41:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:41:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:42:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:42:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:43:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:43:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:44:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:44:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:45:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:45:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:46:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:46:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:46:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:46:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:47:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:48:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 14:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:49:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:25 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:26 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:27 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:28 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:29 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:30 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:31 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:32 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:33 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:34 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:35 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:36 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:37 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:38 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:39 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:40 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:41 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:42 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:43 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:44 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:45 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:46 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:47 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:48 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:49 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:50 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:51 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:52 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:53 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:54 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:55 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:56 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:57 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:58 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:52:59 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:00 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:01 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:02 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:03 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:04 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:05 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:06 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:07 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:08 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:09 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:10 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:11 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:12 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:13 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:14 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:15 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:16 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:17 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:18 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:19 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:20 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:21 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:22 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:23 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 14:53:24 --> Severity: Notice --> Use of undefined constant condition - assumed 'condition' C:\xampp\htdocs\sokrets\application\views\question_answer_v.php 88
ERROR - 2019-03-07 15:43:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:44:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:45:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:45:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:46:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:47:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:48:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 15:48:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:49:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:50:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:51:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:52:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:53:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:54:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:55:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:57:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:58:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 15:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:00:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:03:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:04:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:05:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:06:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:07:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:08:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:09:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:10:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:11:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:12:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:13:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:17:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:22:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 16:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 16:27:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 16:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:27:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:20 --> Query error: Unknown column 'questionID' in 'where clause' - Invalid query: UPDATE `questions` SET `isCompleted` = 'progress-36'
WHERE `questionID` = '133'
ERROR - 2019-03-07 16:28:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-07 16:29:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:32 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 859
ERROR - 2019-03-07 16:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-07 16:33:01 --> Severity: Notice --> Undefined variable: cur_q_id C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 859
