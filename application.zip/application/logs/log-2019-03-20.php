<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-20 10:42:48 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-03-20 10:42:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 10:42:59 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-03-20 10:44:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 10:44:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:41:21 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1057
ERROR - 2019-03-20 11:42:13 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1057
ERROR - 2019-03-20 11:42:42 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1057
ERROR - 2019-03-20 11:43:11 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1057
ERROR - 2019-03-20 11:50:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:50:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:50:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:52:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:53:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:55:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:56:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 11:57:40 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 11:58:20 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 11:58:46 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 11:59:03 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:00:07 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:00:35 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:11:52 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:12:44 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:13:11 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:13:34 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:14:28 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:15:09 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:15:35 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:15:53 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:16:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:18:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:20:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:21:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:22:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:23:06 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:23:34 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:25:53 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:26:46 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:27:12 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:27:35 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:28:28 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1056
ERROR - 2019-03-20 12:29:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:35:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:44:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:45:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:45:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:45:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:45:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 12:53:45 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:54:17 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:54:43 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:55:14 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:55:36 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:55:57 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:56:16 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:56:35 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:56:54 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:57:39 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1058
ERROR - 2019-03-20 12:58:10 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1059
ERROR - 2019-03-20 12:59:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 13:03:23 --> Severity: Notice --> Undefined variable: ouput /var/www/html/sokrets/application/controllers/Ask_questions.php 1061
ERROR - 2019-03-20 14:52:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:23:29 --> 404 Page Not Found: Ask_questions/e
ERROR - 2019-03-20 16:40:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:40:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:40:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:40:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:43:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:43:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:46:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:46:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:47:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:47:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:48:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:48:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:50:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:51:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:51:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 16:58:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 17:08:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-20 17:10:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-20 17:10:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-20 17:15:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-03-20 17:21:09 --> Severity: Notice --> Undefined property: Login_c::$ask_question_m /var/www/html/sokrets/application/controllers/Login_c.php 131
ERROR - 2019-03-20 17:21:09 --> Severity: error --> Exception: Call to a member function getQuestionforApi() on null /var/www/html/sokrets/application/controllers/Login_c.php 131
ERROR - 2019-03-20 17:47:22 --> 404 Page Not Found: UpdateAnswerApi/2
ERROR - 2019-03-20 18:08:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND content like '% tennis %' OR content like '% ball %' OR content like '% cric' at line 1 - Invalid query: SELECT * FROM `tbl_files` WHERE user_id= AND content like '% tennis %' OR content like '% ball %' OR content like '% cricket %' 
