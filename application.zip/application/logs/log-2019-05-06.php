<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-06 16:18:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-05-06 16:18:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-05-06 16:19:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-05-06 16:20:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-05-06 16:20:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-05-06 16:20:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
