ERROR - 2019-03-05 13:29:08 --> http://localhost/sokrets/subscription/sample/
ERROR - 2019-03-05 13:29:09 --> http://localhost/sokrets/subscription/sample/
ERROR - 2019-03-05 13:29:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\sokrets\application\libraries\jobs.php 627
ERROR - 2019-03-05 13:29:48 --> You in addnew_questiontag function
ERROR - 2019-03-05 13:31:17 --> http://localhost/sokrets/subscription/sample/
ERROR - 2019-03-05 13:31:17 --> http://localhost/sokrets/subscription/sample/
ERROR - 2019-03-05 13:31:47 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\sokrets\application\libraries\jobs.php 627
ERROR - 2019-03-05 13:40:50 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:51 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:52 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:53 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:54 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:55 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:57 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:58 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:40:59 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:00 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:01 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:02 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:03 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:04 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:05 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:06 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:07 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:08 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:09 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:10 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:11 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:12 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:13 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:14 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:15 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:16 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:17 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:18 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:19 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:20 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:21 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:22 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:23 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:24 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:25 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:26 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:27 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:28 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:29 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:30 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:31 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:32 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:33 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:34 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:35 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:36 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:37 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:38 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:39 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:41:40 --> Severity: error --> Exception: syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\sokrets\application\controllers\Ask_questions.php 105
ERROR - 2019-03-05 13:50:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-05 13:50:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-05 13:50:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:50:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:19 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:36 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:41 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:51:59 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:03 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:05 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:08 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:15 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2019-03-05 13:52:18 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:29 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-03-05 13:52:33 --> 404 Page Not Found: Assets/css
