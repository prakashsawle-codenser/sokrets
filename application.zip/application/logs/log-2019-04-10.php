<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-10 18:31:04 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-10 18:31:50 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-10 18:31:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-10 18:32:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20160303/php_intl.dll' - /usr/lib/php/20160303/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-10 18:35:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:35:42 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:35:51 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:35:59 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:36:11 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:36:20 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:36:32 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:36:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:36:50 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:37:01 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:42:42 --> Severity: Notice --> Undefined variable: user_id /var/www/html/sokrets/application/controllers/Login_c.php 137
ERROR - 2019-04-10 18:42:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND questions.answer_source='A' AND tbl_researcher_current_questions.isCompleted' at line 1 - Invalid query: SELECT * FROM questions INNER JOIN tbl_researcher_current_questions ON questions.id=tbl_researcher_current_questions.questionID WHERE questions.userID= AND questions.answer_source='A' AND tbl_researcher_current_questions.isCompleted=0
ERROR - 2019-04-10 18:46:23 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-10 18:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sokrets/application/controllers/Ask_questions.php 288
ERROR - 2019-04-10 18:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sokrets/application/controllers/Ask_questions.php 288
ERROR - 2019-04-10 18:48:29 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:48:37 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:48:46 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:48:56 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:06 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:15 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:25 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:33 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:42 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:49:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 228
ERROR - 2019-04-10 18:54:26 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
ERROR - 2019-04-10 18:54:49 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:55:14 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sokrets/application/controllers/Ask_questions.php 1016
ERROR - 2019-04-10 18:55:30 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:55:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:55:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:01 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:05 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:14 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:18 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:30 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:30 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:39 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:48 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:48 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:56:57 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:09 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:18 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:30 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:50 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:57:59 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:58:12 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:59:12 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
ERROR - 2019-04-10 18:59:22 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /var/www/html/sokrets/application/controllers/Login_c.php 226
