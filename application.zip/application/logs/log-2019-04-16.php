<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-16 15:31:00 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
