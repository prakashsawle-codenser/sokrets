<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-12 17:24:23 --> Severity: error --> Exception: syntax error, unexpected '$ansApiRes' (T_VARIABLE) /var/www/html/sokrets/application/controllers/Login_c.php 94
ERROR - 2019-04-12 17:24:57 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'sokrates_db.tbl_mycomments.id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = 2 AND messageBy != 2 AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa
ERROR - 2019-04-12 17:25:36 --> Severity: Warning --> file_get_contents(/home/they/pdfmaker_thumbnail/JjsLD9QkrYl.png): failed to open stream: No such file or directory /var/www/html/sokrets/application/views/my_library_v.php 204
