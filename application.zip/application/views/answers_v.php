<!--<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/nicEdit/nicEdit-latest.js"></script>
<style>
    form.example input[type=text] {
        padding: 2px;
        font-size: 13px;
        float: left;
        width: 70%;
        background: #fff;
    }
    form.example button {
        float: left;
        width: 15%;
        padding: 6px;
        background: #2196F3;
        color: white;
        font-size: 17px;
        border-left: none;
        cursor: pointer;
        border: none;
    }
    form.example button:hover {
        background: #0b7dda;
    }
    form.example::after {
        content: "";
        clear: both;
        display: table;
    }
    .answerCount{
        background: #5DB368;
        color: #fff;
        line-height: 35px;
        margin-bottom: 0;
        padding-left: 10px;
        padding-top: 9px;
        font-weight: bold;
        font-size: 24px;
    }
    .comment{
        margin-bottom: 10px !important;
        border: 1px solid #c0c0c061;
        padding: 5px 15px !important;
        border-radius: 5px;
    }
    .copyclip{
        float: right;
        font-size: 17px;
        background: #5DB368;
        padding: 5px;
        color: #fff;
        cursor: pointer;
    }
    .reply{
        float: right;
        font-size: 17px;
        background: #5DB368;
        padding: 5px;
        margin-right: 10px;
        color: #fff;
    }
    .hdn-border{
        border: none !important;
        background-color: #fff !important;
        border-bottom: 1px solid #ccc !important;
    }
    
</style>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('error')) : ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                        </div>  
                    <?php endif; ?>
            <?php if ($this->session->flashdata('success')) : ?>

                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="col-lg-12 text-right">
<!--                            <form class="example" action="<?php echo site_url('ask_questions/search_answer/' . $this->uri->segment(3)); ?>" method="post" style="float: right;max-width:300px;margin-top: 10px;">
                    <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>-->
            </div>
            <div class="article answer-artical">
                <h2 class="ans_q_title" ><?php echo @$question->questionTitle; ?> </h2>              
                <div class="clr"></div>
                <p>
                    Posted by <a href="#"><?php echo @$question->firstName; ?></a>                 
                </p>

                <?php if ($this->session->userdata('userType') == 2) { ?>
                    <div class="col-lg-12 noPadding pro-st-div">
                        <form action="<?php echo site_url('ask_questions/change_progress_status/'); ?>" method="post">                        
                            <input type="hidden" name="questionID" value="<?php echo @$this->uri->segment(3); ?>" />
                            <input type="hidden" name="questionBy" value="<?php echo @$question->userID; ?>" /> 
                            <input type="hidden" name="answerBy" value="<?php echo @$this->session->userdata('user_id'); ?>" /> 
                            <div class="col-lg-4 noPadding">
                                <div class="form-group">
                                    <label for="status">Progress Status</label>
                                    <select id="pst" class="form-control frm-l-s" name="progress_status">
                                        <option value="">Select Progress Status</option>
                                        <?php foreach ($pro_messages as $rowpm) { ?>
                                            <option value="<?php echo @$rowpm['id']; ?>"><?php echo @$rowpm['message']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <script>
    <?php if (@$p_status->progress_status != "") { ?>
                                            document.getElementById('pst').value = <?php echo @$p_status->progress_status; ?>;
    <?php } ?>
                                    </script>
                                </div>     
                            </div>
                            <div class="col-lg-8" style="margin-top: 24px;">
                                <button type="submit" class="btn btn-success">Update Status</button>
                            </div>
                        </form>
                    </div>
                <?php } ?>
            </div>

            <div class="article" style="padding: 8px 24px 0;">                
                <div class="clr"></div>
                <?php
                foreach ($answers as $row) {
                    $sourceURL = ($row['sourceURL'] != '') ? "\n" . @$row['sourceURL'] . " " : "";
                    //echo $sourceURL; exit;
                    ?>
                    <div class="comment answer-comment" >                         
                        <p style="border-bottom: 1px solid #efebeb;">

                            <a href="#"><?php echo @$row['firstName'] ?></a> Says: at
                            <?php echo date('j F, Y', strtotime($row['created'])); ?>
                            <!--<button style="margin-left: 25px;padding: 2px 7px;font-size: 12px;" onclick="CopyToClipboard('<?php echo @$row['id']; ?>')" class="btn btn-default">Copy Answer</button>-->
                            <a onclick="copyToClipboard('answer<?php echo @$row['id']; ?>')" data-toggle="tooltip" data-placement="top" title="Copy answer" class="copyclip" ><i class="fa fa-clipboard"></i></a>

                        </p>
                        <p style="padding: 0;margin: 4px 0;">
    <!--                            <a class="score-icon" href="" ><i class="fa fa-sort-up"></i></a>
                            <a class="score-icon" href="" ><i class="fa fa-sort-down"></i></a>-->
                            <a id="answer<?php echo @$row['id'] ?>" class="answer" href="<?php @$row['sourceURL']; ?>" target="_blank" ><?php echo @$row['answer']; ?></a>
                            <!--<input type="hidden" id="url<?php echo @$row['id'] ?>" value="<?php echo @$row['answer'] . $sourceURL; ?>" />-->
                        </p>                    
                    </div>                   
                <?php } ?>             
                <hr>
                <!--                <div class="col-lg-12">
                                    <div class="form-group">
                                        <button class="btn btn-success" id="iCommentbtn">Comment</button>
                                        <button class="btn btn-success" id="iAnswerbtn">Answer</button>
                                    </div>
                                </div>
                                <hr>-->

                <div id="iAnswer" class="row" style="margin-top: 20px;margin-bottom: 20px;">
                    <form action="<?php echo site_url('ask_questions/post_my_comment/' . $this->uri->segment(3)); ?>" method="post">
                        <input type="hidden" name="questionID" value="<?php echo @$this->uri->segment(3); ?>" /> 
                        <input type="hidden" name="questionBy" value="<?php echo @$question->userID; ?>" /> 
                        <input type="hidden" name="answerBy" value="<?php echo @$this->session->userdata('user_id'); ?>" /> 
                        <div class="col-lg-12">
                            <?php if ($this->session->userdata('userType') == 2) { ?>
                                <div class="form-group">
                                    <label class="radio-inline"><input type="radio" name="replyType" value="Comment" required>Comment</label>
                                    <label class="radio-inline"><input type="radio" name="replyType" value="Answer">Answer</label>
                                </div>
                            <?php } else { ?>
                                <input type="hidden" name="replyType" value="Comment" /> 
                            <?php } ?>
                            <script type="text/javascript">
                                //<![CDATA[
                                bkLib.onDomLoaded(function () {
                                    nicEditors.allTextAreas()
                                });
                                //]]>
                            </script>
                            <div class="form-group">
                                <h4>Write here</h4>
                                <textarea name="answer" cols="80"   rows="10" style="width: 100%;"></textarea>
                            </div>
                            <?php if ($this->session->userdata('userType') == 2) { ?>
                                <div class="form-group">
                                    <label for="Ans">Answer</label>

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="input-group dropdown">
                                                <input autocomplete="off" name="ans" type="text" class="frm-l-s form-control countrycode dropdown-toggle" placeholder="Select Answer" value="">
                                                <ul class="dropdown-menu" style="min-width:100%;">
                                                    <?php foreach ($st_ans_list as $row_sa) { ?>
                                                        <li><a style="color:#1D1D1B !important;text-decoration: none;" href="#" data-value="<?php echo @$row_sa['ans']; ?>"><?php echo @$row_sa['ans']; ?></a></li>
                                                    <?php } ?>
                                                </ul>
                                                <span role="button" class="input-group-addon dropdown-toggle hdn-border" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="caret"></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                            <?php } ?>
                            <div class="" style="padding-top: 15px;">
                                <button type="submit" class="btn btn-success" >Post Comment</button> 
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
        <script>
            $(function () {
                $('.dropdown-menu a').click(function () {
                    console.log($(this).attr('data-value'));
                    $(this).closest('.dropdown').find('input.countrycode')
                            .val($(this).attr('data-value')).focus();
                });
            });
            $(document).ready(function () {
                $('[data-toggle="tooltip"]').tooltip();
                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);

                $("#iCommentbtn").on('click', function () {
                    $('#iAnswer').hide();
                    $('#iComment').show();
                });
            });

//            function CopyToClipboard(id) {
//                var txt = $('#answer' + id).val();
//                if (!txt || txt == '') {
//                    return;
//                }
//
//                copyTextToClipboard(txt);
//
//            }
//
//            function copyTextToClipboard(text) {
//                var textArea = document.createElement("textarea");
//
//                textArea.style.position = 'fixed';
//                textArea.style.top = 0;
//                textArea.style.left = 0;
//                textArea.style.width = '2em';
//                textArea.style.height = '2em';
//                textArea.style.padding = 0;
//                textArea.style.border = 'none';
//                textArea.style.outline = 'none';
//                textArea.style.boxShadow = 'none';
//                textArea.style.background = 'transparent';
//                textArea.value = text;
//                document.body.appendChild(textArea);
//                textArea.select();
//                try {
//                    var successful = document.execCommand('copy');
//                    var msg = successful ? 'successful' : 'unsuccessful';
//                    alert('text copied');
//                    //console.log('Copying text command was ' + msg);
//                } catch (err) {
//                    alert('unable to copy text');
//                    //console.log('Oops, unable to copy');
//                }
//                document.body.removeChild(textArea);
//
//            }
            function copyToClipboard(target) {
                var res = target.split("answer");
                var element = document.getElementById(target); //alert(element);
                var text = element.innerHTML;
                CopyToClipboard(text);
                alert("Copied the text");
            }

            function CopyToClipboard(text) {

                if (window.clipboardData && window.clipboardData.setData) {
                    // IE specific code path to prevent textarea being shown while dialog is visible.
                    return clipboardData.setData("Text", text);

                } else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
                    var textarea = document.createElement("textarea");
                    textarea.textContent = text;
                    textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
                    document.body.appendChild(textarea);
                    textarea.select();

                    try {
                        return document.execCommand("copy");  // Security exception may be thrown by some browsers.
                    } catch (ex) {
                        console.warn("Copy to clipboard failed.", ex);
                        return false;
                    } finally {
                        document.body.removeChild(textarea);
                    }
                }
            }

        </script>