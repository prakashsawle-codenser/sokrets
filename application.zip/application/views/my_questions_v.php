<style>
    .nav>li>a:focus, .nav>li>a:hover {
        text-decoration: none; 
        background-color: #F9F8F8;
    }
    .active_my_tab{
        background-color: #fff;
        border-left: 2px solid #F9F8F8!important;
        font-size: 12px;
        font-weight: bold;
        color:#201F1F !important;
    }
</style>

<a href="javascript:void(0);" onclick="closeNav('MenuPopup')"><img class="close-btn-png my-q-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" /></a>           
<div class="container-sokrates">
    <div class="col-lg-12  question-div clearfix" >
        <div class="col-lg-3 col-sm-3 noPadding question-title-div" >
            <h3>My Questions</h3>
            <small>My Questions has <?php echo @count($questions_answer); ?> Questions.</small>
        </div>
        <div class="col-lg-9 col-sm-9 noPadding">
            <div class="question-ser-div">
                <i class="fa fa-search my-q-ser-icon"></i>
                <input onkeyup="serQuestion(this.value,'MYQuestion');" type="text" id="iSer"  name="ser" value="<?=@$ser;?>" class="form-control my-q-ser" placeholder="My Questions Search" />
                <small>sort by &nbsp; 
                    <a id="iSortDate" onclick="serQuestion('sort_date','MYQuestion');" href="javascript:void(0);" data-item="ASC">
                        date
                    </a> &nbsp; &nbsp;
                    <a id="iSortAbc" onclick="serQuestion('sort_abc','MYQuestion');" href="javascript:void(0);" data-item="ASC">
                        alphabetically^
                    </a>
                </small>
            </div>
        </div>
    </div>
    <div class="col-lg-12 q-and-answer" id="iMyQList"  >
        <div class="main-myq-tab-div">
            <ul class="nav nav-tabs my-q-nav">
                <li class=""><a class="active_my_tab" data-toggle="tab" href="javascript:void(0)">Questions</a></li>
               
                <li>
                    <a onclick="openNav('Progress');" data-toggle="tab" href="javascript:void(0)" >Progress
                        <?php if (isset($progress_count->progress_count) && $progress_count->progress_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $progress_count->progress_count; ?>
                            </span>
                        <?php }
                        ?>
                    </a>
                </li>
                 <li>
                    <a onclick="openNav('New_answer');" data-toggle="tab" href="javascript:void(0)">New answers
                        <?php if (isset($ans_count->ans_count) && $ans_count->ans_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $ans_count->ans_count; ?>
                            </span>            
                        <?php } ?>
                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <div id="Questions" class="tab-pane fade in active">
                    <div class="question-tab-data" id="iAjaxResult">
                        
                        <?php
                        foreach ($questions_answer as $q) {
                            if (@$q['followUpQuestionsID'] != "") {
                                $sql_follup = "SELECT * FROM `answer` WHERE questionID = '" . $q['question_id'] . "' and questionBy = '" . $this->session->userdata('user_id') . "' ";
                                $exe_follup = $this->db->query($sql_follup);
                                if ($exe_follup->num_rows() > 0) {
                                    ?>
                                     <div class="q-a-width" id="qblock<?php echo $q['question_id']; ?>" >
                                    <h4>
                                        <i style="font-weight: bold;color: #000;" class="fa fa-angle-right"></i> 
                                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>">
                                            <?php echo @$q['questionTitle']; ?> <span style="color: #A5A4A4;font-weight: normal;font-size: 14px;">(<?php echo date('j F, Y', strtotime($q['created'])); ?>)</span>
                                        </a>
                                    </h4>
                                    <span class="q-answer">
                                        &nbsp; &nbsp; <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>"><?php echo @$exe_follup->first_row()->answer; ?></a>
                                    </span>
                                    <div class="delete-my-q-div">
                                        <!--onclick="serQuestion('deleteQue-<?php //echo @$q['question_id']; ?>');"-->
                                        <a  alt="Delete"  onclick="deleteQuestion(<?php echo $q['question_id']; ?>)"  href="javascript:void(0)"  >
                                            <i style="color:gray;" class="fa fa-trash-o" ></i>
                                        </a>
                                    </div>
                                  </div>
                                    <?php
                                }
                            } else {
                                ?>
                                <div class="q-a-width" id="qblock<?php echo $q['question_id']; ?>" >
                                    <h4>
                                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['questionTitle']; ?></a>

                                    </h4>
                                    <span class="q-answer">
                                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['answer']; ?></a>
                                    </span>
                                    <!-- tags section -->
                                    <div class="tag_section">
                                        <a class="tagbtn" id="tagArea" href="#" title="Add Tags" data-qid="<?php echo $q['question_id']; ?>">
                                            <i class="fa fa-tags" aria-hidden="true"></i>
                                            <span id="" class="">Tag:</span>
                                        </a>
                                        <?php 
                                             $sql_tag = "SELECT * FROM `question_tag` WHERE qid = '" . $q['question_id'] . "' ";
                                         $exe_tag = $this->db->query($sql_tag)->result_array();
                                         ?>
                                        <div class="tags_list" id="tags_list<?php echo $q['question_id']; ?>">
                                            <?php foreach ($exe_tag as $key => $value) { ?>
                                               <a href="javascript:void(0)"> <?php echo $value['tag']; ?>, <i class="fa fa-times close" aria-hidden="true"  data-id="<?php echo $value['id']; ?>" data-qid="<?php echo $value['qid']; ?>" onclick="closefun(<?php echo $value['id']; ?>,<?php echo $value['qid']; ?>)"></i></a>
                                           <?php } ?>
                                           
                                         <!--    <a href="javascript:voide(0)"> tag 2, <i class="fa fa-times" aria-hidden="true"></i></a>
                                            <a href="javascript:voide(0)"> tag 3, <i class="fa fa-times" aria-hidden="true"></i></a>
                                            <a href="javascript:voide(0)"> tag 4 <i class="fa fa-times" aria-hidden="true"></i></a> -->
                                        </div>
                                        <div class="tagBox" id="tagBox<?php echo $q['question_id']; ?>">
                                           <div class="inputTag">
                                            <a href="#" class="addTag" style="display:none;">
                                               <i class="fa fa-plus-circle"></i>
                                            </a>
                                               <span class="inputgroup">
                                                   <input type="text" placeholder="" class="inputtag"   data-qid="<?php echo $q['question_id']; ?>" />
                                                   <a href="#" class="crossTag"><i class="fa fa-times" aria-hidden="true"></i></a>
                                               </span>
                                           </div>

                                        </div>
                                    </div>
                                    <!-- /tags section -->

                                    <div class="delete-my-q-div">
                                        <!--onclick="serQuestion('deleteQue-<?php //echo @$q['question_id']; ?>');"-->
                                        <a  alt="Delete"  onclick="deleteQuestion(<?php echo $q['question_id']; ?>)"  href="javascript:void(0)"  >
                                            <i style="color:gray;" class="fa fa-trash-o" ></i>
                                        </a>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>                              
            </div>
        </div>       
    </div> 
</div>

<script>
$(document).ready(function(){
  $(".tagbtn").click(function(){
   $(document).unbind('keydown');
    var qid=$(this).data('qid')
    $("#tagBox"+qid).slideToggle(500);
  });

$(".inputtag").keypress(function(e) {
    if(e.which == 13) {
     bindFunction();
        var qid=$(this).data('qid');
        var temp=$(this);
        var tag=$(this).val();
        var formData = new FormData();
        formData.append('qid', qid);
        formData.append('tag', tag);
        $.ajax({
            url: '<?php echo site_url("ask_questions/add_questiontag/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { 
             $(temp).val('');
               $("#tagBox"+qid).slideToggle(500);
               $("#tags_list"+qid).html(data);
            }
        });

    }
});



});

$(document).on("click",".close",function(){
alert('dd'); 
   // alert($(this).data('qid'));
   //  var qid=$(this).data('qid');
   //      var temp=$(this);
   //      var id=$(this).data('id');
   //      var formData = new FormData();
   //      formData.append('qid', qid);
   //      formData.append('id', id);
   //      $.ajax({
   //          url: '<?php echo site_url("ask_questions/remove_questiontag/"); ?>',
   //          type: "POST",
   //          data: formData,
   //          contentType: false,
   //          cache: false,
   //          processData: false,
   //          success: function (data)
   //          { 
           
   //             $("#tags_list"+qid).html(data);
   //          }
   //      });

})

function closefun(id,qid)
{
   
        var formData = new FormData();
        formData.append('qid', qid);
        formData.append('id', id);
        $.ajax({
            url: '<?php echo site_url("ask_questions/remove_questiontag/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { 
           
               $("#tags_list"+qid).html(data);
            }
        });

}
function bindFunction(){
 $(document).bind('keydown',function(e){
    $('#tags').focus();
   // $(document).unbind('keydown');
});
}
</script>