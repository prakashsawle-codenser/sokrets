
<div class="content">

    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar" style="width: 100%">

            <h5 style="    background: #fb7a7a;
                color: #fff;
                font-weight: bold;
                padding: 12px 10px;
                font-size: 17px;">Your Current Plan expired on <?php echo date('j F, Y', strtotime("+$current_plan->duration", strtotime($current_plan->created))); ?></h5>

                <div class="article" style="background-color: #fff;">
                <div class="pricing-title">PRICING PLANS</div>
                <div class="p-title-bottom text-center"></div>
                <h2><span></span> </h2>

                <div class="clr"></div>

                <div class="comment" style="display: flow-root;"> 
                    <div class="col-lg-12">
                        <?php foreach ($subscription_plan as $row) { ?>
                            <div class="col-lg-3 sub3-pad">
                                <div class="table-responsive" >
                                    <table class="table table-striped table-bordered pricing-table"  >                                     
                                        <tr class="<?php
                                        if (@$row['id'] == $user->subscriptionID) {
                                            echo 'active_plan';
                                        } else {
                                            echo 'sub-head';
                                        }
                                        ?>">
                                            <td class="text-center">                                            
    <?php echo @$row['planName']; ?>
                                            </td>                                       
                                        </tr>
                                        <tr>
                                            <td class="text-center" style="    padding: 35px 0;">
                                                <div class="price"><span class="currency">$</span><?php echo @$row['price']; ?></div>
                                                <div class="tariff">/ <?php echo @$row['duration']; ?></div>
                                            </td>
                                        </tr> 
                                        <tr  class="<?php
    if (@$row['id'] == $user->subscriptionID) {
        echo 'buy-active';
    }
    ?>">
                                            <td class="text-center">
                                                <div class="c-foot">
                                                    <a href="<?php echo site_url("subscription/buy_plan/" . $row['id']); ?>" class="buy-btn">BUY NOW</a>
                                                </div>
                                            </td>
                                        </tr> 
                                    </table>
                                </div>
                            </div>
<?php } ?>
                    </div>
                </div>

            </div>

        </div>
 <?php include 'common.php'; ?>
        <script>
            $(document).ready(function () {
                $("#USERM").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);
            });
        </script>