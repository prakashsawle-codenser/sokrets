
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick-theme.css">
<script src="<?php echo base_url(); ?>assets/slick/slick.js" charset="utf-8"></script>
<style>
    .slick-slider{
        width:85%;
        margin: auto;
    }
    .follow-up-questions{
        width:85%;
        margin: auto;
    }
</style>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="home-main">
            <div class="mainbar" style="width:100%;">
                <div class="art-q-div"  >
                    <div class="article-question" style="min-height: auto !important">
                        <div class="clr"></div>
                        <div class="comment" style="text-align: center;" >                             
                            <p class="text-center home-q-title" >
                                <?php echo $dialogue[0]['questionTitle']; ?>
                            </p>                    
                        </div>
                    </div>
                </div>
                <?php foreach ($dialogue as $d_row) { ?>
                    <div class="art-a-div">
                        <div class="article-answer" style="padding:0;min-height: auto !important;">                        
                            <div class="text-center" style="padding:5px;">                                    
                                <p class="commentbx-home" >                                 
                                    <?php echo @$d_row['answer']; ?>                                                                               
                                </p>
                            </div>                          
                        </div>
                    </div>
                <?php } ?>
            </div>

        </div>

<!--        <div class="ask_q_footer">
            <div class="ask_q_footer_resize">
                <div class="col-lg-12 noPadding">
                    <div id="HomeSidenav" class="ans-src-div">
                        <a href="javascript:void(0)" class="closebtn-ans-src" onclick="closeSrc()">&times;</a>
                        <div class="asq_foot_btn" >Answer Source</div>
                        <div class="ans-src-chk" style="">                    
                            <label class="checkbox-inline qcustom-check"  >
                                <input id="ichk_int" name="sources" type="checkbox" value="Internet" >
                                Internet
                                <span class="qcheckmark" ></span>
                            </label>
                            <label class="checkbox-inline qcustom-check" >
                                <input id="ichk_lib" name="sources" type="checkbox" value="My Library">
                                My Library
                                <span class="qcheckmark" ></span>
                            </label>
                        </div>
                    </div> 
                    <div class="asq_foot_btn asq-right" onclick="openSrc()" >
                        Answer Source
                    </div>
                    <div id="HomePronav" class="home-pro-div">

                    </div>
                    <div class="asq_foot_btn asq-left" onclick="openPro()">
                        Progress 
                        <span class="header_q_count" style="padding: 0px 4px;">
                            <?php echo @str_pad("50", 2, "0", STR_PAD_LEFT); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>-->
        <?php include 'footer_tabs.php'; ?>
        <?php include 'common.php'; ?>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
        <script>

            function getSugVal(val) {
                $('#tags').val(val);
                $('.sugestion-tag').hide();
            }
            $(document).ready(function () {

                $('input').keypress(function (e) {
                    if (e.which == 13) {
                        $('form#form-question').submit();
                        return false;    //<---- Add this line
                    }
                });

                $('#ichk_int').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });
                $('#ichk_lib').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });

                $("#tags").on('keyup', function () {
                    var q = this.value;
                    var formData = new FormData();
                    formData.append('q', q);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/get_sugestion/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                            $('.sugestion-tag').show();
                            $('#sugestion-tag').html(data);
                        }
                    });
                });

                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);


            });

        </script>
