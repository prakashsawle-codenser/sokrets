<div class="content">
    <div class="content_resize">
        <div class="mainbar">
            <!--            <div class="article">
                            <h2><span>Contact</span></h2>
                            <div class="clr"></div>
                            <p>You can find more of my free template designs at my website. For premium commercial designs, you can check out DreamTemplate.com.</p>
                        </div>-->
            <div class="article div-l-s" style="background-color: #fff;">
                
                <h2 style="text-align: center;color: #757575;">Change password</h2>
                <div class="clr"></div>
                <div class="row">
                    <?php if ($this->session->flashdata('register_success')) : ?>
                        
                    <div class="col-md-12">
                            <div class="alert alert-success alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success!</strong> <?php echo $this->session->flashdata('register_success'); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
                if ($this->session->flashdata('error')) {
                    echo $this->session->flashdata('error');
                }
                ?>
                <form action="<?php echo site_url("register/change_pass"); ?>" method="post" id="sendemail">
                    <ol>
                        <li>
                            <label for="website">Old Password (required)</label>
                            <input class="form-control frm-l-s" id="password" type="password" name="old_password" class="text"  />
                        </li>
                        <li>
                            <label for="website">New Password (required)</label>
                            <input class="form-control frm-l-s" id="password" type="password" name="password" class="text" />
                        </li>
                         <li>
                            <label for="website">Confirm new Password (required)</label>
                            <input class="form-control frm-l-s" id="password" type="password" name="con_password" class="text" />
                        </li>
                        <li>
                            <button class="btn send" type="submit" name="submit" style="margin-bottom: 10px;background-color: #E40613;color: #fff;">Submit</button>
                            <!--<input type="image" name="imageField" id="imageField" src="<?php echo base_url(); ?>assets/images/submit.gif" class="send" />-->
                            <div class="clr"></div>
                        </li>
                    </ol>
                </form>
     
            </div>
        </div>
         <?php include 'common.php'; ?>
        <script>
            $(document).ready(function () {
                $("#USERM").removeClass().addClass('dropdown active');
            });
        </script>