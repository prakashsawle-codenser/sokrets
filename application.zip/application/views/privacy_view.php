
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
         <link rel='icon' href="<?php echo base_url(); ?>uploads/doc_image/sokrates_app_logo.png" type='image/png'/ >
        <!--        bootstrap live link   start -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="h<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!--  end-->
       <!--<link rel="stylesheet" href="http://localhost/sokrets/assets/drag_and_drop/css/style.css" />-->

        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
        <style>
            .head-drop li a:hover{
                border-bottom: none !important;              
            }
        </style>
    </head>
<body class="terms_privacy">     
        
        <!-- START PAGE SOURCE -->
          
    <div class="main">   
    	<div class="terms-header header_resize">
    		<div class="logo">
    			<a href="<?php echo site_url("Login_c"); ?>"><img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a>  
    		</div>
<?php  if ($this->session->userdata('user_id') != '') { ?>
           		<a href="<?php echo site_url("ask_questions"); ?>" class="big_close-btn" onclick="closeNavSideMenu()">
			    <img class="close-btn-png nav-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
			</a>
       <?php } ?>    
       	</div>
    		
    	</div>
			<section class="">
			    	<div class="container-small">
			    		<h2 class="mainTitle">Sokrates Privacy of Use</h2>
			    		<p class="upperTxtP" style="color: #000; font-weight: 700;">
			    			The Sokrates Privacy Policy was
updated on February 21, 2019.
			    		</p>
			    		<p class="smallP">Your privacy is important to Sokrates so we have
developed a Privacy Policy that covers how we
collect, use, disclose, transfer, and store your
personal information. Please take a moment to
familiarize yourself with our privacy practices and
contact us if you have any questions.</p>

						<h3 class="subtitleh3">Collection and Use of
Personal Information</h3>
						<p class="smallP">
							 Personal information is data that can be used to identify or
contact a single person.
						</p>
						<p class="smallP">
							You may be asked to provide your personal information anytime
you are in contact with Sokrates or an Sokrates affiliated
company. Sokrates and its affiliates may share this personal
information with each other and use it consistent with this
Privacy Policy. They may also combine it with other information
to provide and improve our products, services, content, and
advertising. You are not required to provide the personal 
information that we have requested, but, if you chose not to do
so, in many cases we will not be able to provide you with our
products or services or respond to any queries you may have.
						</p>
						<p class="smallP">
							Here are some examples of the types of personal information
Sokrates may collect and how we may use it:
						</p>
						<h3 class="subtitleh3">
							What personal information we collect
						</h3>
						<p class="smallP">
							<ul>
								<li>When you create an Sokrates ID, purchase a product,
connect to our services, contact us or participate in an
online survey, we may collect a variety of information,
including your name, mailing address, phone number,
email address, contact preferences, device identifiers, IP
address, location information and credit card information.</li>

							<li>When you share your content with colleagues, family and
friends using Sokrates products, or invite others to
participate in Sokrates services or forums, Sokrates may
collect the information you provide about those people
such as name, mailing address, email address, and phone
number. Sokrates will use such information to fulfill your
requests, provide the relevant product or service, or for
anti-fraud purposes.</li>
							<li>In certain jurisdictions, we may ask for a government
issued ID in limited circumstances including when
activating your services, or as required by law.</li>
							
							</ul>
						</p>
						<h3 class="subtitleh3">How we use your personal information</h3>
						<p class="smallP">
							We may process your personal information: for the purposes
described in this Privacy Policy, with your consent, for
compliance with a legal obligation to which Sokrates is subject
or when we have assessed it is necessary for the purposes of 
the legitimate interests pursued by Sokrates or a third party to
whom it may be necessary to disclose information.

						<ul>
							<li>
								The personal information we collect allows us to keep you
posted on Sokrates’s latest product announcements,
software updates, and upcoming events. If you don’t want
to be on our mailing list, you can opt out anytime by
updating your preferences.
							</li>
							<li>
								We also use personal information to help us create,
develop, operate, deliver, and improve our products,
services, content and advertising, and for loss prevention
and anti-fraud purposes. We may also use your personal
information for account and network security purposes,
including in order to protect our services for the benefit of
all our users. Where we use your information for anti-fraud
purposes it arises from the conduct of an online transaction
with us. We limit our uses of data for anti-fraud purposes to
those which are strictly necessary and within our assessed
legitimate interests to protect our customers and our
services. For certain online transactions we may also
validate the information provided by you with publicly
accessible sources.
							</li>
							<li>
								We may use your personal information, including date of
birth, to verify identity, assist with identification of users,
and to determine appropriate services. For example, we
may use date of birth to determine the age of Sokrates ID
account holders.
							</li>
							<li>
								From time to time, we may use your personal information
to send important notices, such as communications about
purchases and changes to our terms, conditions, and
policies. Because this information is important to your
interaction with Sokrates, you may not opt out of receiving 
these communications.
							</li>
							<li>
								We may also use personal information for internal
purposes such as auditing, data analysis, and research to
improve Sokrates’s products, services, and customer
communications.
							</li>
							<li>
								If you enter into a sweepstake, contest, or similar
promotion we may use the information you provide to
administer those programs.

							</li>
							
						</ul>
						</p>
						<h3>Source of your personal information where they
are not collected from you</h3>
						<p class="smallP">
							We may have received your personal information from other
persons if that person has shared their content with you using
Sokrates products, or invited you to participate in Sokrates
services or forums. We may also validate the information
provided by you when creating an Sokrates ID with a third party
for security and fraud prevention purposes.
						</p>
						<p class="smallP">
							For research and development purposes, we may use datasets
such as those that contain images, voices or other data that
could be associated with an identifiable person. When acquiring
such datasets, we do so in accordance with applicable law in
the jurisdiction in which the dataset is hosted. When using such
datasets for research and development, we do not attempt to
re-identify individuals who may appear therein.
						</p>
						<h3 class="subtitleh3">Collection and Use of Non-Personal
Information</h3>

						<p class="smallP">
							We also collect data in a form that does not, on its own, permit
direct association with any specific individual. We may collect,
use, transfer, and disclose non-personal information for any 
purpose. The following are some examples of non-personal
information that we collect and how we may use it:
						<ul>
							<li>
								We may collect information such as occupation, language,
zip code, area code, unique device identifier, referrer URL,
location, and the time zone where a Sokrates product is
used so that we can better understand customer behavior
and improve our products, services, and advertising.
							</li>
							<li>
								We may collect information regarding customer activities
on our website and from our other products and services.
This information is aggregated and used to help us provide
more useful information to our customers and to
understand which parts of our website, products, and
services are of most interest. Aggregated data is
considered non‑personal information for the purposes of
this Privacy Policy
							</li>
							<li>
								We may collect and store details of how you use our
services, including search queries. This information may be
used to improve the relevancy of results provided by our
services. Except in limited instances to ensure quality of
our services over the Internet, such information will not be
associated with your IP address.
							</li>
							<li>
								With your explicit consent, we may collect data about how
you use your device and applications in order to help app
developers improve their apps.
							</li>
						</ul>
						If we do combine non-personal information with personal
information the combined information will be treated as
personal information for as long as it remains combined.

						</p>
						<h3 class="subtitleh3">
							Cookies and Other Technologies
						</h3>
						<p class="smallP">
							Sokrates’s websites, online services, interactive applications,
email messages, and advertisements may use "cookies" and
other technologies such as pixel tags and web beacons. These
technologies help us better understand user behavior, tell us
which parts of our websites people have visited, and facilitate
and measure the effectiveness of advertisements and web
searches. We treat information collected by cookies and other
technologies as non‑personal information. However, to the
extent that Internet Protocol (IP) addresses or similar identifiers
are considered personal information by local law, we also treat
these identifiers as personal information. Similarly, to the extent
that non-personal information is combined with personal
information, we treat the combined information as personal
information for the purposes of this Privacy Policy.
						</p>
						<p class="smallP">
							Sokrates and our partners also use cookies and other
technologies to remember personal information when you use
our website, online services, and applications. Our goal in these
cases is to make your experience with Sokrates more
convenient and personal. For example, knowing your first name
lets us welcome you the next time you visit the Sokrates app.
Knowing your country and language helps us provide a
customized and more useful experience. If you want to disable
cookies on your computer or device, check with your provider to
find out how to disable cookies. Please note that certain
features of the Sokrates website will not be available once
cookies are disabled.
						</p>
						<p class="smallP">
							As is true of most internet services, we gather some information
automatically and store it in log files. This information includes
Internet Protocol (IP) addresses, browser type and language,
Internet service provider (ISP), referring and exit websites and
applications, operating system, date/time stamp, and
clickstream data.
						</p>
						<p class="smallP">
							We use this information to understand and analyze trends, to
administer the site, to learn about user behavior on the site, to
improve our product and services, and to gather demographic
information about our user base as a whole. Sokrates may use
this information in our marketing and advertising services.
						</p>
						<h3 class="subtitleh3">Disclosure to Third Parties</h3>
						<p class="smallP">
							At times Sokrates may make certain personal information
available to strategic partners that work with Sokrates to
provide products and services, or that help Sokrates market to
customers. Personal information will only be shared by
Sokrates to provide or improve our products, services and
advertising; it will not be shared with third parties for their
marketing purposes.
						</p>
						<h3 class="subtitleh3">Service Providers</h3>
						<p class="smallP">
							Sokrates shares personal information with companies who
provide services such as information processing, extending
credit, fulfilling customer orders, delivering products to you,
managing and enhancing customer data, providing customer
service, assessing your interest in our products and services,
and conducting customer research or satisfaction surveys.
These companies are obligated to protect your information and
may be located wherever Sokrates operates.
						</p>
						<h3 class="subtitleh3">Others</h3>
						<p class="smallP">
							It may be necessary − by law, legal process, litigation, and/or
requests from public and governmental authorities within or
outside your country of residence − for Sokrates to disclose
your personal information. We may also disclose information
about you if we determine that for purposes of national security, 
law enforcement, or other issues of public importance,
disclosure is necessary or appropriate.
						</p>
						<p class="smallP">
							We may also disclose information about you if we determine
that disclosure is reasonably necessary to enforce our terms
and conditions or protect our operations or users. Additionally,
in the event of a reorganization, merger, or sale we may
transfer any and all personal information we collect to the
relevant third party.
						</p>
						<h3 class="subtitleh3">Protection of Personal Information</h3>
						<p class="smallP">
							Sokrates takes the security of your personal information very
seriously. When you use some Sokrates products, services, or
applications or post on an Sokrates forum, chat room, or social
networking service, the personal information and content you
share is visible to other users and can be read, collected, or
used by them. You are responsible for the personal information
you choose to share or submit in these instances. For example,
if you list your name and email address in a forum posting, that
information is public. Please take care when using these
features.
						</p>
						<h3 class="subtitleh3">The existence of Automated DecisionMaking, Including Profiling</h3>
						<p class="smallP">Sokrates does not take any decisions involving the use of
algorithms or profiling that significantly affects you.</p>

						<h3 class="subtitleh3">Integrity and Retention of Personal
Information</h3>
						<p class="smallP">
							Sokrates makes it easy for you to keep your personal
information accurate, complete, and up to date. We will retain
your personal information for the period necessary to fulfill the
purposes outlined in this Privacy Policy and our service specific
privacy summaries. When assessing these periods we carefully
examine our need to collect personal information at all and if we
establish a relevant need we only retain it for the shortest
possible period to realize the purpose of collection unless a
longer retention period is required by law.
						</p>
						<h3 class="subtitleh3">Access to Personal Information</h3>
						<p class="smallP">
							You can help ensure that your contact information and
preferences are accurate, complete, and up to date by signing
in to your Sokrates ID account page. For other personal
information we hold, we will provide you with access (including
a copy) for any purpose including to request that we correct the
data if it is inaccurate or delete the data if Sokrates is not
required to retain it by law or for legitimate business purposes.
We may decline to process requests that are frivolous/
vexatious, jeopardize the privacy of others, are extremely
impractical, or for which access is not otherwise required by
local law. We may also decline aspects of deletion or access
requests if we believe doing so would undermine our legitimate
use of data for anti-fraud and security purposes as described
earlier.
						</p>
						<h3 class="subtitleh3">Children & Education</h3>
						<p class="smallP">
							We understand the importance of taking extra precautions to
protect the privacy and safety of children using Sokrates
products and services. Children under the age of 13, or
equivalent minimum age in the relevant jurisdiction, are not 
permitted to create their own Sokrates IDs, unless their parent
provided verifiable consent. 
						</p>
						<p class="smallP">If we learn that we have collected the personal information of a
child under 13, or equivalent minimum age depending on
jurisdiction, outside the above circumstances we will take steps
to delete the information as soon as possible.</p>
						<p class="smallP">
							If at any time a parent needs to access, correct, or delete data
associated with their child’s Sokrates ID, they may contact us
through one of the options provided at the bottom of this page.

						</p>
						<h3 class="subtitleh3">Third‑Party Sites and Services</h3>
						<p class="smallP">Sokrates websites, products, applications, and services may
contain links to third-party websites, products, and services. Our
products and services may also use or offer products or
services from third parties − for example, a third‑party iPhone
app.</p>
						<p class="smallP">Information collected by third parties, which may include such
things as location data or contact details, is governed by their
privacy practices. We encourage you to learn about the privacy
practices of those third parties..</p>

						<h3 class="subtitleh3">International Users</h3>
						<p class="smallP">
							All the information you provide may be transferred or accessed
by entities around the world as described in this Privacy Policy.
Personal information, relating to Sokrates services, regarding
individuals who reside in a member state of the European
Economic Area and Switzerland is controlled by Sokrates
Technologies in the Netherlands. Sokrates uses approved
Model Contractual Clauses for the international transfer of 
personal information collected in the European Economic Area
and Switzerland.
						</p>
						<h3 class="subtitleh3">Our Companywide Commitment to
Your Privacy</h3>
						<p class="smallP">To make sure your personal information is secure, we
communicate our privacy and security guidelines to Sokrates
employees and strictly enforce privacy safeguards within the
company.</p>
						<h3 class="subtitleh3">Privacy Questions</h3>
						<p class="smallP">If you have any questions or concerns about Sokrates’s Privacy
Policy or data processing, or if you would like to make a
complaint about a possible breach of local privacy laws, please
contact us.</p>
						<p class="smallP">When a privacy question or question about personal information
received in response to an access/download request is
received we have a dedicated team which triages the contacts
and seeks to address the specific concern or query which you
are seeking to raise. Where your issue may be more
substantive in nature, more information may be sought from
you. All such substantive contacts receive a response. If you
are unsatisfied with the reply received, you may refer your
complaint to the relevant regulator in your jurisdiction. If you ask
us, we will endeavor to provide you with information about
relevant complaint avenues which may be applicable to your
circumstances.</p>
						<p class="smallP">Sokrates may update its Privacy Policy from time to time. When
we change the policy in a material way, a notice will be posted
on our website along with the updated Privacy Policy.</p>
						<p class="smallP">Sokrates Technologies, Amsterdam, the Netherlands</p>
						

			    	</div>
    	</section>
	</div>


<div class="footer">
    <div class="footer_resize">
        <p class="lf">Copyright © 2018 <a href="#">Sokrates Technologies.</a> All rights reserved.</p>        
        <div class="clr"></div>
    </div>
</div>
<!-- END PAGE SOURCE -->

</body>
</html>

