
<div class="content">
    <div class="content_resize">
        <div  class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <div class="col-lg-12 text-right" style="padding: 0">
<!--                    <form class="example" action="<?php echo site_url('standard_answers'); ?>" method="post" style="   margin: 0 0 20px 0;">
                        <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>-->
                </div>
                <div style="clear: both">

                    <h3 style="color:#2980b9;font-size: 1.25em;font-weight: bold;margin-top: 10px;"><a style="text-decoration: none;" href="<?php echo site_url('register/my_profile/'); ?>">Activity by <?php echo @$this->session->userdata('firstName') . " " . @$this->session->userdata('lastName'); ?></a></h3>

                    <div class="clr"></div>
                    <div class="comment" style="padding:0 !important;"> 
                        <div class="table-responsive">

                            <table class="table" id="user-activity-tbl">
                                <tbody>
                                    <tr >
                                        <td style="font-size: 18px;">
                                            Score:
                                        </td>
                                        <?php  
                                        $i = 0; $j = 0; 
                                        $points = 0;
                                        foreach ($score as $row_s) {  
                                            
                                            if (@$row_s['progress_status'] == $st_count->tbl_status_count) { 
                                                if (@$row_s['step_time'] <= 1440) {
                                                    $points += 10;
                                                }
                                                if (@$row_s['step_time'] >= 1441 && $row_s['step_time'] <= 2880) {
                                                    $points += 5;
                                                }
                                                if (@$row_s['step_time'] >= 2881 && $row_s['step_time'] <= 4320) {
                                                    $points += 2;
                                                }
                                                $i++;
                                            } 
                                            $j++;
                                        }
                                        ?>
                                        <td id="act-points" style="font-size: 17px;color:#23527c;">
                                            <?php echo @$points; ?> points 
                                        </td>
                                    </tr>
                                    <tr >
                                        <td style="font-size: 18px;">
                                            Questions:
                                        </td>
                                        <td id="act-points" style="font-size: 17px;color:#23527c;">
                                            <?php echo @$j; ?> 
                                        </td>
                                    </tr>
                                    <tr id="answers" >
                                        <td style="font-size: 18px;">
                                            Answers:
                                        </td>
                                        <td id="act-points" style="font-size: 17px;color:#23527c;">
                                            <?php echo @$i; ?> 
                                        </td>
                                    </tr>
                                    <tr id="comments" >
                                        <td style="font-size: 18px;">
                                            Comments:
                                        </td>
                                        <td id="act-points" style="font-size: 17px;color:#23527c;">
                                            0
                                        </td>
                                    </tr>
                                    <tr id="votedon" >
                                        <td style="font-size: 18px;">
                                            Voted on:
                                        </td>
                                        <td id="act-points" style="font-size: 17px;color:#23527c;" >
                                            0 questions, 0 answers
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Modal -->
        <div class="modal fade" id="addans" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title" style="color:#1D1D1B;font-weight: bold;">Add Answer</h4>
                    </div>
                    <form method="post" action="<?php echo site_url('standard_answers/add_s_ans/'); ?>" >

                        <div class="modal-body">
                            <div class="form-group">
                                <label for="usr">Answer:</label>
                                <input type="text" name="ans" value="" placeholder="" class="form-control frm-l-s" id="usr">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" >Submit</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
         <?php include 'common.php'; ?>
        <script>

            $(document).ready(function () {

                $("#a11").removeClass().addClass('active');
                $('#msg').delay(4000).fadeOut();
            });

        </script>

