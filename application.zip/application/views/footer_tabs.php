<?php
$uid = $this->session->userdata('user_id');
//select * from (select a.*, b.questionTitle from tbl_researcher_current_questions a, questions b WHERE a.isCompleted = 0 and a.questionBy = 2 AND a.questionID = b.id order by questionID desc) x group by `questionID`SELECT a.*, b.questionTitle FROM tbl_researcher_current_questions a, questions b WHERE a.questionBy = 2 AND a.questionID = b.id
//$sql_p = $this->db->query("SELECT a.*, b.questionTitle FROM tbl_researcher_current_questions a, questions b WHERE a.questionBy = $uid AND a.questionID = b.id");
$sql_p2 = $this->db->query("SELECT a.id AS q_id,a.questionTitle,a.created AS created_datetime,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID LEFT JOIN answer ON a.id=answer.questionID WHERE a.userID = $uid AND (answer.isRead=0 OR answer.isRead IS NULL )   AND a.isDeleted = 0 ORDER BY a.id DESC ");
$data['user_pro_data'] = $sql_p2->result_array();
//print_r($sql_p2->result_array()); exit;

$uid = $this->session->userdata('user_id');
            $sql_q = "SELECT count(*) as q_count FROM questions INNER JOIN answer on questions.id=answer.questionID WHERE answer.isDeleted = 0 and answer.isRead = 0 AND answer.questionBy = $uid AND answer.replyType = 'Answer' ORDER BY answer.id";
            //$sql_q = "SELECT COUNT(id) as q_count FROM `questions` WHERE userID = $uid AND isRead = 0 AND isDeleted = 0";
            $query_q = $this->db->query($sql_q);


$sql_gn = $this->db->query("SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = $uid AND messageBy != $uid AND isRead = 0 AND isDeleted = 0 AND is_final = 0 GROUP BY questionID) AS aaa");
$give_input = $sql_gn->first_row();

$sql_gn = $this->db->query("SELECT * FROM user WHERE id=".$uid);
$anssource = $sql_gn->first_row();

?>

<div class="footer-tab">
     <div  id="answerer" class="divAnswersource f-child-tab-div">
        <a href="javascript:void(0)" style="display: none;" class="iCloseanswerer" id="iCloseanswerer" >
            <img class="close-btn-png ans-sou-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
        </a>
        <div class="answerer-sub" style="padding: 5px 0 10px 0; font-weight: 400; font-size: 15px;" >Answerer</div>
        <div class="ans-src-chk" style="">                    
            <label class="checkbox-inline qcustom-check" >
                <input id="ichk_researcher" name="sources" type="checkbox" value="R" <?php if ($anssource->answerSource=='R') {
                  echo "checked"; 
                } ?> >
                Researcher
                <span class="qcheckmark" ></span>
            </label>
            <label class="checkbox-inline qcustom-check"  >
                <input id="ichk_me" name="sources" type="checkbox" value="A" <?php if ($anssource->answerSource=='A') {
                  echo "checked"; 
                } ?> >
                Me
                <span class="qcheckmark" ></span>
            </label>
            
        </div>
    </div>


    <div  id="iAnswerSource" class="divAnswersource f-child-tab-div">
        <a href="javascript:void(0)" style="display: none;" class="iCloseAnswerSource" id="iCloseAnswerSource" >
            <img class="close-btn-png ans-sou-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
        </a>
        <div class="iAnswerSource-sub" style="padding: 5px 0 10px 0;" >Answer Source</div>
        <div class="ans-src-chk" style="">                    
            <label class="checkbox-inline qcustom-check" >
                <input id="ichk_lib" name="sources" type="checkbox" value="My Library" <?php if ($anssource->questionAnswerSource=='B' OR $anssource->questionAnswerSource=='Both' ) {
                  echo "checked"; 
                } ?>>
                BookShelf
                <span class="qcheckmark" ></span>
            </label>
            <label class="checkbox-inline qcustom-check"  >
                <input id="ichk_int" name="sources" type="checkbox" value="Internet" <?php if ($anssource->questionAnswerSource=='I' OR $anssource->questionAnswerSource=='Both') {
                  echo "checked"; 
                } ?>>
                Internet
                <span class="qcheckmark" ></span>
            </label>
            
        </div>
    </div>
    <?php
    if (@$give_input->comment_count == 0) {
        $bg_color = "background-color: #fff;";
        $pointer = "pointer-events: none;";
    } else {
        $bg_color = "background-color: #F59C3A;";
        $pointer = "";
    }

    if (@$u_cmnt_cnt->comment_count == 0) {
        $giveInputClass = "defaultGiveInput";
        $divUpStyle = "padding: 5px 0 10px 0;";
        $btmHight = "height:29px;";
        //$pointer = "pointer-events: none;";
    } else {
        $giveInputClass = "upGiveInput";
        $divUpStyle = "padding: 28px 0 5px 0;";
        $btmHight = "";
        //$pointer = "";
    }
//    if ($give_input->comment_count == 0) {
//    echo "defaultGiveInput";
//} else {
//    echo "upGiveInput";
//} 
    ?>
    <div style="<?= @$bg_color.$pointer; ?>"  id="iGiveInput1" class="divGiveInput f-child-tab-div <?= @$giveInputClass; ?>" <?php if ($giveInputClass=="upGiveInput") { ?> data-status="active" data-url="<?php echo site_url('ask_questions/'); ?>" <?php }else{ ?> data-status="inactive"  data-url="<?php echo site_url('ask_questions/give_input/'); ?>" <?php } ?> >
        <a href="javascript:void(0)" style="display: none;" class="iCloseGiveInput" id="iCloseGiveInput" >
            <img class="close-btn-png ans-sou-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
        </a>
        <div class="iGiveInput-sub" style="<?= $divUpStyle; ?>" >
            <a id="iGiveInputTitle" style="text-decoration: none;<?php
            if ($give_input->comment_count == 0) {
                echo "color:#D5D5D5;";
            } else {
                echo "color:#fff;";
            }
            ?>" href="#" > Give Input
                   <?php //if ($give_input->comment_count != 0) { ?>
                    <!--<span  class="header_q_count" style="padding: 1px 4px;">-->
                <?php //echo @str_pad($give_input->comment_count, 2, "0", STR_PAD_LEFT); ?>
                <!--</span>-->
                <?php //} ?>
                <?php if ($give_input->comment_count != 0) { ?>
                    <span id="iGiveInputNum" class="header_q_count" style="padding: 1px 2px;position: relative;">
                        <?php echo @$give_input->comment_count; ?>
                    </span>
                <?php }else{  ?>
                    <span id="iGiveInputNum" class="" style="padding: 1px 2px;position: absolute;">
                        <?php echo (@$give_input->comment_count != "0") ? $give_input->comment_count : ""; ?>
                    </span>
                <?php }  ?>
                    
            </a>   
        </div>
        <div class="ans-src-chk" style="<?= @$btmHight; ?>">                    

        </div>
    </div>

    <div id="iProgress" class="divProgress f-child-tab-div"  <?php if (count($sql_p2->result_array()) == 0) { ?> style="background-color: #fff;pointer-events: none;"  <?php }?> >
        <a  style="display: none;" href="javascript:void(0)" class="iCloseprogress" id="iCloseprogress" >
            <img  class="close-btn-png prog-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
        </a>
        <div class="iProgress-sub"   <?php if (count($sql_p2->result_array()) == 0) { ?> style="padding: 5px 0 10px 0; color:#D5D5D5;"  <?php }else{ ?> style="padding: 5px 0 10px 0;" <?php }?> >
            Progress
            <?php if (count($sql_p2->result_array()) != 0) { ?>
                <span class="header_q_count" style="padding: 1px 2px;position: relative;" id="progress_counter">
                    <?php echo @count($sql_p2->result_array()); ?>
                </span>
            <?php } ?>
        </div>
        <div style="" class="progress-footer-div" id="progress_div_container"> 
            <?php
            //$sql_p = $this->db->query("select * from (select a.*, b.questionTitle, c.message from tbl_progress_status a, questions b, tbl_progress_messages c WHERE a.isDeleted = 0 and a.questionBy = '".$data['id']."' AND a.questionID = b.id AND a.progress_status = c.id order by questionID, progress_status desc) x group by `questionID`");
            //$sql_p = $this->db->query("SELECT a.*, b.questionTitle FROM tbl_researcher_current_questions a, questions b WHERE a.questionBy = $uid AND a.questionID = b.id");
            //$data['user_pro_data'] = $sql_p->result_array();
            $this->load->view('footer_progress_v', $data);
            ?>
        </div>
    </div>

      <!-- new answe -->
    <div id="" class=" f-child-tab-div newAnswerSource">
       <a href="<?php echo site_url('ask_questions/question_answer'); ?>"  <?php if ($query_q->first_row()->q_count == 0){ ?>
 style= "background-color: #fff; pointer-events: none; color: #D5D5D5; text-decoration: none;" disable="true" <?php }else{ ?>
style="color: #656564; text-decoration: none;"
 <?php } ?> id="newanswer_an" >
          
            <div class="newAnswerTitle" id="new_anscount" >New Answer
             <?php if ($query_q->first_row()->q_count != 0) { ?>
                <span class="header_q_count" style="padding: 1px 2px;position: relative;" id="newanswer_counter">
                    <?php echo $query_q->first_row()->q_count; ?>
                </span>
            <?php } ?>

        </div>
           
       </a> 
       
        
    </div>
    <!-- new answe -->
</div>
<script>
    $(document).ready(function () {
        $('#iAnswerSource').addClass('defaultAnswerSource');
        $('#answerer').addClass('defaultAnswerSource');
        
        $('#iGiveInput').addClass('defaultGiveInput');
        $('#iProgress').toggleClass('defaultProgress');
//                $('#iAnswerSource').click(function () {
//                    $('#iAnswerSource').toggleClass('upAnswerSource');
//                });
//                $('#iProgress').click(function () {
//                    $('#iProgress').toggleClass('upProgress');
//                });
        $('.iGiveInput-sub').click(function () { //alert('1');
            $("#iGiveInput").addClass("upGiveInput");
            $("#iGiveInput").removeClass("defaultGiveInput");
            //$('.iCloseAnswerSource').show();
        });
        $('.iAnswerSource-sub').click(function () {
            $("#iAnswerSource").addClass("upAnswerSource");
            $("#iAnswerSource").removeClass("defaultAnswerSource");
            $('.iCloseAnswerSource').show();
        });
        $('.iCloseAnswerSource').click(function () { //alert('2');
            $("#iAnswerSource").removeClass("upAnswerSource");
            $("#iAnswerSource").addClass("defaultAnswerSource");
            $('.iCloseAnswerSource').hide();
        });
        $('.iProgress-sub').click(function () { //alert('1');
            $("#iProgress").addClass("upProgress");
            $("#iProgress").removeClass("defaultProgress");
            $('.iCloseprogress').show();
        });
        $('.iCloseprogress').click(function () { //alert('2');
            $("#iProgress").removeClass("upProgress");
            $("#iProgress").addClass("defaultProgress");
            $('.iCloseprogress').hide();
        });



         $('.answerer-sub').click(function () {
            $("#answerer").addClass("upAnswerSource");
            $("#answerer").removeClass("defaultAnswerSource");
            $('.iCloseanswerer').show();
        });
        $('#iCloseanswerer').click(function () { //alert('2');
            $("#answerer").removeClass("upAnswerSource");
            $("#answerer").addClass("defaultAnswerSource");
            $('.iCloseanswerer').hide();
        });
    });

</script>