<style>

</style>
<div class="nav-cls-div">
    <a href="javascript:void(0)" onclick="closeNav('MenuPopup')"><img class="res-nav-cls-img" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" /></a>           
</div>
<div class="row">
    <div class="col-lg-12 ser-main-div">

        <div class="col-md-9 live-search" style="margin-top:20px;">

            <div style="position: relative;">
                <label style="color:#D5D5D5;" class="ser-ans">Q</label>
                <div id="iq-div" style="font-weight: bold; padding-left: 10px; padding-bottom: 7px;color:#5E5E5E; font-size: 17px;">
                    <?php echo @$question; ?>
                </div>                
            </div>
            <div style="position: relative;">
                <label class="ser-ans">A</label>
                <textarea  id="i_nav_search" name="nav_search" class="input-search" type="text" ><?php echo @$answer; ?></textarea>
                <i style="cursor: pointer;" class="fa fa-search icon-ser" onclick="searchQuestion();"></i>
            </div>
        </div>
        <div class="col-md-3 ">
            <div class="user-progress new_search" style="border: 0px solid;">
                <h5 class="title-h5 text-center">User progress</h5>
                <div class="pr-title progress-text u_process_1"   style="display: none;"><b>Understanding</b><br/>your question.</div>
                <div class="pr-title progress-text2 u_process_2"  style="display: none;"><b>Researching</b><br/>your question</div>
                <div class="pr-title progress-text3 u_process_3"  style="display: block;"><b>Answering</b><br/>your question</div>
                <div class="pr-title progress-text4 u_process_4"  style="display: none;"><b>Briefing</b><br/>you on the answer</div>
                <div id="iProgressPer" class="pr-title progress-circle progress-60">
                    <span id="iStopwatch" >
                        <spnn>00:00:00</spnn>
                    </span>
                </div> 
            </div>
        </div>
    </div>
    <div class="col-md-12 ser-main-div" id="" >
        <div class="col-md-6">
            <label class="title-ser-mylib">BookShelf</label>
           <?php if (!empty($library_result)) {
             foreach ($library_result as $key => $value) { ?>
                <div class="ser-div">
                        <div class="url-div">
                            <lable class="url-lbl"><a style="color:#313793;font-weight: bold;" href="<?= @$q->url; ?>" target="_blank"></a></lable>
                        </div>
                        <div class="display-url">
                            <a style="color:#246D3C; word-break: break-word;" href="<?php echo $value['url']; ?>" target="_blank"> <?php 
                                echo $value['url'];
                            ?></a>
                        </div>
                        <div class="ser-descr"> 
                            <?php echo word_limiter($value['content'], 25); ?>
                        </div>
                        <p></p>
                    </div>  
           <?php  }
           }


            ?>
        </div>
        <div class="col-md-6">
            <label class="title-ser-inter">Internet</label>
            <?php
            if (!empty($ser)) {
                foreach (@$ser as $q) {
                    ?>
                    <div class="ser-div">
                        <div class="url-div">
                            <lable class="url-lbl"><a style="color:#313793;font-weight: bold;" href="<?= @$q->url; ?>" target="_blank"><?= @$q->name; ?></a></lable>
                        </div>
                        <div class="display-url">
                            <a style="color:#246D3C;" href="<?= @$q->displayUrl; ?>" target="_blank"><?= @$q->displayUrl; ?></a>
                        </div>
                        <div class="ser-descr"> 
                            <?php echo word_limiter($q->snippet, 25); ?>
                        </div>
                        <p></p>
                    </div>   
                <?php
                }
            }?>

<?php            if(empty($ser) AND empty($library_result)){ ?>
            <div style="position: absolute;
    left: -60%;
    background: #D7242E;
    padding: 14px;
    width: 63%;
    color: #fff;
    border-radius: 69px;
    margin-top: 10%;">
                    No hits! Do this:
Copy the green text into your search
engine and find an answer!
                </div>
           <?php }
            ?>
        </div>
    </div> 
</div>