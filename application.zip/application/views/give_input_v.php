<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick-theme.css">
<script src="<?php echo base_url(); ?>assets/slick/slick.js" charset="utf-8"></script>
<style>
    .slick-slider{
        width:85%;
        margin: auto;
    }
    .follow-up-questions{
        width:85%;
        margin: auto;
    }
</style>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="home-main">
            <div class="mainbar" style="width:100%;">
                <div class="slider" id="slick">
                    <?php foreach ($comments as $row_comnt) {  //print_r(); exit;?>
                        <div id="div-slider" data-qid="<?php echo @$row_comnt['questionID']; ?>" data-a_by="<?php echo @$row_comnt['answerBy']; ?>"  >
                            <div class="art-q-div"  >
                                <div class="article-question" style="min-height: 70px;">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="q-box">Q</span>-->
                                        <p class="text-center home-q-title" style="font-size:20px;" >
                                            <?php echo @$row_comnt['questionTitle']; ?>
                                        </p>                    
                                    </div>
                                </div>
                            </div>
                            <div class="art-a-div">
                                <div class="article-answer" style="overflow: auto;font: normal 12px Helvetica;  min-height: auto;">
                                    <div class="clr"></div>
                                    <div class="comment"  > 
                                        <!--<span class="a-box">A</span>--> 
                                        <?php
                                        //echo "SELECT * FROM `tbl_mycomments` WHERE questionID = '".$row_comnt['questionID']."' AND questionBy = '".$this->session->userdata('user_id')."' AND isDeleted = 0 order by created asc "; exit;
                                        $sql_com = $this->db->query("SELECT * FROM `tbl_mycomments` WHERE questionID = '" . $row_comnt['questionID'] . "' AND questionBy = '" . $this->session->userdata('user_id') . "' AND isDeleted = 0 order by id asc ");
                                             $response_arr=[];
                                         $newsql = $this->db->query("SELECT * FROM `tbl_mycomments` WHERE questionID = '" . $row_comnt['questionID'] . "' AND questionBy = '" . $this->session->userdata('user_id') . "' AND isDeleted = 0 AND messageBy!='" . $this->session->userdata('user_id') . "' AND is_final=0 AND isRead=0 order by id asc ");
                                         $response_arr=$newsql->result_array();
                                   
                                        foreach ($sql_com->result_array() as $row_comnts) { //print_r($row_comnts); exit;
                                            if ($row_comnts['messageBy'] == $this->session->userdata('user_id')) {
                                                ?>
                                                <p class="commentbx-home" style="font-size: 18px !important;" > 
                                                    <img style="width:5%;border-radius: 50px;display: inline-block; height: 38px;" src="<?php echo base_url() . USER_IMAGE . $this->session->userdata('user_image'); ?>" alt="user-image" class="img-responsive" />
                                                    <b><?php echo @$row_comnts['comment']; ?></b>
                                                </p>
                                            <?php } else { ?>
                                                <p class="commentbx-home" style="font-size: 18px !important;" >                                                
                                                    <em><?php echo @$row_comnts['comment']; ?></em>
                                                </p>



                                              
                                                <?php
                                            }?>
                                        <?php }
                                        ?>
                                        <?php if (empty($response_arr)) { ?>
                                            <p class="commentbx-home" style="font-size: 18px !important;">                                                
                                                    <em>Waiting for a response … </em>
                                                </p>
                                                <script type="text/javascript">
                                                    setTimeout(checkResponse, 5000);
                                                    

                                                    function checkResponse() {
                                                        window.location.href="<?php echo site_url('ask_questions/give_input/');?>"
                                                    }
                                                </script>
                                       <?php } ?>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <?php if (!empty($response_arr)) { ?>
                <div class="follow-up-questions">
                    <form action="<?php echo site_url("ask_questions/submit_user_comment/" . @$comments[0]['questionID'] . "/" . @$comments[0]['answerBy']); ?>" method="post" enctype="multipart/form-data" id="form-question">
                        <input type="hidden" name="questionBy" value="<?php echo $this->session->userdata('user_id'); ?>"  />
                        <input type="hidden" name="questionID" value="<?php echo @$comments[0]['questionID']; ?>" id="iQuestionId" />
                        <input type="hidden" name="answerBy" value="<?php echo @$comments[0]['answerBy']; ?>" id="iAnswerBy" />
                        <input type="hidden" name="messageBy" value="<?php echo $this->session->userdata('user_id'); ?>" />
                        <ol>
                            <li>
                                <div style="position: relative;left: 5%;top: 85%;">
                                    <img style="height: 38px;width:4.5%;top: 10px;border: 1px solid;position: absolute;" src="<?php echo base_url() . USER_IMAGE . $user_pro->user_image; ?>" class="img-circle" />
                                </div>
                                <input placeholder="Please write your response and press ‘enter’"  autocomplete="off" id="tags" class="input_question" name="comment" type="text"  style="padding: 0 87px;font-size: 21px;background-color: #ffffffa1 !important;height:60px; text-align: left;"   required />
                                <ul class="sugestion-tag" id="sugestion-tag" style="width:43%;"></ul>
                            </li>                
                            <li>
                                <div class="clr"></div>
                            </li>
                        </ol>
                    </form>
                </div>
                <?php
            }
            ?>
        </div>

        <?php include 'footer_tabs.php'; ?>
        <?php include 'common.php'; ?>
        <script>

            function getSugVal(val) {
                $('#tags').val(val);
                $('.sugestion-tag').hide();
            }
            $(document).ready(function () {

                $('input').keypress(function (e) {
                    if (e.which == 13) {
                        $('form#form-question').submit();
                        return false;    //<---- Add this line
                    }
                });

                $('#ichk_int').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });
                $('#ichk_lib').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });

                // $("#tags").on('keyup', function () {
                //     var q = this.value;
                //     var formData = new FormData();
                //     formData.append('q', q);
                //     $.ajax({
                //         url: '<?php echo site_url("ask_questions/get_sugestion/"); ?>',
                //         type: "POST",
                //         data: formData,
                //         contentType: false,
                //         cache: false,
                //         processData: false,
                //         success: function (data)
                //         {
                //             $('.sugestion-tag').show();
                //             $('#sugestion-tag').html(data);
                //         }
                //     });
                // });

                $('.slider').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                    infinite: true,
                    cssEase: 'linear',
                    autoplay: false
                });

                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);

                $('#slick').on('afterChange', function (event, slick, currentSlide, nextSlide) {
                    var $slides = $('#slick').slick("getSlick").$slides;
                    //alert($slides.eq(currentSlide).find('div div').attr('data-qid')); 
                    $('#iQuestionId').val($slides.eq(currentSlide).find('div div').attr('data-qid'));
                    $('#iAnswerBy').val($slides.eq(currentSlide).find('div div').attr('data-a_by'));

                });
            });
        </script>
