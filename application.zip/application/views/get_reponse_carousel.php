<div class="slider" id="slick">
              
                        <div id="div-slider" data-qid="" data-a_by=""  >
                            <div class="art-q-div"  >
                                <div class="article-question" style="min-height: 70px;">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="q-box">Q</span>-->
                                        <!-- <p class="text-center home-q-title" style="font-size:20px;" >
                                          Thanks! I will get back to you within a few minutes.
                                        </p> -->
                                        <textarea placeholder="Thanks! I will get back to you within a few minutes." autocomplete="off" id="" class="input_ask_textarea" name="questionTitle" required="" style="height: auto;"></textarea>                    
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                         <div id="div-slider" data-qid="" data-a_by=""  >
                            <div class="art-q-div"  >
                                <div class="article-question" style="min-height: 70px;">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="q-box">Q</span>-->
                                        <!-- <p class="text-center home-q-title" style="font-size:20px;" >
                                          Click “Progress” below to track your question.
                                        </p> -->  
                                        <textarea placeholder="Click “Progress” below to track your question." autocomplete="off" id="" class="input_ask_textarea" name="questionTitle" required="" style="height: auto;"></textarea>                  
                                    </div>
                                </div>
                            </div>
                           
                        </div>

                        <div id="div-slider" data-qid="" data-a_by=""  >
                            <div class="art-q-div"  >
                                <div class="article-question" style="min-height: 70px;">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="q-box">Q</span>-->
                                        <!-- <p class="text-center home-q-title" style="font-size:20px;" >
                                         Click “Give input” below when it lights-up orange.
                                        </p> -->
                                        <textarea placeholder="Click “Give input” below when it lights-up orange." autocomplete="off" id="" class="input_ask_textarea" name="questionTitle" required="" style="height: auto;"></textarea>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                    
                </div>

                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script src="<?php echo base_url(); ?>assets/slick/slick.js" charset="utf-8"></script>
                <script type="text/javascript">
                    $('.slider').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                    infinite: true,
                    cssEase: 'linear',
                    autoplay: false
                });
                </script>