<?php ini_set(error_reporting(0)); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
         <link rel='icon' href="<?php echo base_url(); ?>uploads/doc_image/sokrates_app_logo.png" type='image/png'/ >
        <!--        bootstrap live link   start -->
        <link href="<?php echo base_url(); ?>assets/css/responsive-login.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link href="<?php echo base_url(); ?>assets/css/login.css" rel="stylesheet" type="text/css" />
        <style>
            input:-webkit-autofill {
                -webkit-box-shadow: 0 0 0 30px white inset;

            }              
            .form-control:focus {
                border-color: #fff;
                -webkit-box-shadow: white !important;
            }
            input:-webkit-autofill {
                -webkit-text-fill-color: #7C7C7C !important;
                -webkit-text-fill-font-size: 15px !important;
            }
        </style>
    </head>
    <body>  
        <div class="main">
            <div class="container">
                <div class=" createForm main-row">
                  
                    <h2 class="createId_title">Create your Sokrates ID</h2>
                          <div class="row">
                                <?php if ($this->session->flashdata('register_error')) : ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-success" role="alert" style="color:#5DB166;">
                                            <?php echo $this->session->flashdata('register_success'); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                                    <form class="form-horizontal" action="<?= base_url();?>create_sokrets_id" method="post"  onsubmit="return checkForm(this);">
                                      <div class="formContent">
                                      <div class="createSignIn">
                                          <p>Your Sokrates ID gives access to all our services.<br>
            Already have a Sokrates ID? <a href="<?php echo base_url(); ?>">Sign in</a></p>
                                      </div>
                                      <div class="form-group">
                                        
                                        <div class="col-sm-6">
                                          <input type="text" class="form-control"  placeholder="First Name" name="first_name" required>
                                        </div>
                                        <div class="col-sm-6">          
                                          <input type="text" class="form-control"  placeholder="Last Name" name="last_name" required>
                                        </div>

                                      </div>
                                     

                                      <div class="form-group">
                                        <label class="control-label col-sm-12" for="pwd">Country/Region</label>
                                        <div class="col-sm-12">          
                                          
                                          <select class="form-control" name="country" required>
                                              <option></option>
                                            <?php foreach ($countries as $key => $value) { ?>
                                             <option value="<?php echo $value['alpha2Code'];  ?>"><?php echo $value['name'];  ?></option>
                                         <?php   } ?>
                                          </select>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <div class="col-sm-12">          
                                            <input type="email" class="form-control"  placeholder="name@example.com" name="email" required>
                                          <span class="idText">This will be your Sokrates ID</span>

                                          </div>
                                          
                                        </div>

                                       <div class="form-group">
                                        <div class="col-sm-12">          
                                          <input type="password" class="form-control" id="password" placeholder="password" name="password" required>
                                        </div>
                                      </div>

                                       <div class="form-group">
                                        <div class="col-sm-12">          
                                          <input type="password" class="form-control" id="confirm_password" placeholder="confirm password" name="confirm_password" required>
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <div class="col-sm-12">          
                                          <div class="termOfUseLink">
                                            <p>
                                            
                                            <label class=" checkbox-inline qcustom-check">
                                                <input id="ichk_lib" name="remember_me" class="form-control"  type="checkbox" value="yes" >
                                                <span class="qcheckmark"></span>
                                            </label>
                                            I have read and agree to the 
                                              <a href="<?php echo site_url('login_c/terms'); ?>" target="_blank">Terms of Use</a>
                                              and
                                              <a href="<?php echo site_url('login_c/privacy'); ?>" target="_blank">Privacy Policy</a>
                                              </p>




                                          </div>
                                        </div>
                                      </div>

                                       
                                     
                                      <!-- <div class="form-group">        
                                        <div class="col-sm-offset-2 col-sm-10">
                                          <button type="submit" class="btn btn-default">Submit</button>
                                        </div>
                                      </div> -->
                                    </div>
                                    <div class="btnRow">
                                         <a href="<?= base_url();?>"><button type="button" class="btn btn-default">Cancel</button></a> 
                                         <button type="submit" class="btn btn-default submitBtn">Submit</button>
                                    </div>
                    </form>
                  
            </div>
        
        </div>

        <script type="text/javascript">
            var password = document.getElementById("password")
var confirm_password = document.getElementById("confirm_password");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
        </script>
         <script type="text/javascript">

  function checkForm(form)
  {
 //alert("Please indicate that you accept the Terms and Conditions");
    if(!form.remember_me.checked) {
      alert("Please indicate that you accept the Terms and Privacy");
      //form.terms.focus();
      return false;
    }
    return true;
  }

</script>
    </body>
</html>

