<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--        bootstrap live link   start -->
        <!--<link href="<?php echo base_url(); ?>assets/css/responsive-login.css" rel="stylesheet" type="text/css" />-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!--  end-->
       <!--<link rel="stylesheet" href="<?php echo base_url(); ?>assets/drag_and_drop/css/style.css" />-->
        <link href="<?php echo base_url(); ?>assets/css/login.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
        <style>
           
        </style>
    </head>
    <body id="body">     
        <div id="MenuPopup" class="sidenav">
            <!--            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>           
                        <div class="container-sokrates">
                            <div class="row"  class="data-div" id="data-div">
            
                            </div>
                        </div>-->
        </div>
        <!-- START PAGE SOURCE -->
        <?php
        if (@$this->session->userdata('user_id') != "") {
            $uid = $this->session->userdata('user_id');
            $sql_q = "SELECT count(*) as q_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa";
            //$sql_q = "SELECT COUNT(id) as q_count FROM `questions` WHERE userID = $uid AND isRead = 0 AND isDeleted = 0";
            $query_q = $this->db->query($sql_q);
        }
        ?>  
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>

                            <!--<li id="LOGIN"><a href="<?php echo site_url("login_c"); ?>">Login</a></li>-->                      

                        </ul>
                    </div>
                    <div class="logo">
                        <div class="col-lg-12" class="noPadding" style="width: 86%;">
<!--                            <span class="logo-text">SOKRATES</span>-->
                            <!--<a href="<?php echo site_url("Login_c"); ?>"><img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a> <small></small>-->
                        </div>
                        <div class="col-lg-6" class="noPadding" style="text-align:center;">
                            <!--<span class="opennav"  onclick="openNav();">&#9776;</span>-->
                        </div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <div class="content_resize" style="width: 71%;">
                    <div class="mainbar" style="">
                        <!--            <div class="article">
                                        <h2><span>Contact</span></h2>
                                        <div class="clr"></div>
                                        <p>You can find more of my free template designs at my website. For premium commercial designs, you can check out DreamTemplate.com.</p>
                                    </div>-->
                        <img src="<?php echo base_url() . IMAGE_COM . '/login-logo.png' ?>" class="img-responsive" />
                        <h2 class="text-center" style="color:#fff;padding-bottom: 0;">Sign in to Sokrates </h2>

                        <div class="login-section" >
                            <div class="clr"></div>
                            <div class="responseMsg"></div>
                            <div class="row">
                                <?php if ($this->session->flashdata('register_success')) : ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-success" role="alert" style="color:#5DB166;">
                                            <?php echo $this->session->flashdata('register_success'); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php
                            if ($this->session->flashdata('error')) {
                                echo '<span style="color:#ff0000c7;padding-left: 8px;">' . $this->session->flashdata('error') . '</span>';
                            }
                            ?>
                            <form action="<?php echo site_url("login_c/check_login"); ?>" method="post" id="sendemail">
                                <div class="col-lg-12 noPadding login-form" >
                                    <div class="form-group login-id-div" >
                                        <input placeholder="Sokrates ID" class="login-input" id="email" name="email" class="text"   />
                                    </div>
                                    <div class="form-group login-pass-div" >
                                        <input placeholder="Password" class="login-input" id="password" type="password" name="password" class="text"  />
                                    </div> 
                                    <div class="login-btn-div">
                                        <button class="login-btn-new" type="submit">
                                            <!--<i  class="fa fa-arrow-circle-o-right"></i>-->
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-12 noPadding text-center" style="margin-top: 7px;">
                            <a data-toggle="modal" data-target="#forgotPasswordModal" style="text-decoration: none;color:#fff;" class="" href="">Forgot Sokrates ID or password?</a>
                            <div class="clr"></div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="forgotPasswordModal" role="dialog">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Please enter your email address </h4>
                                </div>
                                <form action="<?php echo site_url("register/submit_email/"); ?>" method="post" enctype="multipart/form-data" id="form-forgot-pass">
                                    <div class="modal-body" style="padding: 50px 30px;">
                                        <label for="email">Email (required)</label>
                                        <input type="email" required class="form-control frm-l-s" name="user_email"  />
                                    </div>
                                    <div class="modal-footer">
                                        <button style="background-color: #E40613;color: #fff;" id="submit-email" class="btn" type="submit" name="submit" >Submit</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>   
        </div>
    </body>
</html>

