<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/nav.css">
<a href="javascript:void(0)" onclick="closeNavSideMenu()">
    <img class="close-btn-png nav-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
</a>
<!--<h4 style="padding: 19px 41px;
    color: #DA2129;
    font-size: 23px;
    font-weight: bold;">SOKRATES</h4>-->
<div class="" style="margin: 26px 30px;
     position: relative;
     width: 100%;">
    <a href="<?php echo site_url("Login_c"); ?>"><img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a>  
</div>

<div class="col-lg-12">
    <div class="navigation">
        <ul>
            <li class="subSideNav"> 
                <a href="#" class="">home</a>
                <ul>
                    <li> 
                        <a href="javascript:void(0)" onclick="answerer();" >Answerer</a>                       
                    </li>
                    <li> 
                        <a href="javascript:void(0)"  onclick="answerSource();" >Answer source</a>                       
                    </li>
                    <li> 
                        <a href="javascript:void(0)">Give input</a>                       
                    </li>
                    <li> 
                        <a href="javascript:void(0)" onclick="progressPage();">Progress</a>                       
                    </li>
                    <li> 
                        <a href="<?php echo site_url('ask_questions/question_answer'); ?>">New answers</a>                       
                    </li>
                   
                </ul>
            </li>
            <li class="subSideNav"> 
                <a href="#" class="">MyQuestions</a>
                <ul>
                    <li> 
                        <a href="javascript:void(0)" onclick="openPop('My_Questions');">Questions</a>                       
                    </li>
                    <li> 
                        <a href="javascript:void(0)" onclick="openNav('New_answer');">New answers</a>                       
                    </li>
                    <li> 
                        <a href="javascript:void(0)" onclick="openNav('Progress');">Progress</a>                       
                    </li>
                   
                </ul>
            </li>

            <li class="subSideNav"> 
                <a href="#" class="">BookShelf</a>
                <ul>
                    <li> 
                        <a href="javascript:void(0)" onclick="openNav('My_Library');">Expand BookShelf</a>                       
                    </li>                   
                </ul>
            </li>

            <li class="subSideNav"> 
                <a href="#" class="">Account</a>
                <ul>
                    <li> 
                        <a href="javascript:void(0)">Settings</a>                       
                    </li>
                    <li> 
                        <a href="<?php echo site_url('register/my_profile/'); ?>">Personal information</a>                       
                    </li>
                    <li> 
                        <a href="<?php echo site_url('subscription/'); ?>">Manage Subscription</a>                       
                    </li> 
                    <li> 
                        <a href="<?php echo site_url('change_password/'); ?>">Change password</a>                       
                    </li>  
                    <li> 
                        <a href="<?php echo site_url('logout/'); ?>">Logout</a>                       
                    </li> 

                </ul>
            </li>

            <li class="subSideNav"> 
                <a href="#" class="">Sokrates </a>
                <ul>
                    <li> 
                        <a href="javascript:void(0)">About us</a>                       
                    </li>
                    <li> 
                        <a href="<?php echo site_url('login_c/terms'); ?>">Terms of use</a>                       
                    </li>
                    <li> 
                        <a href="<?php echo site_url('login_c/privacy'); ?>">Privacy</a>                       
                    </li>
                                    
                </ul>
            </li>
           
        </ul>
    </div>
</div>
<script>
    function openPop(val) {
        if (val == 'My_Questions') {
            var url = '<?php echo site_url("ask_questions/get_my_question/"); ?>'
            var var_html = 'MenuPopup';
        }
        if (val == 'My_Library') {
            var url = '<?php echo site_url("my_files/get_my_files/"); ?>'
            var var_html = 'MenuPopupLib';
        }

        $.ajax({
            url: url,
            type: "POST",
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { //alert(data);
                $("#" + var_html).html(data);
                document.getElementById("iNavSideMenu").style.width = "0";
                document.getElementById(var_html).style.width = "85%";
            }
        });
    }
    
</script>