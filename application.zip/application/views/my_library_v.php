

<link rel="stylesheet" href="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.css">
<link class="ui-theme" rel="stylesheet" href="<?php echo base_url(); ?>assets/resize/docs/css/jquery-ui.min.css">
<script src="<?php echo base_url(); ?>assets/resize/docs/js/jquery-ui.min.js"></script>

<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/resize/docs/js/jquery-latest.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
<!-- Demo stuff -->

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/resize/docs/css/jq.css">
<link href="<?php echo base_url(); ?>assets/resize/docs/css/prettify.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/resize/docs/js/prettify.js"></script>
<script src="<?php echo base_url(); ?>assets/resize/docs/js/docs.js"></script>

<!-- Tablesorter: required -->
<!--<link rel="stylesheet" href="<?php echo base_url(); ?>assets/resize/css/theme.blue.css">-->
<script src="<?php echo base_url(); ?>assets/resize/js/jquery.tablesorter.js"></script>
<script src="<?php echo base_url(); ?>assets/resize/js/widgets/widget-resizable.js"></script>
<script src="<?php echo base_url(); ?>assets/resize/js/widgets/widget-storage.js"></script>
<script id="js">$(function () {

        $('.full-width-table').tablesorter({
            //theme: 'blue',
            // initialize zebra striping and resizable widgets on the table
            widgets: ['resizable'],
            widgetOptions: {
                resizable: true,
                // These are the default column widths which are used when the table is
                // initialized or resizing is reset; note that the "Age" column is not
                // resizable, but the width can still be set to 40px here
                resizable_widths: ['10%', '10%', '40px', '10%', '100px']
            }
        });

    });</script>
<style>
    .dropzone {
        background: #fff;
        border: 2px dashed #bdbcbc;
        border-radius: 5px;
    }

    .dz-message {
        color: #999;
    }

    .dz-message:hover {
        color: #464646;
    }

    .dz-message h3 {
        font-size: 200%;
        margin-bottom: 15px;
    }

    .dropzone .dz-preview .dz-remove {
        color: blue !important;
    }
    .nav-tabs>li>a{
        padding: 10px 16px;
        font-size: 14px;
    }
    td, th {
        padding: 6px;
    }
    tr td{    font-size: 13px;}
    /*05.11.2018*/
    .nav-tabs>li>a:hover {
     border-color: #fff #fff #ddd; 
}

.nav>li>a:focus, .nav>li>a:hover {
    text-decoration: none;
     background-color: #fff; 
}
.file_iocn img{
    width: 100%;
    height: 100%;
    object-fit: cover;
}

</style>
<a href="javascript:void(0)" class="" onclick="closeNav('MenuPopupLib')">
    <img  class="close-btn-png lib-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" />
</a>           
<div class="container-sokrates bookShelf clearfix ">
    <div class="col-lg-12  question-div clearfix" >
        <div class="col-sm-4 col-md-4 col-lg-5 noPadding question-title-div" >
            <h3>BookShelf</h3>
            <small class="smallText"><?php echo @$used_space; ?>Your BookShelf can now <br>
answer <span class="counterIncicator"><?php echo round($word_count/50) ; ?></span> questions </small>
        </div>
        <div class="col-sm-8 col-md-8 col-lg-7 noPadding "  >
            <!-- tabs -->
                    <div class="tab">
                      <button class="tablinks leftBtn" onclick="openTab(event, 'Icon')" id="defaultOpen">Icon</button>
                      <button class="tablinks rightBtn" onclick="openTab(event, 'List')" id="rightBtn1">List</button>
                    </div>
            <!-- /tabs -->
            <div class="question-ser-div">
                <i class="fa fa-search my-q-ser-icon"></i>
                <input id="iSearch" onkeyup="commnFunLibrary('ser');" type="text"  name="ser" class="form-control my-q-ser" placeholder="BookShelf Search" />
            </div>
        </div>
    </div>
    <div class="col-lg-12 q-and-answer" style="width: 100%;" > 
        <div  class="col-md-12" id="SUCMSG" style="padding: 0;">          

        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <!-- <div class="col-lg-12 noPadding"> -->
                    <!-- <ul class="nav nav-tabs">
                        <li id="act1" class="active"><a id="t1" data-toggle="tab" href="#tab1">Upload Files</a></li> -->
                       <!--  <li id="act2"><a id="t2" data-toggle="tab" href="#tab2">Add Tag</a></li> -->
                    <!-- </ul> -->
                    <!-- <div class="tab-content"> -->
                        
                  <!--       <div id="tab2" class="tab-pane fade">
                            <span>&nbsp;</span>
                            <form id="file_submit" method="post" enctype="multipart/form-data" action="">
                                <input type="hidden" name="file_names" id="f_name_arr" />
                                <div class="col-lg-12 noPadding" style="border-bottom: 1px solid #DDDDDD;">
                                    <div class="col-lg-6" style="padding: 8px 15px;">
                                        <div class="form-group">
                                            <label style="margin-bottom: 0px;" for="comment">Apply Tag</label>
                                            <div id="taglist">
                                                <div class="checkbox">
                                                    <label>
                                                        <input style="cursor: pointer;" id="maincheckbox" type="checkbox" onclick="addTag(this)">
                                                        <input style="height: 28px;" type="text" name="tagName[]" id="tagname" class="form-control frm-l-s">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6" style="padding: 8px 15px;">
                                        <div class="form-group">
                                            <label for="comment">Comment:</label>
                                            <textarea name="comment" class="form-control" rows="4" id="comment" ></textarea>
                                        </div>
                                    </div>
                                </div> 
                                <button  style="color: #fff;background-color:#E40613;float: right;margin-top: 10px" class="btn" type="submit">Submit Files</button>
                                <button type="button" class="btn" id="file_prev" style="background-color:#E40613;color: #fff;margin-right: 0;cursor: pointer;float: right;margin-top: 10px;margin-right: 8px;"> Previous</button>
                            </form>
                        </div> -->
                    <!-- </div> 
                </div>-->
                <div style="clear: both" id="container">
<!-- 
                    <h5 class="lib-title" style="display: inline-block;margin-top: 10px;">My Library has <?php echo @$files_count; ?> files</h5>
 -->

 <div style=" text-align: center; font-size: 21px;font-weight: bold;" id="expand_lib">Expand BookShelf</div>
                            <div class="drop_docTitle">Drop new documents below, to expand your knowledge center.</div>
                    <div class="clr"></div>


<!-- drop tab -->
                            <div id="tab1" class="tab-pane fade in active dragDropSec" <?php if (count($library_data)>0) { ?>style="display: none;" data-isdisplay='N'
                          <?php  }else{ ?>  data-isdisplay='Y' <?php } ?>  data-isdisplay='N'>
                            <!-- <span>&nbsp;</span> -->
                            <form id="file_submit" method="post" enctype="multipart/form-data" action="">
                            <div id="content">
                                <div id="my-dropzone" class="dropzone" style="border-style: dashed;">
                                    
                                     <div class="dz-message">
                                            
                                            <div class="plusIconBlock">
                                                <i class="fa fa-plus-circle" ></i>
                                            </div>
                                            <div class="dropText">

                                                <!-- <h3>Drop files here</h3> or <strong>click</strong> to upload -->
                                                <h3>Add documents by dropping <br> them here!</h3>
                                            </div>
                                        </div>

                                </div>
                            </div>
                            <button  type="submit" class="btn" id="file_next" style="background-color:#E40613;color: #fff;margin-right: 0;cursor: pointer;float: right;margin-top: 10px; padding: 7px 30px; display: none;"> Submit</button>
                        </form>
                        </div>
                            <!-- drop tab -->

                    
<!-- tab content -->
<div id="tablecontainer"> 
                        <!-- tab 1 -->
                        <div id="Icon" class="tabcontent">
                            
                          <div class="iconFile pos-rel" id="documentsDiv">
                            




<?php  foreach ($library_data as $row => $v) {  ?>

 <div class="fileContent">
                                <a href="<?php echo base_url() . USER_FILES . $library_data[$row]['file_name']; ?>" target="_blank" >

                                    <div class="file_iocn">
                                     
                                      <img src="<?php echo $library_data[$row]['thumbnil']; ?>">
                                    </div>
                                    <div class="fileTitle" style="word-wrap: break-word; "><?php echo $library_data[$row]['file_name']; ?></div>
                                </a>
                            </div>

<?php } ?>

                            
                            <!-- <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div> -->
                          </div>
                        </div>
                        <!-- / tab 1 -->

                        <!-- tab 2 -->
                        <div id="List" class="tabcontent">
                            <!-- <div class="drop_docTitle">Drop new documents from your computer in the box
below to expand your knowledge base</div> -->
                          <div class="comment" style="padding:0 !important;"> 
                           <!-- this class commited  class="table-responsive" -->
                        <div class="scroll-Table-Block">
                            <div id="SUCMSG1"></div>
                            <table class="c-librari-tbl table-striped full-width-table" id="refresh_file_table">
                                <thead>
                                    <tr>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid">File Name</th>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;">Tag
                                        </th>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;">Comment</th>
                                        <th   style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;" id="date_column">Date</th>
                                        <th class="resizable-false" style="border-bottom:#939393 1px solid;border-top:#939393 1px solid;">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="_editable_table">
                                    <?php
//                                    $id = $this->session->userdata('user_id');
//                                    $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id =  $id  and isDeleted = 0 order by id desc ");
//                                    $library_data = $sql->result_array();
                                    foreach ($library_data as $row => $v) {
                                        ?>
                                        <tr>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'file_name', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                 <?php echo $library_data[$row]['file_name']; ?> 
                                            
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'tagName', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php echo @$library_data[$row]['tagName']; ?>
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'comment', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php echo @$library_data[$row]['comment']; ?>
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'created', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php
                                                //echo date('j F, Y', strtotime(@$row['created'])); 
                                                echo date('d/m/Y', strtotime(@$library_data[$row]['created']));
                                                ?>
                                            </td>
                                            <td> 
                                                <a href="javascript:void(0)" onclick="commnFunLibrary('deleteLib-<?php echo @$library_data[$row]['id']; ?>');" ><i class="fa fa-trash-o"></i></a> 
                                            </td>                                        
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                        </div>
                        <!-- / tab 2 -->
<!-- tab content -->
                      
                    <!-- tabs -->
</div>
                    
                </div>
            </div>
        </div>
    </div> 
</div>


 <div class="modal fade" id="upload_modal" role="dialog">
            <div class="modal-dialog modal-md" style="margin: 210px auto;width: 500px;">
                <div class="modal-content" style="display: flow-root;padding: 10px;background-color: #F6F5F7;">

                    <div class="modal-body clearfix" style="padding:0;">
                        
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    <img style="position: absolute; left: 0; width: 85%;top: 10px;" src="<?php echo base_url() . IMAGE_COM . '/login-logo.png' ?>" class="img-responsive" />
                                </div>
                                <div class="col-lg-10" style="color: #050607;">
                                    <p style="font-size: 14px; font-weight: bold;">Start answering questions with your knowledge base.</p>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <button   style="border:1px solid #D9D9DA;width: 100px;background-color: #F6F5F7;font-weight: bold;"  class="btn btn-default pull-right custom-close" >Cancel
                                            </button>
                                    </div>
                                    <div class="col-lg-6">
                                       <a href="<?php echo base_url().'ask_questions'; ?>"> <input name="allow"  style="border:1px solid #D9D9DA;width: 100px;background-color: #F6F5F7;font-weight: bold;" type="button" class="btn btn-default pull-left" value="Ok" ></a>
                                    </div>
                                </div>
                            </div>  
                        
                    </div>

                </div>
            </div>
        </div>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
<!--<script src="<?php echo base_url(); ?>vendor/jquery/jquery.min.js"></script>-->



<script src="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.js"></script>

<script>
                                                Dropzone.autoDiscover = false;
                                                var myDropzone = new Dropzone("#my-dropzone", {
                                                    url: "<?php echo site_url("images/upload") ?>",
                                                    acceptedFiles: ".pdf,.doc,.docx",
                                                    addRemoveLinks: true,
                                                    success: function () {
                                                        $("#file_next").click();

                                                    },
                                                    removedfile: function (file) {
                                                        var name = file.name;
                                                        $.ajax({
                                                            type: "post",
                                                            url: "<?php echo site_url("images/remove") ?>",
                                                            data: {file: name},
                                                            dataType: 'html',
                                                            success: function () {

                                                            }
                                                        });

                                                        var previewElement;
                                                        return (previewElement = file.previewElement) != null ? (previewElement.parentNode.removeChild(file.previewElement)) : (void 0);
                                                    },
                                                    init: function () {
                                                        var me = this;
                                                        $.get("<?php echo site_url("images/list_files") ?>", function (data) {
                                                            // if any files already in server show all here 
                                                            if (data.length > 0) {
                                                                $.each(data, function (key, value) {
                                                                    var mockFile = value;
                                                                    me.emit("addedfile", mockFile);
                                                                    me.emit("thumbnail", mockFile, "<?php echo base_url(); ?>uploads/temp/" + value.name);
                                                                    me.emit("complete", mockFile);
                                                                });
                                                            }
                                                        });
                                                    }
                                                });


                                                $(document).ready(function () {

                                                    $("#MYFILES").removeClass().addClass('active');
                                                    $('#msg').delay(4000).fadeOut();

                                                    // $("#file_next").on('click', function () {
                                                    //     $('#t1').attr("aria-expanded", "false");
                                                    //     $('#tab1').removeClass().addClass('tab-pane fade');
                                                    //     $('#act1').removeClass();
                                                    //     $('#act2').addClass('active');
                                                    //     $('#t2').attr("aria-expanded", "true");
                                                    //     $('#tab2').removeClass().addClass('tab-pane fade active in');
                                                    // });

                                                    $("#file_prev").on('click', function () {
                                                        $('#t1').attr("aria-expanded", "true");
                                                        $('#tab1').removeClass().addClass('tab-pane fade active in');
                                                        $('#act2').removeClass();
                                                        $('#act1').addClass('active');
                                                        $('#t2').attr("aria-expanded", "false");
                                                        $('#tab2').removeClass().addClass('tab-pane fade');
                                                    });

                                                    $("#file_submit").on('submit', (function (e) {
//                                                      
                                                        e.preventDefault();
                                                        $.ajax({
                                                            url: '<?php echo site_url('my_files/upload_files/'); ?>',
                                                            type: "POST",
                                                            data: new FormData(this),
                                                            contentType: false,
                                                            cache: false,
                                                            processData: false,
                                                            success: function (data)
                                                            { //alert(data);
                                                                // refresh_file_table
                                                                //$("#_editable_table").load(location.href + " #_editable_table");
                                                                $('#upload_modal').modal('show');
                                                                $("#MenuPopupLib").html(data);
                                                                // $('#SUCMSG').html('<div id="msg" class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Message:</strong> Files uploaded successfully.</div>');
                                                                // $('#msg').delay(5000).fadeOut();

                                                            }
                                                        });
                                                    }));
                                                });
                                                function addTag(val) { //alert('fghfgh');

                                                    var tagname = $("#tagname").val();
                                                    if (tagname == "") {
                                                        alert('Please fill the text field.')
                                                        $('#maincheckbox').prop('checked', false);
                                                        return false;
                                                    }
                                                    //alert($("#tagname").val());
                                                    $("#taglist").prepend("<div class='checkbox'><label><input name='tagName[]' value=" + tagname + " type='checkbox' checked >" + tagname + "</label></div>");
                                                    //val.unchecked
                                                    $('#maincheckbox').prop('checked', false);
                                                    $('#tagname').val('');
                                                }
                                                function saveToDatabase(editableObj, column, id) {
                                                    $(editableObj).css("background", "#FFF url(loaderIcon.gif) no-repeat right");
                                                    $.ajax({
                                                        url: '<?php echo site_url("my_files/update_library_data/"); ?>',
                                                        type: "POST",
                                                        data: 'column=' + column + '&editval=' + editableObj.innerHTML + '&id=' + id,
                                                        success: function () {
                                                            $(editableObj).css("background", "none");
                                                            // $('#SUCMSG1').html('<div id="msg1" class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Message:</strong> Success! updation.</div>');                                                           
                                                            // $('#msg1').fadeOut(3000);
                                                        }
                                                    });
                                                }

                                                      
                                                

                                                $('.content').click(function() {

    document.getElementById('MenuPopupLib').style.width = "0";
});

 $('#container').on(
    'dragover',
    function(e) {
       if ($("#tab1").data('isdisplay')=='N') {
            $("#tab1").attr('style','display:block');
            $('#tab1').data('isdisplay','Y');
        }
    }
)                                              

</script>
<script type="text/javascript">
$(document).on('mousemove','.tablesorter-resizable-handle', function(){
if ($(this).data('column')==3 ) {
// $(this).removeClass();
}
} ) 
    </script>
<script>

    function openTab(evt, cityName) {

      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace("active", "");
      }
      document.getElementById(cityName).style.display = "block";
    if (cityName=='Icon') {
      $("#defaultOpen").addClass("active");
    }else{
        $("#rightBtn1").addClass("active"); 
      //evt.currentTarget.className += " active";
    }
    }

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();

    $("#expand_lib").click(function(){
      
        if ($("#tab1").data('isdisplay')=='N') {
            $("#tab1").attr('style','display:block');
            $('#tab1').data('isdisplay','Y');
        }else{
             $("#tab1").attr('style','display:none');
             $('#tab1').data('isdisplay','N');
            
        }
    })



   

  
</script>


<script >
    $(function () {
        $(document).on('click','.custom-close', function() {
            $(".modal-backdrop").remove();
           $("body").removeClass();
            $('.modal').hide();
        });
    });
              
</script>