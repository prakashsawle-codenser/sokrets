<!--<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>-->
<!--<script type="text/javascript" src="<?php echo base_url(); ?>assets/nicEdit/nicEdit-latest.js"></script>--> 

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick-theme.css">

<style>
    #tags{
        height: auto;
    }
</style>
<div class="content">
    <div class="content_resize">
        <?php $uid = $this->session->userdata('user_id'); ?>
        <div class="mainbar" style="text-align: center; "  id="question_box">
            <div class="article qsk-question-section">
                <div class="clr"></div>
                <div class="row">
                    <div id="responseMsg"></div>
                    <?php if ($this->session->flashdata('error')) : ?>
                        <div style="width: 90%;" class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                        </div>  
                    <?php endif; ?>
                    <?php if ($this->session->flashdata('success')) : ?>
                        <div class="col-md-12">
                            <div class="alert alert-success alert-dismissible" style="color: #989696c7;background-color: #cccccc59;width: 90%;margin: auto;border-color:#c1c1c1;">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!--action="<?php //echo site_url("ask_questions/submit_question/");          ?>"-->
                <input type="hidden" id="isokrates_permission" value="<?=@$udata->sokrates_permission;?>" />
                <form style="margin-top: 30px;" action="" method="post" enctype="multipart/form-data" id="form-question">
                    <input type="hidden" name="userID" value="<?php echo $this->session->userdata('user_id'); ?>" />
                    <input type="hidden" name="sources" id="isources" value="" />
                    <!--<input type="hidden" name="" id="" value="" />-->
                    <!--Type your question and hit ‘enter’-->
                    <ol>
                        <li>                         
                            <textarea placeholder="Hi <?= $this->session->userdata('firstName'); ?>, please type your questions and hit enter." autocomplete="off" id="tags" class="input_ask_textarea" name="questionTitle" required  ></textarea>   
                            <!--</textarea>input_ask_textarea-->
                            <ul class="sugestion-tag" id="sugestion-tag" style="width: 71.1%;"></ul>
                        </li>
                        <li>
                            <!--<button id="submit-button" class="btn btn-success send" type="submit" style="margin-bottom: 10px;">Submit Question</button>-->
                            <!--<input type="image" name="imageField" id="imageField" src="<?php echo base_url(); ?>assets/images/submit.gif" class="send" />-->
                            <div class="clr"></div>
                        </li>
                    </ol>
                </form>
            </div>
        </div>





         <div class="mainbar" style="width:100%; display: none;" id="success_msg_box" >
                
            </div>
        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog modal-md" style="margin: 210px auto;width: 500px;">
                <div class="modal-content" style="display: flow-root;padding: 10px;background-color: #F6F5F7;">

                    <div class="modal-body" style="padding:0;">
                        <form action="<?php echo site_url('ask_questions/submit_permission'); ?>" method="post" >
                            <div class="col-lg-12">
                                <div class="col-lg-2">
                                    <img style="position: absolute; left: 0; width: 85%;top: 10px;" src="<?php echo base_url() . IMAGE_COM . '/login-logo.png' ?>" class="img-responsive" />
                                </div>
                                <div class="col-lg-10" style="color: #050607;">
                                    <p style="font-size: 14px; font-weight: bold;">Do you want to give Sokrates permission to look for answers in your BookShelf documents?</p>
                                </div>
                                <div class="col-lg-12">
                                    <div class="col-lg-6">
                                        <input name="d_allow"  style="border:1px solid #D9D9DA;width: 100px;background-color: #F6F5F7;font-weight: bold;" type="submit" class="btn btn-default pull-right" value="Don't Allow">
                                    </div>
                                    <div class="col-lg-6">
                                        <input name="allow"  style="border:1px solid #D9D9DA;width: 100px;background-color: #F6F5F7;font-weight: bold;" type="submit" class="btn btn-default pull-left" value="Ok" >
                                    </div>
                                </div>
                            </div>  
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <!--        <div class="ask_q_footer">
                    <div class="ask_q_footer_resize">
                        <div class="col-lg-12 noPadding">
                            <div id="HomeSidenav" class="ans-src-div">
                                <a href="javascript:void(0)" class="closebtn-ans-src" onclick="closeSrc()">&times;</a>
                                <div class="asq_foot_btn" >Answer Source</div>
                                <div class="ans-src-chk" style="">                    
                                    <label class="checkbox-inline qcustom-check"  >
                                        <input id="ichk_int" name="sources" type="checkbox" value="Internet" >
                                        Internet
                                        <span class="qcheckmark" ></span>
                                    </label>
                                    <label class="checkbox-inline qcustom-check" >
                                        <input id="ichk_lib" name="sources" type="checkbox" value="My Library">
                                        My Library
                                        <span class="qcheckmark" ></span>
                                    </label>
                                </div>
                            </div>
                            <div class="asq_foot_btn asq-right" onclick="openSrc()" >
                                Answer Source
                            </div>
                            <div id="HomePronav" class="home-pro-div">
        
                            </div>
                            <div class="asq_foot_btn asq-left" onclick="openPro()">
                                Progress 
                                <span class="header_q_count" style="padding: 0px 4px;">
        <?php //echo @str_pad(count($query_pc->result()), 2, "0", STR_PAD_LEFT); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>-->

        <?php include 'footer_tabs.php'; ?>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>--> 
        <?php include 'common.php'; ?>
        
        <script>
            $(window).on('load', function () {
                var per = document.getElementById("isokrates_permission").value;
                if (per == '0') {
                    $('#myModal').modal('show');
                }
            });
            $(document).ready(function () {
                $('#form-question').keydown(function () {
                    var key = e.which;
                    if (key == 13) {
                        $('#form-question').submit(); // Submit form code
                        return true;
                    }
                });
                $('input').keypress(function (e) {
                    if (e.which == 13) {
                        $('form#form-question').submit();
                        return false; //<---- Add this line
                    }
                });

                $('#ichk_int').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });
                $('#ichk_lib').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });
                $("#tags").on('keyup', function () {
                    var q = this.value;
                    var formData = new FormData();
                    formData.append('q', q);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/get_sugestion/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                            $('.sugestion-tag').show();
                            $('#sugestion-tag').html(data);
                        }
                    });
                });
                $("#ASKQUESTION").removeClass().addClass('active');
                $('.alert').delay(4000).fadeOut();
            });
            function getSugVal(val) {
                $('#tags').val(val);
                $('.sugestion-tag').hide();
            }

            
                $("textarea").on("keydown", function (e) {
                    $("#typing").val("yes");
                    if (e.altKey && e.keyCode === 13) {
                        e.preventDefault();
                        e.stopPropagation();
                        $(this).val($(this).val() + "\n");
                    } else if (e.keyCode === 13) {
                        e.preventDefault();
                        e.stopPropagation();
                        // $(this).parents('form').submit();
                        var userID = $("input[name=userID]").val();
                        var sources = $("input[name=sources]").val();
                        var questionTitle = $('textarea#tags').val();
                        var formData = new FormData();
                        formData.append('userID', userID);
                        formData.append('sources', sources);
                        formData.append('questionTitle', questionTitle);
                        $('textarea#tags').val('');
                        $.ajax({
                            url: '<?php echo site_url("ask_questions/submit_question/"); ?>',
                            type: "POST",
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (data)
                            {
                                 
                                //$('#form-question').hide(); 
                                //$('#QueMsg').show();
                                //$('textarea#tags').attr("placeholder", "Your question submited successfully");
                                  $("#question_box").attr('style','display:none;');
                                $("#success_msg_box").attr('style','width:100%;');
                              $("#success_msg_box").html(data);

                              var i=1;
                               //callanswerFromApi();
                             setInterval(function(){ if(i<3){ $(".slick-next").click(); i++;}else{
                                 window.location.href = "<?php echo site_url("ask_questions/submit_question/"); ?>"
                             } }, 4000);
                                 
                                
                                // setTimeout(function () {
                                //     window.location.href = "<?php //echo site_url("ask_questions/submit_question/"); ?>"
                                // }, 10000);
//                               $('#sugestion-tag').html(data);
                            }
                        });
                    }
                });

                function callanswerFromApi(){
                 
                    $.ajax({

                            url   : '<?php echo site_url("ask_questions/answerFromApi/"); ?>',
                            async : true //change this to false if you hate your users and want them to wait 
                        }).done(function() {
                            
                        });
                }

                $("#ichk_lib").click(function(){
                     var status="B";
                if($(this).prop("checked") == false){
                       if($("#ichk_int").prop("checked") == false){
                       alert("Atleast one checkbox should be active.");
                       $(this).prop('checked', true);
                       return false;
                   }
                   else{
                    status="I"
                   }
                   }else{
                   
                    if($("#ichk_int").prop("checked"))
                    {
                        status="Both";
                    }
                   }

                    var formData = new FormData();
                    formData.append('questionAnswerSource', status);  
                        $.ajax({
                            url: '<?php echo site_url("ask_questions/update_answer_source/"); ?>',
                            type: "POST",
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (data1)
                            { 

                
                            }
                        });

                  

                })
                $("#ichk_int").click(function(){
                      var status="I";
                     if($(this).prop("checked") == false){
                       if($("#ichk_lib").prop("checked") == false){
                       alert("Atleast one checkbox should be active.");
                       $(this).prop('checked', true);
                       return false;
                   }else{
                    status="B"
                   }
                   }else{
                  
                    if($("#ichk_lib").prop("checked"))
                    {
                        status="Both";
                    }
                   }
                      var formData = new FormData();
                    formData.append('questionAnswerSource', status);  
                        $.ajax({
                            url: '<?php echo site_url("ask_questions/update_answer_source/"); ?>',
                            type: "POST",
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (data1)
                            { 

                
                            }
                        });

                   
                })


                 $("#ichk_researcher").click(function(){
                if($(this).prop("checked") == false){
                       if($("#ichk_me").prop("checked") == false){
                       alert("Atleast one checkbox should be active.");
                       $(this).prop('checked', true);
                       return false;
                   }
                   }
                   $("#ichk_me").prop('checked', false);
                   var formData = new FormData();
                    formData.append('answerSource', 'R');  
                        $.ajax({
                            url: '<?php echo site_url("ask_questions/update_answer_source/"); ?>',
                            type: "POST",
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (data1)
                            { 

                
                            }
                        });

                })
                $("#ichk_me").click(function(){
                     if($(this).prop("checked") == false){
                       if($("#ichk_researcher").prop("checked") == false){
                       alert("Atleast one checkbox should be active.");
                       $(this).prop('checked', true);
                       return false;
                   }
                   }
                   $("#ichk_researcher").prop('checked', false);
                   var formData = new FormData();
                    formData.append('answerSource', 'A');  
                        $.ajax({
                            url: '<?php echo site_url("ask_questions/update_answer_source/"); ?>',
                            type: "POST",
                            data: formData,
                            contentType: false,
                            cache: false,
                            processData: false,
                            success: function (data1)
                            { 

                
                            }
                        });

                   
                })
    $(document).bind('keydown',function(e){
    $('#tags').focus();
   // $(document).unbind('keydown');
});
                                 

        </script>

<?php if ($this->session->userdata('login_status')=='Y') { ?>
 <script type="text/javascript">
     openNav('My_Library');
 </script>
<?php }  $this->session->set_userdata('login_status', 'N'); ?>
        