<?php
//$sql_q1 = "SELECT * FROM `answer`";
//$query_q1 = $this->db->query($sql_q1);
//$dateArray = array();
//$month_str="";
//foreach ($query_q1->result() as $row) {
//    $d = new DateTime($row->created);
//    $monthName = $d->format('F');
//    $month_str .= $monthName . ',';
//    $dateArray[$monthName][] = $row;
//}
//$month = rtrim($month_str,',');
//$monthArray = explode(',', $month);
//foreach ($monthArray as $r) {
//    echo $r . "<br>";
//    foreach ($dateArray[$r] as $d) {
//        echo $d->answer . "<br>";
//    }
//}
?>
<div id="refresh-notification">
    <?php
    if ($this->session->userdata('user_id') != "") {
        $id = $this->session->userdata('user_id');
        $uid= $this->session->userdata('user_id');
        $sql = "SELECT a.id,b.questionTitle,b.id AS qid FROM answer a, questions b WHERE a.questionBy = '" . $this->session->userdata('user_id') . "' AND a.notificationStatus = 0 and a.progress_status = 4 and a.questionID = b.id AND a.isDeleted = 0 LIMIT 1";
        $query = $this->db->query($sql);

        if ($query->num_rows() > 0) {
            //print_r($row->id); exit;
            foreach ($query->result() as $row) {
                $notimsg = "Hi, '" . $this->session->userdata('firstName') . "'. I have found an answer to your question:\n";
                $notimsg .= "“" . substr($row->questionTitle, 0, 30) . "...”";
                //$notimsg =. $row->questionTitle;
                ?>
                 <input type="hidden" value="<?php echo site_url("ask_questions/question_answer/$row->qid/$row->id"); ?>" id="redirecturl" />
                <input type="hidden" value="<?php echo @$row->id; ?>" id="nitufyid" />
                <input type="hidden" value="<?php echo @$notimsg; ?>" id="nitufymsg" />
                <?php
                $sql1 = "UPDATE `answer` SET `notificationStatus` = '1' WHERE `questionBy` = '" . $this->session->userdata('user_id') . "' and `id` = $row->id ";
                $query1 = $this->db->query($sql1);
            }
        }
        $sql_gn1 = $this->db->query("SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = '" . $this->session->userdata('user_id') . "' AND messageBy != '" . $this->session->userdata('user_id') . "' AND isRead = 0 AND isDeleted = 0 AND is_final =0  GROUP BY questionID) AS aaa");
        $give_input1 = $sql_gn1->first_row(); 
        ?>
        <input type="hidden" value="<?php echo @$give_input1->comment_count; ?>" id="hdn_rech_com_count" />
<?php
$sql_p2 = $this->db->query("SELECT a.id AS q_id,a.questionTitle,a.created AS created_datetime, b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID LEFT JOIN answer ON a.id=answer.questionID WHERE a.userID = $uid AND (answer.isRead=0 OR answer.isRead IS NULL ) AND a.isDeleted = 0 ORDER BY a.id DESC ");
$data['user_pro_data'] = $sql_p2->result_array();

  $sql_q = "SELECT count(*) as q_count FROM questions INNER JOIN answer on questions.id=answer.questionID WHERE answer.isDeleted = 0 and answer.isRead = 0 AND answer.questionBy = $uid AND answer.replyType = 'Answer' ORDER BY answer.id  ";
          
  $query_q = $this->db->query($sql_q);
 $my_question_counter= $query_q->first_row()->q_count;
 ?>
 <input type="hidden" name="" id="typing" value="no">
 <input type="hidden" value="<?php echo count($data['user_pro_data']); ?>" id="hidden_progress" />
 <input type="hidden" value="<?php echo $my_question_counter; ?>" id="hidden_my_question_counter" />
 <div style="display: none;" id="progress_div_contents">
     <?php  $this->load->view('footer_progress_v', $data); ?>
 </div>

    <?php }
    ?>  
</div>
<script>
    navigator.sayswho = (function () {
        var ua = navigator.userAgent, tem,
                M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
        if (/trident/i.test(M[1])) {
            tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
            return 'IE ' + (tem[1] || '');
        }
        if (M[1] === 'Chrome') {
            tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
            if (tem != null)
                return tem.slice(1).join(' ').replace('OPR', 'Opera');
        }
        M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
        if ((tem = ua.match(/version\/(\d+)/i)) != null)
            M.splice(1, 1, tem[1]);
        return M.join(' ');
    })();
    var bro_ver = navigator.sayswho;
    var res_bro = bro_ver.split(" ");
    if (res_bro[0] == 'Safari' && res_bro[1] < 11) {
        window.location.href = '<?php echo site_url("ask_questions/update_version/"); ?>';
    }

    var auto_refresh = setInterval(
    function ()
    {
        $("#refresh-notification").load(location.href + " #refresh-notification");
//                $("#iInputCount1").load(location.href + " #iInputCount1");
//                $(".divGiveInput").load(location.href + " .divGiveInput");
        var nid = $('#nitufyid').val(); //alert(nid);
        if (nid != "" && nid != undefined) {
            notifyMe($('#nitufymsg').val())

            if (window.location.href=='https://demo.sokrates.ai/ask_questions') {
               
                if($("#typing").val()=='no'){
                     window.location.href = $("#redirecturl").val();
                }
            }
            $('#nitufyid').val("");
            $("#progress_div_container").html($("#progress_div_contents").html())
        }
        var hdn_rech_com_count = $('#hdn_rech_com_count').val();
        if (hdn_rech_com_count != "0" && typeof hdn_rech_com_count !== "undefined") {
            $("#iGiveInput1").css("background-color", "#F39A38");
            $("#iGiveInput1").css("pointer-events", "auto");   
            $("#iGiveInputTitle").css("color", "#fff");
            $("#iGiveInputNum").html(hdn_rech_com_count);
            $('#iGiveInputNum').addClass('header_q_count');
            $("#iGiveInputNum").show();
        }

        var progress_counter=$("#hidden_progress").val();
        var progress_counter_current=$("#progress_counter").html();
        progress_counter_current=progress_counter_current.trim();
     
        if (progress_counter!=progress_counter_current && typeof progress_counter !== "undefined" ) {
            $("#progress_counter").html(progress_counter);
            $("#progress_div_container").html($("#progress_div_contents").html());
        }

        var myquestion_current_counter=$("#myquestion_counter").html();
        var my_question_counter=$("#hidden_my_question_counter").val();
        myquestion_current_counter=myquestion_current_counter.trim();
        
        if (myquestion_current_counter!=my_question_counter) {
                $("#myquestion_counter").html(my_question_counter);
                var html_str='<span class="header_q_count" style="padding: 1px 2px;position: relative;" id="newanswer_counter">'+my_question_counter+'</span>';
                if (Number(my_question_counter)>0) {
                    $("#newanswer_an").attr('style','color: #656564; text-decoration: none;');
                     $("#newanswer_an").attr('disable','false');
                }
                    
                $("#new_anscount").html("New Answer "+html_str);
        }

    }, 1000); // refresh every 10000 milliseconds
$(".iProgress-sub").click(function(){
    
     $("#progress_div_container").html($("#progress_div_contents").html());
})
    $(document).ready(function () {
        // myquestion
        $('#MenuPopup').click(function (e) {
            e.stopPropagation(); //alert('div');
        });
        $("#MYQUESTION").click(function (e) {
            e.preventDefault();
            e.stopPropagation(); //alert('btn');
        });
        // AnswerSource
        $(".iAnswerSource-sub").click(function (e) {
            e.preventDefault();
            e.stopPropagation(); //alert('btn');
        });
        $('#iAnswerSource').click(function (e) {
            e.stopPropagation(); //alert('div');
        });
        // Progress
        $(".iProgress-sub").click(function (e) {
            e.preventDefault();
            e.stopPropagation(); //alert('btn');
        });
        $('#iProgress').click(function (e) {
            e.stopPropagation(); //alert('div');
        });
        // my library
        $("#MYLIBRARY").click(function (e) {
            e.preventDefault();
            e.stopPropagation(); //alert('btn');
        });
        $('#MenuPopupLib, #my-dropzone').click(function (e) {
            e.stopPropagation(); //alert('div');
        });

         $('#iNavSideMenu').click(function (e) {
            e.stopPropagation(); //alert('div');
        });
         $(".opennav").click(function(e){
            e.stopPropagation();
         })

        $(document).click(function () {
            $("#typing").val('no');
            $("#MenuPopup").css("width", "0px");
            $("#iAnswerSource").removeClass("upAnswerSource");
            $("#iAnswerSource").addClass("defaultAnswerSource");
            $('.iCloseAnswerSource').hide();
            //$("#iProgress").removeClass("upProgress");
            //$("#iProgress").addClass("defaultProgress");
            //$('.iCloseprogress').hide();
            $("#USERM1").attr('class','dropdown');
            $('#iNavSideMenu').css("width", "0px");
            // $("#MenuPopupLib").css("width", "0px");
            //alert('window');
        });
    });

    function notifyMe(msg) {
        // Let's check if the browser supports notifications
        if (!("Notification" in window)) {
            alert("This browser does not support desktop notification");
        }

        // Let's check if the user is okay to get some notification
        else if (Notification.permission === "granted") {
            // If it's okay let's create a notification
            var options = {
                body: msg,
                icon: "<?php echo base_url() . IMAGE_COM . "noti-logo.png"; ?>",
                dir: "ltr"
            };
            var notification = new Notification("Sokrates", options);
            notification.onclick = function () {
                 window.location.href = "<?php echo site_url("ask_questions/question_answer/"); ?>"
            };
        }

        // Otherwise, we need to ask the user for permission
        // Note, Chrome does not implement the permission static property
        // So we have to check for NOT 'denied' instead of 'default'
        else if (Notification.permission !== 'denied') {
            Notification.requestPermission(function (permission) {
                // Whatever the user answers, we make sure we store the information
                if (!('permission' in Notification)) {
                    Notification.permission = permission;
                }

                // If the user is okay, let's create a notification
                if (permission === "granted") {
                    var options = {
                        body: msg,
                        icon: "<?php echo base_url() . IMAGE_COM . "noti-logo.png"; ?>",
                        dir: "ltr"
                    };
                    var notification = new Notification("Sokrates", options);
                }
            });
        }
        // At last, if the user already denied any notification, and you
        // want to be respectful there is no need to bother them any more.

//            if (permission === "granted") {
//                    var options = {
//                        body: "This is the body of the notification",
//                        icon: "",
//                        dir: "ltr"
//                    };
//                    var notification = new Notification("Hi there", options);
//                }
    }

    function deleteQuestion($qid){
         var formData = new FormData();
        formData.append('qid', $qid);
        
        $.ajax({
            url: '<?php echo site_url("Ask_questions/delete_question_per"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data1)
            { 
               $("#qblock"+$qid).attr('style','display:none'); 
            }
        });

    }
    function progressPage() {
        closeNav('MenuPopup');
        //closeNavSideMenu();
        $("#iProgress").addClass("upProgress");
        $("#iProgress").removeClass("defaultProgress");
        $('.iCloseprogress').show();
    }
     function answerSource() {
        closeNav('MenuPopup');
        //closeNavSideMenu();
        $("#iAnswerSource").addClass("upAnswerSource");
            $("#iAnswerSource").removeClass("defaultAnswerSource");
    }
    function answerer() {
        closeNav('MenuPopup');
         $("#answerer").addClass("upAnswerSource");
            $("#answerer").removeClass("defaultAnswerSource");
            $('.iCloseanswerer').show();
    }


     

    function openNav(val) {
        if (val == 'My_Questions') {
            var url = '<?php echo site_url("ask_questions/get_my_question/"); ?>';
            var var_html = 'MenuPopup';
            $("#typing").val('yes');
        }
        if (val == 'New_answer') {
            var url = '<?php echo site_url("ask_questions/get_new_answer/"); ?>';
            var var_html = 'MenuPopup';
             $("#typing").val('yes');
        }
        var res = val.split("-");
        if (res[0] == 'Seen_It') {
            var url = '<?php echo site_url("ask_questions/seen_new_answer/"); ?>' + res[1];
            var var_html = 'MenuPopup';
        }
        var res = val.split("-");
        if (res[0] == 'Delete_It') {
            var url = '<?php echo site_url("ask_questions/delete_seen_answer/"); ?>' + res[1];
            var var_html = 'MenuPopup';
        }
        if (val == 'Progress') {
            var url = '<?php echo site_url("ask_questions/get_progress_result/"); ?>';
            var var_html = 'MenuPopup';
             $("#typing").val('yes');
        }
        if (val == 'My_Library') {
            var url = '<?php echo site_url("my_files/get_my_files/"); ?>'
            var var_html = 'MenuPopupLib';
             $("#typing").val('yes');
        }

        $.ajax({
            url: url,
            type: "POST",
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { //alert(data);
                $("#" + var_html).html(data);

            }
        });

        document.getElementById(var_html).style.width = "85%";
    }

    function closeNav(val) {
        $("#typing").val('no');
        document.getElementById(val).style.width = "0";
        
    }

    function openNavSideMenu() {
        $.ajax({
            url: '<?php echo site_url("home/navigation/"); ?>',
            type: "POST",
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            {
                $("#iNavSideMenu").html(data);
            }
        });
        document.getElementById("iNavSideMenu").style.width = "350px";
    }

    function closeNavSideMenu() {
        document.getElementById("iNavSideMenu").style.width = "0";
    }
    function commnFunLibrary(val) {
        var sort_fname = "";
        var sort_tag = "";
        var sort_comment = "";
        var sort_date = "";
        var res = val.split("-");

        if (res[0] == 'deleteLib') {
            var del = res[1];
        } else {
            var del = "";
        }
        if (val == 'ser' || $('#iSearch').val() != "") {
            var ser = $('#iSearch').val();
        } else {
            var ser = "";
        }
        if (val == 'sort_fname') {
            var sort_fname = $('#iSortFName').attr('data-item');
            if (sort_fname == 'ASC') {
                $('#iSortFName').attr('data-item', 'DESC');
            } else {
                $('#iSortFName').attr('data-item', 'ASC');
            }
        }
        if (val == 'sort_tag') {
            var sort_tag = $('#iSortTag').attr('data-item');
            if (sort_tag == 'ASC') {
                $('#iSortTag').attr('data-item', 'DESC');
            } else {
                $('#iSortTag').attr('data-item', 'ASC');
            }
        }
        if (val == 'sort_comment') {
            var sort_comment = $('#iSortComment').attr('data-item');
            if (sort_comment == 'ASC') {
                $('#iSortComment').attr('data-item', 'DESC');
            } else {
                $('#iSortComment').attr('data-item', 'ASC');
            }
        }
        if (val == 'sort_date') {
            var sort_date = $('#iSortDate').attr('data-item');
            if (sort_date == 'ASC') {
                $('#iSortDate').attr('data-item', 'DESC');
            } else {
                $('#iSortDate').attr('data-item', 'ASC');
            }
        }
        var formData = new FormData();
        formData.append('ser', ser);
        formData.append('delete', del);
        formData.append('sort_fname', sort_fname);
        formData.append('sort_tag', sort_tag);
        formData.append('sort_comment', sort_comment);
        formData.append('sort_date', sort_date);
        $.ajax({
            url: '<?php echo site_url("my_files/commnFunLibrary/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data1)
            { //alert(data1);
                 //$("#MenuPopupLib").html(data1);
                  //$(".rightBtn").addClass('active');
                 //$(".rightBtn").click();

               $("#tablecontainer").html(data1);
               if ($("#defaultOpen").hasClass("active")) { 
              
                $("#defaultOpen").removeClass("active");
                 $("#defaultOpen").click();
                 }else{
                     $("#rightBtn1").removeClass("active"); 
                    $("#rightBtn1").click();
                 }
            }
        });
    }
    function serQuestion(val, tab) {
        var sort_date = "";
        var sort_abc = "";
        if (val == 'sort_date') {
            var sort_date = $('#iSortDate').attr('data-item');
            if (sort_date == 'ASC') {
                $('#iSortDate').attr('data-item', 'DESC');
            } else {
                $('#iSortDate').attr('data-item', 'ASC');
            }
        }
        if (val == 'sort_abc') {
            var sort_abc = $('#iSortAbc').attr('data-item');
            if (sort_abc == 'ASC') {
                $('#iSortAbc').attr('data-item', 'DESC');
            } else {
                $('#iSortAbc').attr('data-item', 'ASC');
            }
        }
        var res = val.split("-");
        if (res[0] == 'deleteQue') {
            var del_que = res[1];
            var val = "";
        } else {
            var del_que = "";
        }

        if (tab == "MYProgress") {
            var url = '<?php echo site_url("ask_questions/serQuestionPro/"); ?>' + tab;
        } else if (tab == "NEWAnswers") {
            var url = '<?php echo site_url("ask_questions/serQuestionNewA/"); ?>' + tab;
        } else {
            var url = '<?php echo site_url("ask_questions/serQuestion/"); ?>' + tab;
        }

        var formData = new FormData();
        formData.append('ser', val);
        formData.append('sort_date', sort_date);
        formData.append('sort_abc', sort_abc);
        formData.append('del_question', del_que);
        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data1)
            {
                //$("#iMyQList").html(data1);
                $("#iAjaxResult").html(data1);

            }
        });
    }
//    function openSrc() {
//        document.getElementById("HomeSidenav").style.height = "50px";
//    }
//    function closeSrc() {
//        document.getElementById("HomeSidenav").style.height = "0";
//    }
//    function openPro() {
//        $.ajax({
//            url: '<?php echo site_url("pro_message/get_progress_status/"); ?>',
//            type: "POST",
//            contentType: false,
//            cache: false,
//            processData: false,
//            success: function (data)
//            {
//                $("#HomePronav").html(data);
//            }
//        });
//        document.getElementById("HomePronav").style.height = "550px";
//    }
//    function closePro() {
//        document.getElementById("HomePronav").style.height = "0";
//    }

$("#USERM1").click(function(e){
    var class1=$("#USERM1").attr('class');
    
    if (class1=='dropdown') {
        $("#USERM1").attr('class','dropdown open');
    }else{
         $("#USERM1").attr('class','dropdown');
    }
      e.stopPropagation(); 
})


$("#iGiveInput1").click(function(){
    var status=$(this).data('status');
    
    if (status=='active') {
           window.location.href = $(this).data('url');
     }else{
 window.location.href = $(this).data('url');
    }
})

$('body').keydown(function(event){

    if($("#iGiveInput1").data('status')=='active')
    {
        if (event.which=='39') {
            $(".slick-next").click();
        }

         if (event.which=='37') {
            $(".slick-prev").click();
        }


       
    }else{
        return true;
    }
    
})

</script>