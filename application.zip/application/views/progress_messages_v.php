
<div class="content">
    <div class="content_resize">
        <div  class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <div class="col-lg-12 text-right" style="padding: 0">
<!--                    <form class="example" action="<?php echo site_url('pro_message'); ?>" method="post" style="   margin: 0 0 20px 0;">
                        <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>-->
                </div>

                <div style="clear: both">
                    <?php if ($this->uri->segment(2) == 'search_file') { ?>
                        <h3 style="display: inline-block;font-size: 20px;margin-top: 10px;"><span>Search result..</span> </h3>
                    <?php } else { ?>
                        <h3 style="color:#1D1D1B;display: inline-block;font-size: 20px;margin-top: 10px;">Progress Messages</h3>
                    <?php } ?>
                    <div class="clr"></div>

                    <div class="comment" style="padding:0 !important;"> 
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr style="color: #1D1D1B;font-size: 17px;">
                                    <th width="80%">Message</th>
                                    <th width="20%">Action</th>
                                </tr>
                                <?php
                                //print_r($this->session->userdata('upload_file'));    
                                foreach ($pro_messages as $row) {
                                    ?>
                                    <tr style="font-size: 17px;">
                                        <td>                                            
                                            <?php echo @$row['message']; ?>
                                        </td>                                        
                                        <td>
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#editPmessage<?php echo @$row['id']; ?>" title="Edit" ><i class="fa fa-edit"></i></a>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="editPmessage<?php echo @$row['id']; ?>" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title">Update Progress Messages</h4>
                                                </div>
                                                <form method="post" action="<?php echo site_url('pro_message/update_pro_message/'); ?>" >
                                                    <input type="hidden" name="id" value="<?php echo @$row['id']; ?>" />
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="usr">Message:</label>
                                                            <input type="text" name="message" value="<?php echo @$row['message']; ?>" class="form-control" id="usr">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success" >Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Modal -->

        <script>

            $(document).ready(function () {

                $("#a11").removeClass().addClass('active');
                $('#msg').delay(4000).fadeOut();
            });

        </script>

