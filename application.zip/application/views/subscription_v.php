
<div class="content">

    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar" style="width: 100%;">


            <div class="article pricing-main" style="border: none;">                
                <div class="col-lg-12 noPadding pricing-container">
                    <?php                     
                    foreach ($subscription_plan as $row) { ?>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 subcription-child noPadding">
                            <div class="col-lg-12 noPadding">
                                <h2><b><?=@$row['planName'];?></b></h2>
                            </div>
                            <div class="col-lg-12 noPadding">
                                <div class="subcription-detail"><?=@$row['detail'];?></div>
                            </div>
                            <div class="col-lg-12 subcription-price noPadding">
                                <small><?=(@$row['price'] != 'Custom')? '€':''; ?></small>
                                <div style="<?=(@$row['price'] != 'Custom')? '':'font-size:22px;'; ?>" class="price-num"><?=@$row['price'];?></div>
                                <div class="subcription-duration">
                                    <?=@$row['duration'];?>
                                </div>
                            </div>
                            <div class="col-lg-12 noPadding">
                                <div class="subcription-btn">
                                    <a href="<?php echo site_url("subscription/buy_plan/" . $row['id']); ?>" class=""><?=@$row['btn'];?></a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <?php include 'common.php'; ?>
            <script>
                $(document).ready(function () {
                    $("#USERM").removeClass().addClass('active');
                    setTimeout(function () {
                        $('#msg').fadeOut();
                    }, 5000);
                });
            </script>