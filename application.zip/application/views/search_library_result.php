


                    
<!-- tab content -->

                        <!-- tab 1 -->
                        <div id="Icon" class="tabcontent">
                            
                          <div class="iconFile pos-rel" id="documentsDiv">
                            




<?php  foreach ($library_data as $row => $v) {  ?>

 <div class="fileContent">
                                <a href="<?php echo base_url() . USER_FILES . $library_data[$row]['file_name']; ?>" target="_blank" >

                                    <div class="file_iocn">
                                      
                            <img src="<?php echo $library_data[$row]['thumbnil']; ?>">
                                       
                                       
                                    </div>
                                    <div class="fileTitle" style="word-wrap: break-word; "><?php echo $library_data[$row]['file_name']; ?></div>
                                </a>
                            </div>

<?php } ?>

                            
                            <!-- <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div>
                            <div class="fileContent">
                                <a href="0#">
                                    <div class="file_iocn">
                                        <i class="fa fa-file-pdf-o"></i>
                                    </div>
                                    <div class="fileTitle">Battery-storageThe-next-disruptivetechnology.pdf</div>
                                </a>
                            </div> -->
                          </div>
                        </div>
                        <!-- / tab 1 -->

                        <!-- tab 2 -->
                        <div id="List" class="tabcontent">
                            <!-- <div class="drop_docTitle">Drop new documents from your computer in the box
below to expand your knowledge base</div> -->
                          <div class="comment" style="padding:0 !important;"> 
                           <!-- this class commited  class="table-responsive" -->
                        <div class="scroll-Table-Block">
                            <div id="SUCMSG1"></div>
                            <table class="c-librari-tbl table-striped full-width-table" id="refresh_file_table">
                                <thead>
                                    <tr>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid">File Name</th>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;">Tag
                                        </th>
                                        <th style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;">Comment</th>
                                        <th   style="border-top:#939393 1px solid;border-bottom:#939393 1px solid;border-right:#d2d2d2 1px solid;" id="date_column">Date</th>
                                        <th class="resizable-false" style="border-bottom:#939393 1px solid;border-top:#939393 1px solid;">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="_editable_table">
                                    <?php
//                                    $id = $this->session->userdata('user_id');
//                                    $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id =  $id  and isDeleted = 0 order by id desc ");
//                                    $library_data = $sql->result_array();
                                    foreach ($library_data as $row => $v) {
                                        ?>
                                        <tr>
                                            <td>
                                                <a style="color: #23527c;text-decoration: none" href="<?php echo base_url() . USER_FILES . $library_data[$row]['file_name']; ?>" download="<?php echo @$library_data[$row]['file_name']; ?>">
                                                  <!--   <?php echo $library_data[$row]['file_name']; ?> -->
                                                    <?php echo strlen(@$library_data[$row]['file_name']) > 30 ? substr(@$library_data[$row]['file_name'],0,30)."..." : @$library_data[$row]['file_name']; ?>
                                                </a> 
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'tagName', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php echo @$library_data[$row]['tagName']; ?>
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'comment', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php echo @$library_data[$row]['comment']; ?>
                                            </td>
                                            <td contenteditable="true" onBlur="saveToDatabase(this, 'created', '<?php echo $library_data[$row]['id']; ?>')" onClick="showEdit(this);">
                                                <?php
                                                //echo date('j F, Y', strtotime(@$row['created'])); 
                                                echo date('d/m/Y', strtotime(@$library_data[$row]['created']));
                                                ?>
                                            </td>
                                            <td> 
                                                <a href="javascript:void(0)" onclick="commnFunLibrary('deleteLib-<?php echo @$library_data[$row]['id']; ?>');" ><i class="fa fa-trash-o"></i></a> 
                                            </td>                                        
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                        </div>
                        <!-- / tab 2 -->
<!-- tab content -->
                      
                    <!-- tabs -->