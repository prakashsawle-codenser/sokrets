<style>
    form.example input[type=text] {
        padding: 2px;
        font-size: 13px;
        float: left;
        width: 70%;
        background: #fff;
    }

    form.example button {
        float: left;
        width: 15%;
        padding: 6px;
        background: #2196F3;
        color: white;
        font-size: 17px;
        border-left: none;
        cursor: pointer;
        border: none;
    }

    form.example button:hover {
        background: #0b7dda;
    }

    form.example::after {
        content: "";
        clear: both;
        display: table;
    }
    .dropzone {
        background: #fff;
        border: 2px dashed #ddd;
        border-radius: 5px;
    }

    .dz-message {
        color: #999;
    }

    .dz-message:hover {
        color: #464646;
    }

    .dz-message h3 {
        font-size: 200%;
        margin-bottom: 15px;
    }
</style>
<div class="content">
    <div class="content_resize">

        <div class="mainbar">

            <div class="col-lg-12 text-right">

                <form class="example" action="<?php echo site_url('ask_questions/search_answer/' . $this->uri->segment(3)); ?>" method="post" style="float: right;max-width:300px;margin-top: 10px;">
                    <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                    <button type="submit"><i class="fa fa-search"></i></button>

                </form>
                <a href="#" data-toggle="modal" data-target="#Files-Modal" style="margin-right: 15px; line-height: 3; font-size: 15px;"> Add Files</a>
            </div>
            <!--            <div class="article">
                            <h2><span>Question</span> </h2>
                            <div class="clr"></div>
                            <p>Posted by <a href="#"><?php echo @$question->firstName; ?></a> </p>
                            <p><?php echo @$question->questionTitle; ?></p>
                            <p>Tagged: <a href="#">orci</a>, <a href="#">lectus</a>, <a href="#">varius</a>, <a href="#">turpis</a></p>
                            <p><a href="#"><strong>Comments (3)</strong></a> <span>&nbsp;&bull;&nbsp;</span> May 27, 2010 <span>&nbsp;&bull;&nbsp;</span> <a href="#"><strong>Edit</strong></a></p>
                        </div>-->
            <div class="article">
                <h2><span>10</span> Files</h2>
                <div class="clr"></div>

                <div class="comment"> 
                    <a href="#">
                        <img src="#" width="40" height="40" alt="" class="userpic" />
                    </a>
                    <p>
                        <a href="#">hardik</a> Says:<br />
                        4 July, 2018</p>
                    <p>
                        test
                    </p>
                </div>

            </div>

        </div>
        <!-- Modal -->
        <div class="modal fade" id="Files-Modal" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Modal Header</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="col-lg-4">

                                </div>
                                <div class="col-lg-8">
                                    <div id="content">
                                        <div id="my-dropzone" class="dropzone">
                                            <div class="dz-message">
                                                <h3>Drop files here</h3> or <strong>click</strong> to upload
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.js"></script>
        <script>
            Dropzone.autoDiscover = false;
            var myDropzone = new Dropzone("#my-dropzone", {
                url: "<?php echo site_url("files/upload") ?>",
                acceptedFiles: "image/*",
                addRemoveLinks: true,
                removedfile: function (file) {
                    var name = file.name;

                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url("files/remove") ?>",
                        data: {file: name},
                        dataType: 'html'
                    });

                    // remove the thumbnail
                    var previewElement;
                    return (previewElement = file.previewElement) != null ? (previewElement.parentNode.removeChild(file.previewElement)) : (void 0);
                },
                init: function () {
                    var me = this;
                    $.get("<?php echo site_url("files/list_files") ?>", function (data) {
                        // if any files already in server show all here
                        if (data.length > 0) {
                            $.each(data, function (key, value) {
                                var mockFile = value;
                                me.emit("addedfile", mockFile);
                                me.emit("thumbnail", mockFile, "<?php echo base_url(); ?>uploads/" + value.name);
                                me.emit("complete", mockFile);
                            });
                        }
                    });
                }
            });
        </script>
        <script>
            $(document).ready(function () {
                $("#HOME").removeClass().addClass('active');
            });
        </script>