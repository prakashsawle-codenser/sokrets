
<script type="text/javascript" src="<?php echo base_url(); ?>assets/nicEdit/nicEdit-latest.js"></script>
<div class="content">
    <div class="content_resize">
        <div class="mainbar">
            <!--            <div class="article">
                            <h2><span>Contact</span></h2>
                            <div class="clr"></div>
                            <p>You can find more of my free template designs at my website. For premium commercial designs, you can check out DreamTemplate.com.</p>
                        </div>-->
            <div class="article">
                <h2> <span style="font-size: 20px;font-weight: bold;color: #000000b3;"><?php echo @$question->questionTitle; ?></span>
                       </h2>
                <div class="clr"></div>
                <div class="row">
                    <div id="responseMsg"></div>
                    <?php if ($this->session->flashdata('error')) : ?>
                        <div  class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?>
                        </div>  
                    <?php endif; ?>
                    <div class="col-md-12">
                        <?php if ($this->session->flashdata('success')) : ?>

                            <div id="msg" class="alert alert-success alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success!</strong> <?php echo $this->session->flashdata('register_success'); ?>
                            </div>

                        <?php endif; ?>
                    </div>
                </div>

                <form action="<?php echo site_url("ask_questions/submit_answer/" . $this->uri->segment(3)); ?>" method="post" enctype="multipart/form-data" id="form-question">
                    <input type="hidden" name="answerBy" value="<?php echo $this->session->userdata('user_id'); ?>" />
                    <input type="hidden" name="questionBy" value="<?php echo $this->uri->segment(4); ?>" />
                    <input type="hidden" name="questionID" value="<?php echo $this->uri->segment(3); ?>" />
                    
                    <ol>
<!--                        <li>
                            <label for="question">Question Title</label>
                            <span style="font-size: 17px;font-weight: bold;color: #000000b3;"><?php echo @$question->questionTitle; ?></span>
                        </li>-->
                        <li>
                            <label style="    font-size: 18px;
    padding-bottom: 13px;">Your Answer</label>
                            <!--<input class="form-control" name="questionTitle" class="text"  />-->
                            <!--<textarea required cols="80" id="description" name="answer" rows="10" ></textarea>-->
                            <script type="text/javascript">
//<![CDATA[
                                bkLib.onDomLoaded(function () {
                                    nicEditors.allTextAreas()
                                });
                                //]]>
                            </script>
                            <textarea name="answer" cols="80"  rows="10" style="width: 100%;"></textarea>

                        </li>

                        <li>
                            <label for="email">Source URL (optional)</label>
                            <input class="form-control" name="sourceURL" class="text" />
                        </li>

                        <li>
                            <button id="submit-button" class="btn btn-success send" type="submit" style="margin-bottom: 10px;">Submit Answer</button>
                            <!--<input type="image" name="imageField" id="imageField" src="<?php echo base_url(); ?>assets/images/submit.gif" class="send" />-->
                            <div class="clr"></div>
                        </li>
                    </ol>
                </form>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 

        <script>
        $(document).ready(function () {
            $("#MYQUESTION").removeClass().addClass('active');
            // $('#msg').delay(4000).fadeOut();
            setTimeout(function () {
                $('#msg').fadeOut();
            }, 5000);
        });

        function notifyMe() {
            // Let's check if the browser supports notifications
            if (!("Notification" in window)) {
                alert("This browser does not support desktop notification");
            }

            // Let's check if the user is okay to get some notification
            else if (Notification.permission === "granted") {
                // If it's okay let's create a notification
                var options = {
                    body: "This is the body of the notification",
                    icon: "icon.jpg",
                    dir: "ltr"
                };
                var notification = new Notification("Hi there", options);
            }

            // Otherwise, we need to ask the user for permission
            // Note, Chrome does not implement the permission static property
            // So we have to check for NOT 'denied' instead of 'default'
            else if (Notification.permission !== 'denied') {
                Notification.requestPermission(function (permission) {
                    // Whatever the user answers, we make sure we store the information
                    if (!('permission' in Notification)) {
                        Notification.permission = permission;
                    }

                    // If the user is okay, let's create a notification
                    if (permission === "granted") {
                        var options = {
                            body: "This is the body of the notification",
                            icon: "icon.jpg",
                            dir: "ltr"
                        };
                        var notification = new Notification("Hi there", options);
                    }
                });
            }
            document.getElementById("myForm").submit();
        }
        </script>

