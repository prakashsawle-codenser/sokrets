
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick-theme.css">
<script src="<?php echo base_url(); ?>assets/slick/slick.js" charset="utf-8"></script>
<style>
    .slick-slider{
        width:85%;
        margin: auto;
    }
    .follow-up-questions{
        width:85%;
        margin: auto;
    }
</style>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="home-main">
            <div class="mainbar" style="width:100%;">
                <div class="slider" id="slick">
                    <?php foreach ($questions as $question) { ?>
                        <div id="div-slider" data-qid="<?php echo @$question['questionID']; ?>" data-a_id="<?php echo @$question['answer_id']; ?>" >
                            <div class="art-q-div"  >
                                <div class="article-question" style="">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="q-box">Q</span>-->
                                        <p class="text-center home-q-title" >
                                            <?php echo @$question['questionTitle']; ?>
                                        </p>                    
                                    </div>
                                </div>
                            </div>
                            <div class="art-a-div">
                                <div class="article-answer" style="">
                                    <div class="clr"></div>
                                    <div class="comment" style="text-align: center;" > 
                                        <!--<span class="a-box">A</span>-->
                                        <div class="text-center" style="padding:5px;">                                    
                                            <p class="commentbx-home" >    
                                                <a href="" class="slider-ans-text">
                                                    <?php echo @$question['answer']; ?>
                                                </a>                                                
                                            </p>                                           
                                           
                                            <!--                                            <div class="f-answer">
                                                                                            <label for="email" style="padding-top: 15px;font-weight: none;">Find Answer &nbsp;</label> 
                                                                                            <label class="checkbox-inline custom-check" style="font-weight: none;">
                                                                                                <input name="sources" type="checkbox" value="Internet" <?php
                                            if (@$question['sources'] == "Internet") {
                                                echo 'checked';
                                            }
                                            ?>>Internet
                                                                                                <span class="checkmark"></span>
                                                                                            </label>
                                                                                            <label class="checkbox-inline custom-check" style="font-weight: none;">
                                                                                                <input name="sources" type="checkbox" value="My Library" <?php
                                            if (@$question['sources'] == "My Library") {
                                                echo 'checked';
                                            }
                                            ?>>My Library
                                                                                                <span class="checkmark"></span>
                                                                                            </label>
                                                                                        </div>-->
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <?php if (!empty($questions)) { ?>
                <div class="follow-up-questions">
                    <form action="<?php echo site_url("ask_questions/submit_follow_up_questions/"); ?>" method="post" enctype="multipart/form-data" id="form-question">
                        <input type="hidden" name="userID" value="<?php echo $this->session->userdata('user_id'); ?>"  />
                        <input type="hidden" name="followUpQuestionsID" id="iQuestionID" value="<?php echo @$questions[0]['questionID']; ?>" />
                        <input type="hidden" name="sources" id="isources" value="" />
                        <ol>
                            <li>
                                <input placeholder="Type your follow-up question (on this topic)"  autocomplete="off" id="tags" class="input_question" name="questionTitle" type="text"  style="font-size: 21px;background-color: #ffffffa1 !important;height:60px;margin-top: 20px;" required />
                                <ul class="sugestion-tag" id="sugestion-tag" style="width:61.5%;"></ul>
                            </li>                
                            <li>
                                <div class="clr"></div>
                            </li>
                        </ol>
                    </form>
                </div>
            <?php } else {
                
            } ?>
        </div>
        <?php
        $sql_pc = "select * from (select a.*, b.questionTitle from tbl_progress_status a, questions b WHERE a.isDeleted = 0 and a.questionBy = '" . $this->session->userdata('user_id') . "'  AND a.questionID = b.id order by questionID, progress_status desc) x group by `questionID`";
        $query_pc = $this->db->query($sql_pc);
        ?>
        <!--        <div class="ask_q_footer">
                    <div class="ask_q_footer_resize">
                        <div class="col-lg-12 noPadding">
                            <div id="HomeSidenav" class="ans-src-div">
                                <a href="javascript:void(0)" class="closebtn-ans-src" onclick="closeSrc()">&times;</a>
                                <div class="asq_foot_btn" >Answer Source</div>
                                <div class="ans-src-chk" style="">                    
                                    <label class="checkbox-inline qcustom-check"  >
                                        <input id="ichk_int" name="sources" type="checkbox" value="Internet" >
                                        Internet
                                        <span class="qcheckmark" ></span>
                                    </label>
                                    <label class="checkbox-inline qcustom-check" >
                                        <input id="ichk_lib" name="sources" type="checkbox" value="My Library">
                                        My Library
                                        <span class="qcheckmark" ></span>
                                    </label>
                                </div>
                            </div> 
                            <div class="asq_foot_btn asq-right" onclick="openSrc()" >
                                Answer Source
                            </div>
                            <div id="HomePronav" class="home-pro-div">
        
                            </div>
                            <div class="asq_foot_btn asq-left" onclick="openPro()">
                                Progress 
                                <span class="header_q_count" style="padding: 0px 4px;">
<?php echo @str_pad(count($query_pc->result()), 2, "0", STR_PAD_LEFT); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>-->
<?php include 'footer_tabs.php'; ?>
<?php include 'common.php'; ?>
                <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
        <script>

            function getSugVal(val) {
                $('#tags').val(val);
                $('.sugestion-tag').hide();
            }
            $(document).ready(function () {

                $('input').keypress(function (e) {
                    if (e.which == 13) {
                        $('form#form-question').submit();
                        return false;    //<---- Add this line
                    }
                });

                $('#ichk_int').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });
                $('#ichk_lib').change(function () {
                    if ($(this).is(':checked')) {
                        $('#isources').val(this.value);
                    }
                });

                $("#tags").on('keyup', function () {
                    var q = this.value;
                    var formData = new FormData();
                    formData.append('q', q);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/get_sugestion/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                            $('.sugestion-tag').show();
                            $('#sugestion-tag').html(data);
                        }
                    });
                });

                $('.slider').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                    infinite: true,
                    cssEase: 'linear',
                    autoplay: false
                });

                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);

                $('#slick').on('afterChange', function (event, slick, currentSlide, nextSlide) {
                    var $slides = $('#slick').slick("getSlick").$slides;

                    $('#iQuestionID').val($slides.eq(currentSlide).find('div div').attr('data-q_id'));
                    var ans_id = $slides.eq(currentSlide).find('div div').attr('data-a_id');
                    var formData = new FormData();
                    formData.append('answer_id', ans_id);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/readAnswer/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false
                    });
                });
            });
            
        </script>
