<style>
    .nav>li>a:focus, .nav>li>a:hover {
        text-decoration: none; 
        background-color: #F9F8F8;

    }
    .active_my_tab{
        background-color: #fff;
        border-left: 2px solid #F9F8F8!important;
        font-size: 12px;
        font-weight: bold;
        color:#201F1F !important;
    }
</style>
<a href="javascript:void(0)" onclick="closeNav('MenuPopup')"><img class="close-btn-png my-q-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" /></a>           
<div class="container-sokrates">
    <div class="col-lg-12  question-div clearfix" >
        <div class="col-lg-3 col-sm-3 noPadding question-title-div" >
            <h3>My Questions</h3>
            <small>My Questions has <?php echo @count($questions_answer); ?> Questions.</small>
        </div>
        <div class="col-lg-9 col-sm-9 noPadding">
            <div class="question-ser-div">
                <i class="fa fa-search my-q-ser-icon"></i>
                <input onkeyup="serQuestion(this.value, 'NEWAnswers');" type="text"  name="ser" class="form-control my-q-ser" placeholder="My Questions Search" />
                <small>sort by &nbsp; 
                    <a id="iSortDate" onclick="serQuestion('sort_date', 'NEWAnswers');" href="javascript:void(0)" data-item="ASC">
                        date
                    </a> &nbsp; &nbsp;
                    <a id="iSortAbc" onclick="serQuestion('sort_abc', 'NEWAnswers');" href="javascript:void(0)" data-item="ASC">
                        alphabetically^
                    </a>
                </small>
            </div>
        </div>
    </div>
    <div class="col-lg-12 q-and-answer" id="iMyQList" >
        <div class="main-myq-tab-div">
            <ul class="nav nav-tabs my-q-nav">
                <li class=""><a onclick="openNav('My_Questions');" href="javascript:void(0)"  data-toggle="tab" href="#Questions">Questions</a></li>
                <li>
                    <a onclick="openNav('Progress');" data-toggle="tab" href="javascript:void(0)" >Progress
                        <?php if (isset($progress_count->progress_count) && $progress_count->progress_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $progress_count->progress_count; ?>
                            </span>
                        <?php }
                        ?>
                    </a>
                </li>
                <li>
                    <a class="active_my_tab" data-toggle="tab" href="javascript:void(0)">New answers
                        <?php if (isset($ans_count->ans_count) && $ans_count->ans_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $ans_count->ans_count; ?>
                            </span>            
                        <?php } ?>
                    </a>
                </li>
                
            </ul>
            <div class="tab-content">
                <div id="Questions" class="tab-pane fade in active">
                    <div class="question-tab-data" id="iAjaxResult">
                        <?php
 
                        foreach ($questions_answer as $q) {

                            if (@$q['followUpQuestionsID'] != "") {
                                //$sql_follup = "SELECT * FROM `answer` WHERE questionID = '" . $q['question_id'] . "' and questionBy = '" . $this->session->userdata('user_id') . "' ";
                                //$exe_follup = $this->db->query($sql_follup);
                                //if ($exe_follup->num_rows() > 0) {
                                    ?>
                          
                                    <?php
                                //}
                            } else {
                                ?>
                                <div class="q-a-width" id="qblock<?php echo $q['question_id']; ?>" >
                                    <h4>
                                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['questionTitle']; ?></a>
                                    </h4>
                                    <span class="q-answer" >
                                        <a id="answerBox<?php echo $q['question_id']; ?>" href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['answer']; ?></a>
                                    </span>
                                    <?php if ($q['answer_source']=='A') {
                                        if ($q['ans_accept']=='N') {
                                            
                                             if ($q['replyType']=='std_ans') {  ?>
                                                    <div id="responseDiv<?php echo $q['question_id']; ?>">
                                                  <p>Do you want to save this question? <a href="#" class="response resYes" id="yes" data-id="<?php echo $q['question_id']; ?>" data-value="Y" data-url="<?php echo $q['sourceURL']; ?>">Y</a><a href="#" class="deleteQuestion resNo"   id="no" data-id="<?php echo $q['question_id']; ?>"data-value="N" data-url="<?php echo $q['sourceURL']; ?>">N</a></p>
                                            </div>
                                         <?php    }else{ ?>
                                            <div id="responseDiv<?php echo $q['question_id']; ?>">
                                                  <p>Does this answer your question? <a href="#" class="response resYes"  id="yes" data-id="<?php echo $q['question_id']; ?>" data-value="Y" data-url="<?php echo $q['sourceURL']; ?>">Y</a><a href="#" class="response resNo"     id="no" data-id="<?php echo $q['question_id']; ?>"data-value="N" data-url="<?php echo $q['sourceURL']; ?>">N</a></p>
                                            </div>

                                          <?php   }
                                         ?>
                                  
                                <?php } } ?>
                                    <div class="seen-ans-div">
                                        <a class="" alt="Delete"  onclick="deleteQuestion(<?php echo $q['question_id']; ?>)" >
                                           <i style="color:gray;" class="fa fa-trash-o" ></i>
                                        </a>
                                    </div>
                                </div>
                                <?php
                                $key='';
                               $sql = $this->db->query("SELECT 
                                    a.id as answer_id, 
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept,
                                    a.replyType   
                                FROM 
                                    answer a  INNER JOIN 
                                    questions b  ON a.questionID = b.id
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    b.followUpQuestionsID=".$q['question_id']);
                        
                          $res = $sql->result_array();
                      // print_r($res);
                                foreach ($res as $q1) {
                                   
                                  ?>
                                   <div class="q-a-width" id="qblock<?php echo $q1['question_id']; ?>">
                                        <h4>
                                            <i style="font-weight: bold;color: #000;" class="fa fa-angle-right"></i> 
                                            <a href="<?php echo site_url('ask_questions/question_answer/' . $q1['question_id'] . '/' . $q1['answer_id']); ?>">
                                                <?php echo @$q1['questionTitle']; ?> <span style="color: #A5A4A4;font-weight: normal;font-size: 14px;">(<?php echo date('j F, Y', strtotime($q1['created'])); ?>)</span>
                                            </a>
                                        </h4>
                                        <span class="q-answer" >
                                            &nbsp; &nbsp; <a href="<?php echo site_url('ask_questions/question_answer/' . $q1['question_id'] . '/' . $q1['answer_id']); ?>" id="answerBox<?php echo $q1['question_id']; ?>"><?php echo @$q1['answer']; ?></a>
                                        </span>
                                        <?php if ($q1['answer_source']=='A') {
                                        if ($q1['ans_accept']=='N') { 
                                               if ($q1['replyType']=='std_ans') { ?>
                                                <div id="responseDiv<?php echo $q1['question_id']; ?>">
                                                  <p>Do you want to save this question? <a href="#" class="response resYes" id="yes" data-id="<?php echo $q1['question_id']; ?>" data-value="Y" data-url="<?php echo $q1['sourceURL']; ?>">Y</a><a href="#" class="deleteQuestion resNo"   id="no" data-id="<?php echo $q1['question_id']; ?>"data-value="N" data-url="<?php echo $q1['sourceURL']; ?>">N</a></p>
                                            </div>
                                   
                                    <?php }else{ ?>

                                             <div id="responseDiv<?php echo $q1['question_id']; ?>">
                                                  <p>Does this answer your question? <a href="#" class="response resYes"  id="yes" data-id="<?php echo $q1['question_id']; ?>" data-value="Y" data-url="<?php echo $q1['sourceURL']; ?>">Y</a><a href="#" class="response resNo"     id="no" data-id="<?php echo $q1['question_id']; ?>"data-value="N" data-url="<?php echo $q1['sourceURL']; ?>">N</a></p>
                                    </div>

                                          <?php 
                                             }

                                            ?>
                                <?php } } ?>


                                    <div class="delete-my-q-div">
                                        <!--onclick="serQuestion('deleteQue-<?php //echo @$q['question_id']; ?>');"-->
                                        <a  alt="Delete"  onclick="deleteQuestion(<?php echo $q1['question_id']; ?>)"   href="javascript:void(0)"  >
                                            <i style="color:gray;" class="fa fa-trash-o" ></i>
                                        </a>
                                    </div>
                                    </div>.

                               <?php }
                               
                                ?>

                                
                                    <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>        
    </div> 
</div>

<script type="text/javascript">
    function addBookShelfData(qid,url)
    {
               var url=url;
                 var qid=qid;
                var formData = new FormData();
                   formData.append('url', url);
                   formData.append('qid', qid);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/addBookshelfDocument"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                           $("#responseDiv"+qid).html(''); 
                           
                    
                                $("#answerBox"+qid).html("Successfully added pdf in your BookShelf.");
                            

                        setInterval(function(){                               
                                 window.location.href = "<?php echo site_url("ask_questions/"); ?>"
                              }, 3000);

                            
                          
                        }
                    });
   }

   function nobookshelf(qid){
      $("#responseDiv"+qid).html(''); 
   }

  


    
     $(".response").click(function(){
               var qid= $(this).data('id');
               var response= $(this).data('value');
               var url=$(this).data('url');
               var formData = new FormData();
                   formData.append('qid', qid);
                   formData.append('response', response);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/addApiQuestionResponse/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                            console.log(data);
                             var data=$.parseJSON(data);
                            
                           $("#responseDiv"+qid).html(''); 
                           
                            if (response=='N') {
                                $("#answerBox"+qid).html("Let me find another answer and get back to you.");
                                //callanswerFromApi();
                                if (data.count==0) {
                                       setInterval(function(){                               
                                 //window.location.href = "<?php echo site_url("ask_questions/submit_question/"); ?>"
                              }, 5000);
                                }
                             

                            }

                            if (response=='Y') {
                                if (data.response=='Y') {

                                    $("#responseDiv"+qid).html('<p>Save source to BookShelf? <a href="#" class="addbookshelf resYes" id="yes" data-id="'+qid+'" data-value="Y" data-url="'+url+'" onclick=addBookShelfData('+qid+',"'+url+'") >Y</a><a href="#" class="nobookshelf resNo"  onclick="nobookshelf('+qid+')"  id="no" data-id="'+qid+'"data-value="N" data-url="'+url+'">N</a></p>')
                                }else{
                                     if (data.count==0) {
                                   window.location.href = "<?php echo site_url("ask_questions/"); ?>"
                              }
                                }
                            }



                           // $("#responseDiv"+qid).html('');                            
                           //  if (response=='N') {
                           //      $("#answerBox"+qid).html("Let me find another answer and get back to you.");
                           //      //callanswerFromApi();
                           //      setInterval(function(){                               
                           //       window.location.href = "<?php echo site_url("ask_questions/submit_question/"); ?>"
                           //    }, 5000);

                           //  }

                           //  if (response=='Y') {
                           //      if (data=='Y') {

                           //          $("#responseDiv"+qid).html("<button class='btn btn-danger btn-xs addbookshelf' data-url='"+url+"'> Add source to BookShelf</button>")
                           //      }else{
                           //          window.location.href = "<?php echo site_url("ask_questions/"); ?>"
                           //      }
                           //  }    
                        }
                    });
            })

       $(".deleteQuestion").click(function(){
               var qid= $(this).data('id');
               var response= $(this).data('value');
               var formData = new FormData();
                   formData.append('qid', qid);
                   formData.append('response', response);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/delete_question"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                          window.location.href = "<?php echo site_url("ask_questions/"); ?>"
 
                        }
                    });
            })
            function callanswerFromApi(){                 
                    $.ajax({
                            url   : '<?php echo site_url("ask_questions/answerFromApi/"); ?>',
                            async : true //change this to false if you hate your users and want them to wait 
                        }).done(function() {
                            
                        });
                }

               //  $(document).on("click", ".addbookshelf", function(){
                    
               //  var url=$(this).data('url');
               //   var qid=$(this).data('qid');
               // var formData = new FormData();
               //     formData.append('url', url);
               //     formData.append('qid', qid);
               //      $.ajax({
               //          url: '<?php echo site_url("ask_questions/addBookshelfDocument"); ?>',
               //          type: "POST",
               //          data: formData,
               //          contentType: false,
               //          cache: false,
               //          processData: false,
               //          success: function (data)
               //          {
               //             $("#responseDiv"+qid).html(''); 
                           
                    
               //                  $("#answerBox"+qid).html("Successfully added pdf in your BookShelf.");
                            

               //          setInterval(function(){                               
               //                   window.location.href = "<?php echo site_url("ask_questions/"); ?>"
               //                }, 3000);

                            
                          
               //          }
               //      });
               //  })



             $(".deleteQuestion").click(function(){
               var qid= $(this).data('id');
               var response= $(this).data('value');
               var formData = new FormData();
                   formData.append('qid', qid);
                   formData.append('response', response);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/delete_question"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                          window.location.href = "<?php echo site_url("ask_questions/"); ?>"
 
                        }
                    });
            })



               
             
                


</script>