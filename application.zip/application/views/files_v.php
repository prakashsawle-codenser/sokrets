<link rel="stylesheet" href="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.css">
<style>
        .dropzone {
        background: #fff;
        border: 2px dashed #bdbcbc;
        border-radius: 5px;
    }

    .dz-message {
        color: #999;
    }

    .dz-message:hover {
        color: #464646;
    }

    .dz-message h3 {
        font-size: 200%;
        margin-bottom: 15px;
    }
    td, th {
        padding: 2px;
    }
    tr td{    font-size: 14px;}
    .dropzone .dz-preview .dz-remove {
        color: blue !important;
    }
    .nav-tabs>li>a{
        padding: 5px 16px;
        font-size: 14px;
    }
</style>

<div class="content">
    <div class="content_resize">
        <div  class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <div class="col-lg-12 text-right" style="padding: 0">
                    <form class="example" action="<?php echo site_url('my_files/search_file/'); ?>" method="post" style="   margin: 0 0 20px 0;">
                        <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
                <div class="col-lg-12 noPadding">
                    <ul class="nav nav-tabs">
                        <li id="act1" class="active"><a id="t1" data-toggle="tab" href="#tab1">Upload Files</a></li>
                        <li id="act2"><a id="t2" data-toggle="tab" href="#tab2">Add Tag</a></li>
                        
                    </ul>

                    <div class="tab-content">
                        <div id="tab1" class="tab-pane fade in active">
                            <span>&nbsp;</span>
                            <div id="content">
                                <div id="my-dropzone" class="dropzone" style="border-style: dashed;">
                                    <div class="dz-message">
                                        <h3>Drop files here</h3> or <strong>click</strong> to upload
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-success" id="file_next" style="margin-right: 0;cursor: pointer;float: right;margin-top: 10px; padding: 7px 30px;"> Next</button>
                        </div>
                        <div id="tab2" class="tab-pane fade">
                            <span>&nbsp;</span>
                            <form method="post" enctype="multipart/form-data" action="<?php echo site_url('my_files/upload_files/'); ?>">
                                <input type="hidden" name="file_names" id="f_name_arr" />
                                <div class="col-lg-12 noPadding" style="border-bottom: 1px solid #DDDDDD;">
                                    <div class="col-lg-6" style="padding: 8px 15px;">
                                        <div class="form-group">
                                            <label style="margin-bottom: 0px;" for="comment">Apply Tag</label>
                                            <div id="taglist">
                                                <div class="checkbox">
                                                    <label>
                                                        <input style="cursor: pointer;" id="maincheckbox" type="checkbox" onclick="addTag(this)">
                                                        <input style="height: 28px;" type="text" name="" id="tagname" class="form-control frm-l-s">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6" style="padding: 8px 15px;">
                                        <div class="form-group">
                                            <label for="comment">Comment:</label>
                                            <textarea name="comment" class="form-control" rows="4" id="comment" ></textarea>
                                        </div>
                                    </div>
                                </div> 
                                <button style="float: right;margin-top: 10px" class="btn btn-success" type="submit">Submit Files</button>
                                <button type="button" class="btn btn-success" id="file_prev" style="margin-right: 0;cursor: pointer;float: right;margin-top: 10px;margin-right: 8px;"> Previous</button>

                            </form>

                        </div>
                    </div>
                </div>
                <div style="clear: both">
                    <?php if ($this->uri->segment(2) == 'search_file') { ?>
                        <h3 style="display: inline-block;font-size: 20px;margin-top: 10px;"><span>Search result..</span> </h3>
                    <?php } else { ?>
                        <h3 style="display: inline-block;font-size: 20px;margin-top: 10px;"><span><?php echo @$files_count; ?></span> Files</h3>

                    <?php } ?>
                    <div class="clr"></div>

                    <div class="comment" style="padding:0 !important;"> 
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr style="color: #5FB368;font-size: 17px;">
                                    <th width="20%">File Name</th>
                                    <th width="30%">Tag</th>
                                    <th width="30%">Comment</th>
                                    <th width="20%">Date</th>
                                </tr>
                                <?php
                                //print_r($this->session->userdata('upload_file'));    
                                foreach ($files as $row) {
                                    ?>
                                    <tr>
                                        <td>
                                            <a style="color: #23527c;text-decoration: none" href="<?php echo base_url() . USER_FILES . $row['file_name']; ?>" download="<?php echo @$row['file_name']; ?>">
                                                <?php echo @$row['file_name']; ?>
                                            </a> 
                                        </td>
                                        <td>
                                            <?php echo @$row['tagName']; ?>
                                        </td>
                                        <td>
                                            <?php echo @$row['comment']; ?>
                                        </td>
                                        <td>
                                            <?php echo date('j F, Y', strtotime(@$row['created'])); ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        
         <?php include 'common.php'; ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.js"></script>
        
        <script>
        Dropzone.autoDiscover = false;
        var myDropzone = new Dropzone("#my-dropzone", {
            url: "<?php echo site_url("images/upload") ?>",
            acceptedFiles: "image/*,.pdf,.doc,.xls,.xlsx,.txt,.docx",
            addRemoveLinks: true,
            success: function () {
 
            },
            removedfile: function (file) {
                var name = file.name;
                $.ajax({
                    type: "post",
                    url: "<?php echo site_url("images/remove") ?>",
                    data: {file: name},
                    dataType: 'html',
                    success: function () {

                    }
                });

                var previewElement;
                return (previewElement = file.previewElement) != null ? (previewElement.parentNode.removeChild(file.previewElement)) : (void 0);
            },
            init: function () {
                var me = this;
                $.get("<?php echo site_url("images/list_files") ?>", function (data) {
                    // if any files already in server show all here 
                    if (data.length > 0) {
                        $.each(data, function (key, value) {
                            var mockFile = value;
                            me.emit("addedfile", mockFile);
                            me.emit("thumbnail", mockFile, "<?php echo base_url(); ?>uploads/temp/" + value.name);
                            me.emit("complete", mockFile);
                        });
                    }
                });
            }
        });
        $(document).ready(function () {

            $("#MYFILES").removeClass().addClass('active');
            $('#msg').delay(4000).fadeOut();

            $("#file_next").on('click', function () {
                $('#t1').attr("aria-expanded", "false");
                $('#tab1').removeClass().addClass('tab-pane fade');
                $('#act1').removeClass();
                $('#act2').addClass('active');
                $('#t2').attr("aria-expanded", "true");
                $('#tab2').removeClass().addClass('tab-pane fade active in');
            });

            $("#file_prev").on('click', function () {
                $('#t1').attr("aria-expanded", "true");
                $('#tab1').removeClass().addClass('tab-pane fade active in');
                $('#act2').removeClass();
                $('#act1').addClass('active');
                $('#t2').attr("aria-expanded", "false");
                $('#tab2').removeClass().addClass('tab-pane fade');
            });
        });
        function addTag(val) { //alert('fghfgh');

            var tagname = $("#tagname").val();
            if (tagname == "") {
                alert('Please fill the text field.')
                $('#maincheckbox').prop('checked', false);
                return false;
            }
            //alert($("#tagname").val());
            $("#taglist").prepend("<div class='checkbox'><label><input name='tagName[]' value=" + tagname + " type='checkbox' checked >" + tagname + "</label></div>");
            //val.unchecked
            $('#maincheckbox').prop('checked', false);
            $('#tagname').val('');
        }
        </script>

