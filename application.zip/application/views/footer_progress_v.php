<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/progress-circle.css">
<?php
$sql_c_arr = $this->db->query("SELECT questionID FROM `tbl_mycomments` WHERE questionBy = '" . $this->session->userdata('user_id') . "' AND messageBy != '" . $this->session->userdata('user_id') . "' AND isRead = 0 AND isDeleted = 0 AND is_final=0 GROUP BY questionID");
$sql_c_arr->result_array();
if (!empty($sql_c_arr->result_array())) {
    foreach ($sql_c_arr->result_array() as $rowcid) {
        $cmntid[] = $rowcid['questionID'];
    }
} else {
    $cmntid[] = "";
}

foreach ($user_pro_data as $key => $row_pro) {
    if (in_array($row_pro['q_id'], $cmntid)) {
        echo "res-com-act";
        $qid = $rowcid['questionID'];
        $user_pro_data[$key] += ["qid" => $qid];
        //array_merge($user_pro_data[$key], array('qid'=>$qid));
    } else {
        $user_pro_data[$key] += ["qid" => 0];
        //echo "res-com-inct";
    }
}
$keys = array_column($user_pro_data, 'qid');
array_multisort($keys, SORT_DESC, $user_pro_data);
?>
<div class="row" style="padding: 15px 90px;" >    
    <?php
    //print_r($user_pro_data); 
    
    foreach ($user_pro_data as $row_pro) {
        ?>


        <div class="col-md-12 main-pro-div-pos <?php
    if (in_array($row_pro['q_id'], $cmntid)) {
        echo "res-com-act";
    } else {
        echo "res-com-inct";
    }
        ?>" <?php if (in_array($row_pro['q_id'], $cmntid)) { ?>onclick='window.location = "<?php echo site_url('ask_questions/give_input/' . $row_pro['q_id'] . "/" . $row_pro['answerBy']); ?>"' <?php } ?> id="qblock<?php echo $row_pro['q_id']; ?>"   >
         <?php  $nInterval = strtotime(date('Y-m-d H:i:s')) - strtotime($row_pro['created_datetime']);  $min=$nInterval/60;  ?>
                                    <?php if($min>10){ ?>
                                         <a href="javascript:void(0)" onclick="deleteQuestion(<?php echo $row_pro['q_id']; ?>)"><img class="close-btn-png my-q-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close"></a>
                                <?php    }


                                     ?>
        <?php if (in_array($row_pro['q_id'], $cmntid)) { ?>
                <span class="progress-comment"><a href="<?php echo site_url('ask_questions/give_input/' . $row_pro['q_id'] . "/" . $row_pro['answerBy']); ?>" class="" style="text-decoration: none;color:#fff;">Click this box to give input</a></span>
                 <?php } ?>
            <h4 class="text-left" style="font-size: 13px; font-weight: 600;color: #666564;margin-bottom: 0px;">
            <?php if ($row_pro['updated_question']!='') {
              echo @$row_pro['updated_question'];
            }else{
                 echo @$row_pro['questionTitle']; 
            }?>

            </h4>
           <!--   <h6> <?php //echo @$row_pro['updated_question']; ?></h6> -->
            <div class="progesOuterBox">
            

                    <?php if (@$row_pro['process_indicator'] == 'progress-12') { ?>
                        <div class="user-progress-text1"  id="u_process_1" ><b>Understanding</b><br/>your question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-36') {
                        ?>
                        <div class="user-progress-text2"  id="u_process_2" ><b>Researching</b><br/>your question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-60') {
                        ?>
                        <div class="user-progress-text3"  id="u_process_3" ><b>Answering</b><br/>your question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-85') {
                        ?>
                        <div class="user-progress-text4"  id="u_process_3" ><b>Briefing</b><br/>you on the answer.</div>
                    <?php } ?> 
               
                    <?php
                    if ($row_pro['isCompleted'] == "") {
                        $process_indicator = 'progress-0';
                    } else {
                        $process_indicator = $row_pro['process_indicator'];
                    }
                    ?>
                    <div class="progress-circle <?php echo @$process_indicator; ?>">
                        <span><?php //echo @$pro_per[1];   ?></span>
                    </div>                    
                    <div class="" style="float: right;">
                        <span><?php //echo $row_pro['message'];     ?></span>
                    </div>  
            </div>            
        </div>
<?php } ?>
</div>