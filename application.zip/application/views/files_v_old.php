<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Sokrates</title>
        <!--<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/cufon-yui.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/arial.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/cuf_run.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/radius.js"></script>
        <style>
            body {
                background: #f7f7f7;
                font-family: 'Montserrat', sans-serif;
            }

            .dropzone {
                background: #fff;
                border: 2px dashed #ddd;
                border-radius: 5px;
            }

            .dz-message {
                color: #999;
            }

            .dz-message:hover {
                color: #464646;
            }

            .dz-message h3 {
                font-size: 200%;
                margin-bottom: 15px;
            }

            form.example input[type=text] {
                padding: 2px;
                font-size: 13px;
                float: left;
                width: 70%;
                background: #fff;
            }

            form.example button {
                float: left;
                width: 15%;
                padding: 4px;
                background: #2196F3;
                color: white;
                font-size: 17px;
                border-left: none;
                cursor: pointer;
                border: none;
            }

            form.example button:hover {
                background: #0b7dda;
            }

            form.example::after {
                content: "";
                clear: both;
                display: table;
            }
        </style>
    </head>
    <body>
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>
                            <!--<li id="HOME"><a href="<?php //echo site_url("home");            ?>">Home</a></li>-->
                            <!--                            <li><a href="support.html">Support</a></li>
                                                        <li><a href="about.html">About Us</a></li>-->



                            <?php if ($this->session->userdata('user_id') != "") { ?>
                                <li id="SIGNUP" ><a href="<?php echo site_url("ask_questions/questions/"); ?>">My Questions</a></li>
                                <li id="ASKQUESTION"><a href="<?php echo site_url("ask_questions"); ?>">Ask Question</a></li>
                                <li id="ASKQUESTION"><a href="<?php echo site_url("files"); ?>">My Files</a></li>
                                <li><a href="<?php echo site_url("logout"); ?>">Logout</a></li>
                            <?php } else { ?>
                                <li id="LOGIN"><a href="<?php echo site_url("login_c"); ?>">Login</a></li>
                                <li id="SIGNUP" ><a href="<?php echo site_url("register"); ?>">SignUp</a></li>
                            <?php } ?>
                            <?php if ($this->session->userdata('user_id') != "") { ?>    

                                <li class="dropdown">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $this->session->userdata('email'); ?>
                                        <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Yearly Subscription</a></li>
                                        <li><a href="<?php echo site_url("change_password/"); ?>">Change Password</a></li>

                                    </ul>
                                </li>

                            <?php } ?>
                        </ul>
                    </div>
                    <div class="logo">
                        <h1><a href="<?php echo site_url("home"); ?>">Sokrates</a> <small></small></h1>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <div class="content_resize">

                    <div class="mainbar">

                        <div class="col-lg-12 text-right">

                            <form class="example" action="<?php echo site_url('ask_questions/search_answer/' . $this->uri->segment(3)); ?>" method="post" style="float: right;max-width:300px;margin-top: 10px;">
                                <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                                <button type="submit"><i class="fa fa-search"></i></button>

                            </form>
                            <a href="#" data-toggle="modal" data-target="#myModal" style="margin-right: 15px; line-height: 3; font-size: 15px;"> Add Files</a>
                        </div>
                        <!--            <div class="article">
                                        <h2><span>Question</span> </h2>
                                        <div class="clr"></div>
                                        <p>Posted by <a href="#"><?php //echo @$question->firstName;    ?></a> </p>
                                        <p><?php //echo @$question->questionTitle;    ?></p>
                                        <p>Tagged: <a href="#">orci</a>, <a href="#">lectus</a>, <a href="#">varius</a>, <a href="#">turpis</a></p>
                                        <p><a href="#"><strong>Comments (3)</strong></a> <span>&nbsp;&bull;&nbsp;</span> May 27, 2010 <span>&nbsp;&bull;&nbsp;</span> <a href="#"><strong>Edit</strong></a></p>
                                    </div>-->
                        <div class="article">
                            <h2><span>10</span> Files</h2>
                            <div class="clr"></div>

                            <div class="comment"> 
                                <a href="#">
                                    <img src="#" width="40" height="40" alt="" class="userpic" />
                                </a>
                                <p>
                                    <a href="#">hardik</a> Says:<br />
                                    4 July, 2018</p>
                                <p>
                                    test
                                </p>
                            </div>

                        </div>

                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Modal Header</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="col-lg-4" style="border-right: 1px solid #DDDDDD;">
                                                <div class="col-lg-12" style="padding:0;">
                                                    <div class="form-group">
                                                        <label for="comment">Select Tag</label>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 1</label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 2</label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 1</label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 2</label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 1</label>
                                                        </div>
                                                        <div class="checkbox">
                                                            <label><input type="checkbox" value="">Option 2</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12" style="padding:0;">
                                                    <div class="form-group">
                                                        <label for="comment">Comment:</label>
                                                        <textarea class="form-control" rows="5" id="comment"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-8">
                                                <div id="content">
                                                    <div id="my-dropzone" class="dropzone">
                                                        <div class="dz-message">
                                                            <h3>Drop files here</h3> or <strong>click</strong> to upload
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--<div class="sidebar">
                <div class="searchform">
                    <form id="formsearch" name="formsearch" method="post" action="#">
                        <span>
                            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
                        </span>
                        <input name="button_search" src="<?php echo base_url(); ?>assets/images/search_btn.gif" class="button_search" type="image" />
                    </form>
                </div>
                <div class="gadget">
                    <h2 class="star">Popular Categories</h2>
                    <div class="clr"></div>
                    <ul class="sb_menu">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Template Info</a></li>
                        <li><a href="#">Style Demo</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Archives</a></li>
                    </ul>
                </div>
                <div class="gadget">
                    <h2 class="star"><span>Sponsors</span></h2>
                    <div class="clr"></div>
                    <ul class="ex_menu">
                        <li><a href="#">Lorem ipsum dolor</a><br />
                            Donec libero. Suspendisse bibendum</li>
                        <li><a href="#">Dui pede condimentum</a><br />
                            Phasellus suscipit, leo a pharetra</li>
                        <li><a href="#">Condimentum lorem</a><br />
                            Tellus eleifend magna eget</li>
                        <li><a href="#">Fringilla velit magna</a><br />
                            Curabitur vel urna in tristique</li>
                        <li><a href="#">Suspendisse bibendum</a><br />
                            Cras id urna orbi tincidunt orci ac</li>
                        <li><a href="#">Donec mattis</a><br />
                            purus nec placerat bibendum</li>
                    </ul>
                </div>
            </div>-->
                    <div class="clr"></div>
                </div>
            </div>
            <!--<div class="fbg">
                <div class="fbg_resize">
                    <div class="col c1">
                        <h2><span>Image Gallery</span></h2>
                        <a href="#"><img src="<?php echo base_url(); ?>assets/images/pix1.jpg" width="58" height="58" alt="" /></a> 
                        <a href="#"><img src="<?php echo base_url(); ?>/assets/images/pix2.jpg" width="58" height="58" alt="" /></a> 
                        <a href="#"><img src="<?php echo base_url(); ?>assets/images/pix3.jpg" width="58" height="58" alt="" /></a> 
                        <a href="#"><img src="<?php echo base_url(); ?>assets/images/pix4.jpg" width="58" height="58" alt="" /></a> 
                        <a href="#"><img src="<?php echo base_url(); ?>assets/images/pix5.jpg" width="58" height="58" alt="" /></a> 
                        <a href="#"><img src="<?php echo base_url(); ?>assets/images/pix6.jpg" width="58" height="58" alt="" /></a> 
                    </div>
                    <div class="col c2">
                        <h2><span>Lorem Ipsum</span></h2>
                        <p>Lorem ipsum dolor<br />
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. Cras id urna. <a href="#">Morbi tincidunt, orci ac convallis aliquam</a>, lectus turpis varius lorem, eu posuere nunc justo tempus leo. Donec mattis, purus nec placerat bibendum, dui pede condimentum odio, ac blandit ante orci ut diam.</p>
                    </div>
                    <div class="col c3">
                        <h2><span>Contact</span></h2>
                        <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue.</p>
                        <p><a href="#">support@yoursite.com</a></p>
                        <p>+1 (123) 444-5677<br />
                            +1 (123) 444-5678</p>
                        <p>Address: 123 TemplateAccess Rd1</p>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>-->
            <div class="footer">
                <div class="footer_resize">
                    <p class="lf">Copyright &copy; 2018 <a href="#">Sokrates</a> - All Rights Reserved</p>
                    <!--<p class="rf">Design by <a href="http://www.coolwebtemplates.net/">Cool Website Templates</a></p>-->
                    <div class="clr"></div>
                </div>
            </div>
        </div>
<!--        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>vendor/jquery/jquery.min.js"></script>-->
        <script src="<?php echo base_url(); ?>vendor/dropzone/dropzone.min.js"></script>
        <script>
            Dropzone.autoDiscover = false;
            var myDropzone = new Dropzone("#my-dropzone", {
                
                url: "<?php echo site_url("images/upload") ?>",
                
                acceptedFiles: "image/*",
                addRemoveLinks: true,
                removedfile: function (file) {
                    var name = file.name;

                    $.ajax({
                        type: "post",
                        url: "<?php echo site_url("images/remove") ?>",
                        data: {file: name},
                        dataType: 'html'
                    });

                    // remove the thumbnail
                    var previewElement;
                    return (previewElement = file.previewElement) != null ? (previewElement.parentNode.removeChild(file.previewElement)) : (void 0);
                },
                init: function () {
                    var me = this;
                    $.get("<?php echo site_url("images/list_files") ?>", function (data) {
                        // if any files already in server show all here
                        if (data.length > 0) {
                            $.each(data, function (key, value) {
                                var mockFile = value;
                                me.emit("addedfile", mockFile);
                                me.emit("thumbnail", mockFile, "<?php echo base_url(); ?>uploads/" + value.name);
                                me.emit("complete", mockFile);
                            });
                        }
                    });
                }
            });
        </script>
    </body>
</html>