<style>
    .nav>li>a:focus, .nav>li>a:hover {
        text-decoration: none; 
        background-color: #F9F8F8;

    }
    .active_my_tab{
        background-color: #fff;
        border-left: 2px solid #F9F8F8!important;
        font-size: 12px;
        font-weight: bold;
        color:#201F1F !important;
    }
</style>
<a href="javascript:void(0)" onclick="closeNav('MenuPopup')"><img class="close-btn-png my-q-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close" class="img-responsive" /></a>           
<div class="container-sokrates">
    <div class="col-lg-12  question-div clearfix" >
        <div class="col-lg-3 col-sm-3 noPadding question-title-div" >
            <h3>My Questions</h3>
            <small>My Questions has <?php echo $progress_count->progress_count; ?> Questions.</small>
        </div>
        <div class="col-lg-9 col-sm-9 noPadding">
            <div class="question-ser-div">
                <i class="fa fa-search my-q-ser-icon"></i>
                <input onkeyup="serQuestion(this.value, 'MYProgress');" type="text"  name="ser" class="form-control my-q-ser" placeholder="My Questions Search" />
                <small>sort by &nbsp; 
                    <a id="iSortDate" onclick="serQuestion('sort_date');" href="javascript:void(0)" data-item="ASC">
                        date
                    </a> &nbsp; &nbsp;
                    <a id="iSortAbc" onclick="serQuestion('sort_abc');" href="javascript:void(0)" data-item="ASC">
                        alphabetically^
                    </a>
                </small>
            </div>
        </div>
    </div>
    <div class="col-lg-12 q-and-answer" id="iMyQList" >
        <div class="main-myq-tab-div">
            <ul class="nav nav-tabs my-q-nav">
                <li class=""><a onclick="openNav('My_Questions');" href="javascript:void(0)"  data-toggle="tab" href="#Questions">Questions</a></li>
                
                <li>
                    <a class="active_my_tab" data-toggle="tab" href="javascript:void(0)" >Progress
                        <?php if (isset($progress_count->progress_count) && $progress_count->progress_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $progress_count->progress_count; ?>
                            </span>
                        <?php }
                        ?>
                    </a>
                </li>
                <li>
                    <a onclick="openNav('New_answer');"  data-toggle="tab" href="javascript:void(0)">New answers
                        <?php if (isset($ans_count->ans_count) && $ans_count->ans_count != 0) { ?>            
                            <span class="header_q_count" style="font-size: 14px;padding: 0px 6px 2px 3px;border-radius: 14px; font-weight: bold;"> 
                                <?php echo $ans_count->ans_count; ?>
                            </span>            
                        <?php } ?>
                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <div id="Questions" class="tab-pane fade in active">
                    <div class="question-tab-data" id="iAjaxResult">
                        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/progress-circle.css">

                        <div class="row text-left" style="padding: 10px 225px;" >    
                            <?php
                            $sql_c_arr = $this->db->query("SELECT questionID FROM `tbl_mycomments` WHERE questionBy = '" . $this->session->userdata('user_id') . "' and messageBy != '" . $this->session->userdata('user_id') . "' AND isRead = 0 AND isDeleted = 0 AND is_final=0 GROUP BY questionID");
                            $sql_c_arr->result_array();
                            if (!empty($sql_c_arr->result_array())) {
                                foreach ($sql_c_arr->result_array() as $rowcid) {
                                    $cmntid[] = $rowcid['questionID'];
                                }
                            } else {
                                $cmntid[] = "";
                            }
                            //print_r($user_pro_data); 
                            foreach ($user_pro_data as $key => $row_pro) {
                                if (in_array($row_pro['qiestion_id'], $cmntid)) {
                                    echo "res-com-act";
                                    $qid = $rowcid['questionID'];
                                    $user_pro_data[$key] += ["qid" => $qid];
                                    //array_merge($user_pro_data[$key], array('qid'=>$qid));
                                } else {
                                    $user_pro_data[$key] += ["qid" => 0];
                                    //echo "res-com-inct";
                                }
                            }
                            $keys = array_column($user_pro_data, 'qid');
                            array_multisort($keys, SORT_DESC, $user_pro_data);
                            $count=0;
                            foreach ($user_pro_data as $row_pro) {
                               
                                $count++;
                                ?>
                                            <!--<h4 style="font-size: 16px; font-weight: 600;color: #666564;;"><?php echo @$row_pro['questionTitle']; ?></h4>-->
                                <div class="col-md-12 main-pro-div-pos <?php
                            if (in_array($row_pro['qiestion_id'], $cmntid)) {
                                echo "res-com-act";
                            } else {
                                echo "res-com-inct";
                            }
                                ?>" <?php if (in_array($row_pro['qiestion_id'], $cmntid)) { ?>onclick='window.location = "<?php echo site_url('ask_questions/give_input/' . $row_pro['qiestion_id'] . "/" . $row_pro['answerBy']); ?>"' <?php } ?>  id="qblock<?php echo $row_pro['qiestion_id']; ?>">
                                    <?php  $nInterval = strtotime(date('Y-m-d H:i:s')) - strtotime($row_pro['created_datetime']); $min=$nInterval/60;  ?>
                                    <?php if($min>10){ ?>
                                         <a href="javascript:void(0)" onclick="deleteQuestion(<?php echo $row_pro['qiestion_id']; ?>)"><img class="close-btn-png my-q-close-btn" src="<?php echo base_url() . IMAGE_COM . "close-btn.png"; ?>" alt="Close"></a>
                                <?php    }


                                     ?>
                               

                                     <?php if (in_array($row_pro['qiestion_id'], $cmntid)) { ?>
                                        <span class="progress-comment"><a href="<?php echo site_url('ask_questions/give_input/' . $row_pro['qiestion_id'] . "/" . $row_pro['answerBy']); ?>" class="" style="text-decoration: none;color:#fff;">Click this box to give input</a></span>
                                    <?php } ?>
                                    <h4 class="text-left" style="font-size: 13px; font-weight: 600;color: #666564;margin-bottom: 0px;">
                                        <?php if ($row_pro['updated_question']!='') {
                                            echo @$row_pro['updated_question'];
                                        }else{
                                           echo @$row_pro['questionTitle']; 
                                        }  ?>
                                    </h4>
                                   <!--  <h6> <?php //echo @$row_pro['updated_question']; ?></h6> -->
                                    <div class="progesOuterBox">
                                         <?php if (@$row_pro['process_indicator'] == 'progress-12') { ?>
                                            <div class="user-progress-text1"  id="u_process_1" ><b>Understanding</b><br/>your question.</div>
                                        <?php
                                        }
                                        if (@$row_pro['process_indicator'] == 'progress-36') {
                                            ?>
                                            <div class="user-progress-text2"  id="u_process_2" ><b>Researching</b><br/>your question.</div>
                                        <?php
                                        }
                                        if (@$row_pro['process_indicator'] == 'progress-60') {
                                            ?>
                                            <div class="user-progress-text3"  id="u_process_3" ><b>Answering</b><br/>your question.</div>
                                        <?php
                                        }
                                        if (@$row_pro['process_indicator'] == 'progress-85') {
                                            ?>
                                            <div class="user-progress-text4"  id="u_process_3" ><b>Briefing</b><br/>you on the answer.</div>
                                            <?php
                                        }
                                        ?>  
                                        <?php
                                        if ($row_pro['isCompleted'] == "") {
                                            $process_indicator = 'progress-0';
                                        } else {
                                            $process_indicator = $row_pro['process_indicator'];
                                        }
                                        ?>
                                        <div class="progress-circle <?php echo @$process_indicator; ?>">
                                            <span><?php //echo @$pro_per[1];      ?></span>
                                        </div>
                                        <div class="" style="float: right;">
                                            <span><?php //echo $row_pro['message'];  ?></span>
                                        </div>
                                    </div>
                                </div>
<?php } echo $count;?>
                        </div>
                    </div>
                </div>

            </div>
        </div>        
    </div> 
</div>
<script>
//    setTimeout(function () {
//        // Do something after 1 second 
//        openNav('Progress');
//    }, 10000);
    // setTimeout(openNav('Progress'),10000);
    // clearTimeout();
</script>