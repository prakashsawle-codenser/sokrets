
<div class="content">
    <div class="content_resize">
        <div  class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>
                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <div class="col-lg-12 text-right" style="padding: 0">
                    <form class="example" action="<?php echo site_url('ask_questions/researcher_list/'.$this->uri->segment('3').'/'.$this->uri->segment('4')); ?>" method="post" style="margin: 0 0 20px 0;">
                        
                        <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div style="clear: both">
                    
                        <h3 style="color:#1D1D1B;display: inline-block;font-size: 20px;margin-top: 10px;">Researcher List</h3>
                   
                    <div class="clr"></div>

                    <div class="comment" style="padding:0 !important;"> 
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr style="color: #1D1D1B;font-size: 16px;">
                                    <th width="40%">Researcher Name</th>
                                    <th width="40%">Email</th>
                                    <th width="20%">Action</th>
                                </tr>
                                <?php
                                //print_r($this->session->userdata('upload_file'));    
                                foreach ($researcher as $row) {
                                    ?>
                                    <tr style="font-size: 14px;">
                                        <td>                                            
                                            <?php echo @$row['firstName']." ".@$row['lastName']; ?>
                                        </td> 
                                        <td>                                            
                                            <?php echo @$row['email']; ?>
                                        </td>  
                                        <td>
                                            <a style="text-decoration: none;" href="<?php echo site_url('ask_questions/transfer_researcher/'.$this->uri->segment('3').'/'.$this->uri->segment('4').'/'.$row['id']); ?>" alt="assign question" title="Edit" ><img class="img-responsive" style="border: none;width: 11%;display: inline-block;" src="<?php echo base_url().IMAGE_COM."assign-user.png"; ?>" />Transfer question</a>
                                        </td>
                                    </tr>                                    
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Modal -->

        <script>

            $(document).ready(function () {

                $("#a11").removeClass().addClass('active');
                $('#msg').delay(4000).fadeOut();
            });

        </script>

