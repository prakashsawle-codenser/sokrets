<?php ini_set(error_reporting(0)); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
         <link rel='icon' href="<?php echo base_url(); ?>uploads/doc_image/sokrates_app_logo.png" type='image/png'/ >
        <!--        bootstrap live link   start -->
        <link href="<?php echo base_url(); ?>assets/css/responsive-login.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link href="<?php echo base_url(); ?>assets/css/login.css" rel="stylesheet" type="text/css" />
        <style>
            input:-webkit-autofill {
                -webkit-box-shadow: 0 0 0 30px white inset;

            }              
            .form-control:focus {
                border-color: #fff;
                -webkit-box-shadow: white !important;
            }
            input:-webkit-autofill {
                -webkit-text-fill-color: #7C7C7C !important;
                -webkit-text-fill-font-size: 15px !important;
            }
        </style>
    </head>
    <body>  
        <div class="main">
            <div class="container">
                <div class="row main-row">
                    <div class="col-lg-12 logo-div">
                        <img src="<?php echo base_url() . IMAGE_COM . '/login-logo.png' ?>" class="img-responsive logo" />
                 
                    </div>
                    <div class="col-lg-12 text-center">                        
                        <h2 class="signin-text" >Researcher Sign in to Sokrates </h2>
                    </div>
                    <div class="col-lg-12">
                        <div class="login-section" >
                            <div class="row">
                                <?php if ($this->session->flashdata('register_success')) : ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-success" role="alert" style="color:#5DB166;">
                                            <?php echo $this->session->flashdata('register_success'); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php
                            if ($this->session->flashdata('error')) {
                                echo '<span style="color:#ff0000c7;padding-left: 8px;">' . $this->session->flashdata('error') . '</span>';
                            }
                            ?>
                            <form action="<?php echo site_url("researcher_login/check_login"); ?>" method="post" id="sendemail">
                                <div class="col-lg-12 noPadding login-form" >
                                    <div class="form-group login-id-div" >
                                        <input placeholder="Sokrates ID" class="login-input" id="email" name="email" class="text"  <?php if ($_COOKIE['email']!='') {?> value="<?php echo $_COOKIE['email'];  ?>" <?php } ?>  />
                                    </div>
                                    <div class="form-group login-pass-div" >
                                        <input placeholder="Password" class="login-input" id="password" type="password" name="password" class="text"  <?php if ($_COOKIE['password']!='') {?> value="<?php echo $_COOKIE['password'];  ?>" <?php } ?>   />
                                    </div> 
                                    <div class="login-btn-div">
                                        <button class="login-btn-new" type="submit">
                                            <!--<i  class="fa fa-arrow-circle-o-right"></i>-->
                                        </button>
                                    </div>
                                </div>
                           
                        </div>
                        <div class="col-lg-12 noPadding text-center" style="margin-top: 7px;">
                            <label class="checkbox-inline qcustom-check">
                                <input id="ichk_lib" name="remember_me" type="checkbox" value="yes" >
                                Keep me signed in
                                <span class="qcheckmark"></span>
                            </label>
                        </div>
                         </form>
                        <div class="col-lg-12 noPadding text-center" style="margin-top: 7px;">
                            <a data-toggle="modal" data-target="#forgotPasswordModal" style="text-decoration: none;color:#fff;" class="forgot-div" href="">Forgot Sokrates ID or password?</a>
                            <div class="clr"></div>
                        </div>

                        <div class="col-lg-12 noPadding text-center" style="margin-top: 7px;">
                            <a  style="text-decoration: none;color:#fff;" class="forgot-div" href="<?= base_url();?>create_sokrets_id">Create Sokrates ID</a>
                            <div class="clr"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="forgotPasswordModal" role="dialog">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Please enter your email address </h4>
                        </div>
                        <form action="<?php echo site_url("register/submit_email/"); ?>" method="post" enctype="multipart/form-data" id="form-forgot-pass">
                            <div class="modal-body" style="padding: 50px 30px;">
                                <label for="email">Email (required)</label>
                                <input type="email" required class="form-control frm-l-s" name="user_email"  />
                            </div>
                            <div class="modal-footer">
                                <button style="background-color: #E40613;color: #fff;" id="submit-email" class="btn" type="submit" name="submit" >Submit</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

