<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--        bootstrap live link   start -->
        <link href="<?php echo base_url(); ?>assets/css/responsive-login.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!--  end-->
       <!--<link rel="stylesheet" href="<?php echo base_url(); ?>assets/drag_and_drop/css/style.css" />-->

        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />

        <style>

            body{
                font-family: "Helvetica";
                /*background: url(assets/images/skyline.png);*/
                background: linear-gradient( rgba(0,0,0,0.1), rgba(0, 0, 0, 0.4) ),url(assets/images/skyline.png);
                margin: 0;
                padding: 0;
                width: 100%;
                height: 100%;
                background-repeat: no-repeat;
                background-position: 23% 15%;
                background-size: 237% 150%;
            }
            .head-drop li a:hover{
                border-bottom: none !important;              
            }
            .content .mainbar img {
                border: none;
                margin: auto;
                width: 6.5%;
            }
            input:-webkit-autofill {
                -webkit-box-shadow: 0 0 0 30px white inset;

            }              
            .form-control:focus {
                border-color: #fff;
                -webkit-box-shadow: white !important;
            }
            input:-webkit-autofill {
                -webkit-text-fill-color: #7C7C7C !important;
                -webkit-text-fill-font-size: 15px !important;
            }
        </style>
    </head>
    <body>     
        <div id="MenuPopup" class="sidenav">
            <!--            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>           
                        <div class="container-sokrates">
                            <div class="row"  class="data-div" id="data-div">
            
                            </div>
                        </div>-->
        </div>
        <!-- START PAGE SOURCE -->
        <?php
        if (@$this->session->userdata('user_id') != "") {
            $uid = $this->session->userdata('user_id');
            $sql_q = "SELECT count(*) as q_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa";
            //$sql_q = "SELECT COUNT(id) as q_count FROM `questions` WHERE userID = $uid AND isRead = 0 AND isDeleted = 0";
            $query_q = $this->db->query($sql_q);
        }
        ?>  
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>

                            <!--<li id="LOGIN"><a href="<?php echo site_url("login_c"); ?>">Login</a></li>-->                      

                        </ul>
                    </div>
                    <div class="logo">
                        <div class="col-lg-12" class="noPadding" style="width: 86%;">
<!--                            <span class="logo-text">SOKRATES</span>-->
                            <!--<a href="<?php echo site_url("Login_c"); ?>"><img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a> <small></small>-->
                        </div>
                        <div class="col-lg-6" class="noPadding" style="text-align:center;">
                            <!--<span class="opennav"  onclick="openNav();">&#9776;</span>-->
                        </div>
                    </div>
                    <div class="clr"></div>
                </div>
            </div>
            <div class="content">
                <center>
                    <h4>Your safari browser version should be above 11. Please update your safari browser.</h4>
                </center>
            </div>   
        </div>
    </body>
</html>

