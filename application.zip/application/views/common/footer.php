<!--<div id="refresh-notification">
    <?php
//    if ($this->session->userdata('user_id') != "") {
//        $id = $this->session->userdata('user_id');
//
//        $sql = "SELECT a.id,b.questionTitle FROM answer a, questions b WHERE a.questionBy = $id AND a.notificationStatus = 0 and a.progress_status = 4 and a.questionID = b.id AND a.isDeleted = 0 LIMIT 1";
//        $query = $this->db->query($sql);
//
//        if ($query->num_rows() > 0) {
//            //print_r($row->id); exit;
//            foreach ($query->result() as $row) {
//                $notimsg = "Hi, '" . $this->session->userdata('firstName') . "'. I have found an answer to your question:\n";
//                $notimsg .= "“" . $row->questionTitle . "”";
//                //$notimsg =. $row->questionTitle;
//                ?>
                <input type="hidden" value="//<?php echo @$row->id; ?>" id="nitufyid" />

                //<?php
//                //$sql1 = "UPDATE `answer` SET `notificationStatus` = '1' WHERE `questionBy` = $id and `id` = $row->id ";
//                //$query1 = $this->db->query($sql1);
//            }
//        }
//    }
    ?>  
</div>-->


<script>
//    var auto_refresh = setInterval(
//            function ()
//            {
//                $("#refresh-notification").load(location.href + " #refresh-notification");
//                var nid = $('#nitufyid').val(); //alert(nid);
//                if (nid != "" && nid != undefined) {
//                    notifyMe()
//                    $('#nitufyid').val("")
//                }
//
//            }, 10000); // refresh every 10000 milliseconds
//    $(document).ready(function () {
//
//    });
//
//    function notifyMe() {
//        // Let's check if the browser supports notifications
//        if (!("Notification" in window)) {
//            alert("This browser does not support desktop notification");
//        }
//
//        // Let's check if the user is okay to get some notification
//        else if (Notification.permission === "granted") {
//            // If it's okay let's create a notification
//            var options = {
//                body: "<?php echo @$notimsg; ?>",
//                icon: "<?php echo base_url() . IMAGE_COM . "logo.png"; ?>",
//                dir: "ltr"
//            };
//            var notification = new Notification("Sokrates", options);
//        }
//
//        // Otherwise, we need to ask the user for permission
//        // Note, Chrome does not implement the permission static property
//        // So we have to check for NOT 'denied' instead of 'default'
//        else if (Notification.permission !== 'denied') {
//            Notification.requestPermission(function (permission) {
//                // Whatever the user answers, we make sure we store the information
//                if (!('permission' in Notification)) {
//                    Notification.permission = permission;
//                }
//
//                // If the user is okay, let's create a notification
//                if (permission === "granted") {
//                    var options = {
//                        body: "This is the body of the notification",
//                        icon: "<?php echo base_url() . IMAGE_COM . "logo.png"; ?>",
//                        dir: "ltr"
//                    };
//                    var notification = new Notification("Hi there", options);
//                }
//            });
//        }
//
//        // At last, if the user already denied any notification, and you
//        // want to be respectful there is no need to bother them any more.
//    }
//    function openNav(val) {
//        if (val == 'My_Questions') {
//
//            $.ajax({
//                url: '<?php echo site_url("ask_questions/get_my_question/"); ?>',
//                type: "POST",
//                contentType: false,
//                cache: false,
//                processData: false,
//                success: function (data)
//                {
//                    $("#data-div").html(data);
//                }
//            });
//        }
//        document.getElementById("MenuPopup").style.width = "85%";
//    }
//
//    function closeNav() {
//        document.getElementById("MenuPopup").style.width = "0";
//    }
//    function serQuestion(val) {
//        var formData = new FormData();
//        formData.append('ser', val);
//        $.ajax({
//            url: '<?php echo site_url("ask_questions/serQuestion/"); ?>',
//            type: "POST",
//            data: formData,
//            contentType: false,
//            cache: false,
//            processData: false,
//            success: function (data1)
//            {
//                $("#iMyQList").html(data1);
//            }
//        });
//    }

</script>

<div class="clr"></div>
</div>
</div>

<div class="footer">
    <div class="footer_resize">
        <p class="lf">Copyright © 2018 <a href="#">Sokrates Technologies.</a> All rights reserved.</p>        
        <div class="clr"></div>
    </div>
</div>
</div>
<!-- END PAGE SOURCE -->

</body>
</html>

