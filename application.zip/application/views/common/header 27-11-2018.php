<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Sokrates</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--        bootstrap live link   start -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" />
        <script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>    
        <script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!--  end-->
       <!--<link rel="stylesheet" href="<?php echo base_url(); ?>assets/drag_and_drop/css/style.css" />-->

        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />
        <style>
            .head-drop li a:hover{
                border-bottom: none !important;              
            }
        </style>
    </head>
    <body>     
        <div id="MenuPopup" class="sidenav">

        </div>
        <div id="MenuPopupLib" class="sidenav">

        </div>
        <div id="iNavSideMenu" class="sidenav_menu">

        </div>
        <!-- START PAGE SOURCE -->
        <?php
        if (@$this->session->userdata('user_id') != "") {
            $uid = $this->session->userdata('user_id');
            $sql_q = "SELECT count(*) as q_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa";
            //$sql_q = "SELECT COUNT(id) as q_count FROM `questions` WHERE userID = $uid AND isRead = 0 AND isDeleted = 0";
            $query_q = $this->db->query($sql_q);
        }
        ?>  
        <div class="main">
            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>
                            <?php
                            if ($this->session->userdata('user_id') != "") {

                                if ($this->session->userdata('userType') == "1") {
                                    ?>
                                    <!--<li id="HOME"><a href="<?php echo site_url("home"); ?>">Home</a></li>-->
                                    <li id="ASKQUESTION"><a href="<?php echo site_url("ask_questions"); ?>">Home</a></li>
                                    <!--<li id="ASKQUESTION"><a href="<?php echo site_url("ask_questions"); ?>">Ask Question</a></li>-->

                                    <li id="MYQUESTION" >
                                        <a style="display:inline-block;padding-right: 0;"  href="javascript:void(0)"  onclick="openNav('My_Questions');" >My Questions</a>
                                        <?php if (@$query_q->first_row()->q_count != 0) { ?>
                                            <a style="display:inline-block;padding: 0;" href="<?php echo site_url("home"); ?>">
                                                <span style="height: 20px;width: 20px;font-size: 13px;padding: 2px 6px 2px 2px;" class="header_q_count"><?php echo @str_pad($query_q->first_row()->q_count, 2, "0", STR_PAD_LEFT); ?></span>
                                            </a>
                                        <?php } ?>
                                    </li>
                                    <!--<li id="MYFILES"><a href="<?php echo site_url("my_files"); ?>">My Library</a></li>-->
                                    <li id="MYLIBRARY" >
                                        <a   href="javascript:void(0)"  onclick="openNav('My_Library');" >BookShelf</a>
                                    </li>
                                    <?php
                                }
                                if ($this->session->userdata('userType') == "2") {
                                    ?><?php //echo site_url("ask_questions/questions/"); href="javascript:void(0)" onclick="openNav('My-Questions');"  ?>
                                    <li id="MYQUESTION" ><a href="<?php echo site_url("ask_questions/questions/");    ?>"  >My Questions</a></li>
                                    <!--<li id="MYQUESTION" ><a  href="javascript:void(0)"  onclick="openNav('My_Questions');" >My Questions</a></li>-->
                                    <?php
                                }
                            } else {
                                ?>
                                <li id="LOGIN"><a href="<?php echo site_url("login_c"); ?>">Login</a></li>
    <!--                                <li id="SIGNUP" ><a href="<?php echo site_url("register"); ?>">SignUp</a></li>-->
                            <?php } ?>
                            <?php if ($this->session->userdata('user_id') != "") { ?>    

                                <li id="USERM1"  class="dropdown">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo "Hi, " . $this->session->userdata('firstName'); ?>
                                        <span class="caret"></span></a>
                                    <ul class="dropdown-menu head-drop" style="left:-60px;">
                                        <?php if ($this->session->userdata('userType') == "1") { ?>
                                            <li><a href="<?php echo site_url("subscription/"); ?>">My Subscription</a></li>
                                        <?php } else { ?> 
                                            <li><a href="<?php echo site_url("pro_message/"); ?>">Progress Messages</a></li> 
                                            <li><a href="<?php echo site_url("standard_answers/"); ?>">Standard Answers</a></li>
                                        <?php } ?>
<!--                                        <li><a href="<?php echo site_url("my_activity/"); ?>">My Activity</a></li>-->
                                        <li><a href="<?php echo site_url("register/my_profile/"); ?>">My Profile</a></li>    
                                        <li><a href="<?php echo site_url("change_password/"); ?>">Change Password</a></li>
                                        <li><a href="<?php echo site_url("logout"); ?>">Logout</a></li>
                                    </ul>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <div class="logo">
                        <!--<span class="logo-text">SOKRATES</span>-->
                        <a href="<?php echo site_url("Login_c"); ?>"><img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a> 
                        <img class="opennav"  onclick="openNavSideMenu();" src="<?php echo base_url() . IMAGE_COM; ?>bar.png" class="img-responsive bar-image" />
                        <!--<span class="opennav"  onclick="openNavSideMenu();">&#9776;</span>-->
                        <!--<span class="opennav"  onclick="openNavSideMenu();"><i class="fa fa-bars"></i></span>-->
                    </div>
                    <div class="clr"></div>
                </div>
            </div>