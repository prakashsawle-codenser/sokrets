<!--<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/nicEdit/nicEdit-latest.js"></script>
<style>
    form.example input[type=text] {
        padding: 2px;
        font-size: 13px;
        float: left;
        width: 70%;
        background: #fff;
    }
    form.example button {
        float: left;
        width: 15%;
        padding: 6px;
        background: #2196F3;
        color: white;
        font-size: 17px;
        border-left: none;
        cursor: pointer;
        border: none;
    }
    form.example button:hover {
        background: #0b7dda;
    }
    form.example::after {
        content: "";
        clear: both;
        display: table;
    }
    .answerCount{
        background: #5DB368;
        color: #fff;
        line-height: 35px;
        margin-bottom: 0;
        padding-left: 10px;
        padding-top: 9px;
        font-weight: bold;
        font-size: 24px;
    }
    .comment{
        margin-bottom: 10px !important;
        border: 1px solid #c0c0c061;
        padding: 5px 15px !important;
        border-radius: 5px;
    }
    .copyclip{
        float: right;
        font-size: 17px;
        background: #5DB368;
        padding: 5px;
        color: #fff;
        cursor: pointer;
    }
    .reply{
        float: right;
        font-size: 17px;
        background: #5DB368;
        padding: 5px;
        margin-right: 10px;
        color: #fff;
    }
    
</style>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>

                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <!--            <div class="col-lg-12 text-right">
                            <form class="example" action="<?php echo site_url('ask_questions/search_answer/' . $this->uri->segment(3)); ?>" method="post" style="float: right;max-width:300px;margin-top: 10px;">
                                <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>-->
            <div class="article">
                <h2 class="ans_q_title" ><?php echo @$question->questionTitle; ?> </h2>
                <div class="clr"></div>
                <p>Posted by <a href="#"><?php echo @$question->firstName; ?></a> </p>
                <!--<p></p>-->
                <!--<p>Tagged: <a href="#">orci</a>, <a href="#">lectus</a>, <a href="#">varius</a>, <a href="#">turpis</a></p>-->
                <!--<p><a href="#"><strong>Comments (3)</strong></a> <span>&nbsp;&bull;&nbsp;</span> May 27, 2010 <span>&nbsp;&bull;&nbsp;</span> <a href="#"><strong>Edit</strong></a></p>-->
            </div>
            <?php if ($this->uri->segment(2) == 'search_answer') { ?>
                <h2><span>Search result..</span></h2>
            <?php } else { ?>
                <h2 class="answerCount"><span><?php echo @$answer_count; ?></span> Answers</h2>
            <?php } ?>
            <div class="article" style="padding: 8px 24px 0;">

                <div class="clr"></div>
                <?php foreach ($answers as $row) { ?>
                    <div class="comment" > 

                        <div class="replay" >
                            <!--<a href="#"  style="float:right;" ><i class="fa fa-clipboard"></i></a>-->
    <!--                           <a style="float:right;" href="#" data-toggle="modal" data-target="#replyModal<?php //echo @$row['id']   ?>">

                                <span>Reply</span> 
                            </a>-->
                        </div>
                        <p style="border-bottom: 1px solid #efebeb;">
                            <a href="#"><?php echo @$row['firstName'] ?></a> Says: at
                            <?php echo date('j F, Y', strtotime($row['created'])); ?>
                            <!--<button style="margin-left: 25px;padding: 2px 7px;font-size: 12px;" onclick="CopyToClipboard('<?php echo @$row['id']; ?>')" class="btn btn-default">Copy Answer</button>-->
                            <a onclick="CopyToClipboard('<?php echo @$row['id']; ?>')" title="Copy answer" alt="Copy answer" class="copyclip" ><i class="fa fa-clipboard"></i></a>
                            <a href="#" data-toggle="modal" data-target="#replyModal<?php echo @$row['id'] ?>" href="#" title="Reply" alt="Reply" class="reply" >
                                <i class="fa fa-reply"></i>
                            </a>
                        </p>
                        <p style="padding: 0;margin: 4px 0;">
                            <a  class="answer" href="<?php @$row['sourceURL']; ?>" target="_blank" ><?php echo @$row['answer']; ?></a>
                            <input type="hidden" id="answer<?php echo @$row['id'] ?>" value="<?php echo @$row['answer'] . "\n[ Source URL :- " . $row['sourceURL']."  ]"; ?>" />
                        </p>
                        <?php
                        //echo "SELECT a.*,b.firstName FROM tbl_answer_reply a, user b where a.answerID = " . $row['id'] . " and a.isDeleted = 0 AND a.replyBy = b.id order by id asc"; exit;
                        $sql = "SELECT a.*,b.firstName FROM tbl_answer_reply a, user b where a.answerID = " . $row['id'] . " and a.isDeleted = 0 AND a.replyBy = b.id order by id asc";
                        $query = $this->db->query($sql);
//                        
                        ?>
                        <div style="padding:20px;">
                            <?php if ($query->num_rows() > 0) { ?>
                                <p style="padding: 0;margin: 2px 0px;font-size: 10px;font-size: 15px;font-weight: 700;">
                                    Comments:
                                </p>
                                <?php
                            }
                            //print_r($query->result());  exit;
                            foreach ($query->result() as $row1) {
                                ?>
                                <p class="commentbx">
                                    <?php echo $row1->reply; ?> <a href="#"><?php echo $row1->firstName; ?></a>
                                </p>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div class="modal fade" id="replyModal<?php echo @$row['id'] ?>" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Reply</h4>
                                </div>
                                <form action="<?php echo site_url('ask_questions/submit_reply/'); ?>" method="POST" enctype="multipart/form-data"   >
                                    <input type="hidden" name="answerID" value="<?php echo @$row['id'] ?>" />
                                    <input type="hidden" name="replyBy" value="<?php echo @$this->session->userdata('user_id'); ?>" />
                                    <input type="hidden" name="questionID" value="<?php echo @$this->uri->segment(3); ?>" />
                                    <div class="modal-body" style="padding: 25px 40px;">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <label for="reply">Enter Your Comment:</label>
                                                    <input required type="text" class="form-control frm-l-s" name="reply">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit"   class="btn btn-success" >Submit</button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <hr>
                <div class="row" style="margin-top: 20px;margin-bottom: 20px;">
                    <form action="<?php echo site_url('ask_questions/post_my_comment/' . $this->uri->segment(3)); ?>" method="post">
                        <input type="hidden" name="userID" value="<?php echo @$id = $this->session->userdata('user_id'); ?>" /> 
                        <div class="col-lg-12">
                            <script type="text/javascript">
                                //<![CDATA[
                                bkLib.onDomLoaded(function () {
                                    nicEditors.allTextAreas()
                                });
                                //]]>
                            </script>
                            <h4>Your Comment</h4>
                            <textarea name="comment" cols="80"   rows="10" style="width: 100%;"></textarea>
                            <div class="" style="padding-top: 15px;">
                                <button type="submit" class="btn btn-success" >Post Comment</button> 
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
        <script>
            $(document).ready(function () {
                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);
            });


            function CopyToClipboard(id) {
                var txt = $('#answer' + id).val();
                if (!txt || txt == '') {
                    return;
                }

                copyTextToClipboard(txt);

            }

            function copyTextToClipboard(text) {
                var textArea = document.createElement("textarea");

                textArea.style.position = 'fixed';
                textArea.style.top = 0;
                textArea.style.left = 0;
                textArea.style.width = '2em';
                textArea.style.height = '2em';
                textArea.style.padding = 0;
                textArea.style.border = 'none';
                textArea.style.outline = 'none';
                textArea.style.boxShadow = 'none';
                textArea.style.background = 'transparent';
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                try {
                    var successful = document.execCommand('copy');
                    var msg = successful ? 'successful' : 'unsuccessful';
                    alert('text copied');
                    //console.log('Copying text command was ' + msg);
                } catch (err) {
                    alert('unable to copy text');
                    //console.log('Oops, unable to copy');
                }
                document.body.removeChild(textArea);

            }
        </script>