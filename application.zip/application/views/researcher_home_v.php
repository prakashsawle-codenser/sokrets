<?php error_reporting(0); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Researcher | Home</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel='icon' href="<?php echo base_url(); ?>uploads/doc_image/sokrates_app_logo.png" type='image/png'/ >
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/researcher.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/responsive-researcher.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/progress-circle.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>
            /*div{
                border:1px solid;
            }*/
            ::-webkit-input-placeholder { /* Chrome/Opera/Safari */
                color: lightgray;
            }
        </style>
        <?php
        if (@$this->session->userdata('user_id') != "") {

            $researcher_id = $this->session->userdata('user_id');

            //$sql_st_ans = $this->db->query("SELECT * FROM `tbl_standard_answers` WHERE isDeleted = 0");
            //$row_st_ans = $sql_st_ans->result_array();
            $sql_ans = $this->db->query("SELECT count(*) as ans_count FROM `answer` WHERE answerBy = $researcher_id AND replyType = 'Answer' ");
            $r_ans_count = $sql_ans->first_row();

            $sql_acpt_count = $this->db->query("SELECT count(*) as ans_acpt_count FROM `answer` WHERE answerBy = $researcher_id AND replyType = 'Answer' and accept_user = 1 ");
            $r_acpt_count = $sql_acpt_count->first_row();

            @$acpt_per = $r_acpt_count->ans_acpt_count * 100 / $r_ans_count->ans_count;
            $sql_dash = $this->db->query("SELECT * FROM user order by researcher_points DESC");
            $i = 1;
            foreach ($sql_dash->result_array() as $r_rank) {
                $rank_id = $r_rank['id'];
                if ($r_rank['id'] == $researcher_id) {
                    $researcher_rank = $i;
                }
                $i++;
            }
        }
        ?>  
    </head>
    <body>
        <div id="SearchMenuNav" class="searchnav">

        </div>
        <div class="container" id="main_div">
            <div class="row noPadding" style="position:relative;margin-top: 15px;">
                <div class="researcher-logo">
                    <a href="<?php //echo site_url("Login_c");         ?>">
                        <img class="img-responsive logoimg" src="<?php echo base_url() . IMAGE_COM; ?>logo.png" /></a>  
<!--                    <span class="head-logo">SOKRATES</span>-->
                </div>
            </div>

            <div class="row">       
                <!--<input type="hidden" id="iQuestionId" />-->
                <div class="col-lg-12 noPadding">
                    <div class="col-lg-3  s5-play">
                        <div class="col-lg-12 col-xs-6  col-sm-3 noPadding section-new-question">
                            <span class="play-question-span">Solve a new question.</span>
                            <figure>
                                <img id="start" onclick="newQuestion();" src="<?php echo base_url() . IMAGE_COM . "play-btn.png"; ?>" alt="play" class="img-responsive play-img" />
                            </figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xs-6 col-sm-6 s5-pro-bar " >
                        <div class="user-progress">
                            <input type="hidden" id="iProgressIndicator" value="<?php echo @$row_cur->process_indicator; ?>" />
                            <h5 class="title-h5 text-center">User progress</h5>
                            <div class="pr-title progress-text"  id="u_process_1" style="display: none;"><b>Understanding</b><br/>your question.</div>
                            <div class="pr-title progress-text2" id="u_process_2" style="display: none;"><b>Researching</b><br/>your question</div>
                            <div class="pr-title progress-text3" id="u_process_3" style="display: none;"><b>Answering</b><br/>your question</div>
                            <div class="pr-title progress-text4" id="u_process_4" style="display: none;"><b>Briefing</b><br/>you on the answer</div>
                            <div id="iProgressPer" class="pr-title progress-circle <?php
                            if (isset($row_cur->firstName)) {
                                echo $row_cur->process_indicator;
                            } else {
                                echo 'progress-0';
                            }
                            ?>">
                                <span id="iStopwatch" >
                                    <spn>00:00:00</spn>
<!--                                                <time id="timerValue"></time>-->
                                </span>
                            </div>                                                           


                        </div>
                    </div>
                    <div class="col-lg-3 col-xs-6 col-sm-2 s5-profile">
                        <div class="noPadding user-profile">
                            <div class="research_menu">

<!--<img alt="user-image" src="<?php echo base_url() . COUNTRY_FLAG . $r_data->countryname; ?>" class="img-responsive rec_pro_image"  />-->                            
                                <img alt="user-image" src="<?php echo base_url() . USER_IMAGE . $r_data->user_image; ?>" class="img-responsive rec_pro_image"  />                            
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo "Hi, " . $this->session->userdata('firstName'); ?>
                                    <span class="caret"></span></a>
                                <ul class="dropdown-menu head-drop"  >                                        
<!--                                    <li><a href="<?php echo site_url("register/my_profile/"); ?>">My Profile</a></li>    
                                <li><a href="<?php echo site_url("change_password/"); ?>">Change Password</a></li>-->
                                    <li><a href="<?php echo site_url("logout"); ?>">Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <input id="icurrentQuestionID" type="hidden" name="currentQuestionID" value="<?php echo @$row_cur->id ?>" />
               
                <input type="hidden" value="<?php  if(isset($row_cur->totalTime) AND  $row_cur->totalTime !=''){ echo $row_cur->totalTime;  }else{ echo '00:00:00';}   ?>" name="StopwatchValue" id="iStopwatchValue" onkeyup="storeTime(this.value);" />
                <div class="col-lg-12 noPadding">
                    <div class="col-lg-3">
                        <div class="col-lg-12 noPadding asker-section" style="min-height:133px; ">
                            <div class="triangle-right"></div>
                            <h5 class="title-h5 text-center">Asker</h5>

                            <div class="col-lg-4 noPadding asker-lable" >                               
                                <span id="iAskerName" class="lable-title"><?php echo isset($row_cur->firstName) ? "<strong>Name</strong><br>" . $row_cur->firstName : ''; ?></span>
                                <span id="iAskerImage">

                                    <?php
                                    

                                    if (isset($row_cur->firstName)) {
                                        ?>
                                        <img alt="user-image" src="<?php echo base_url() . USER_IMAGE . $row_cur->user_image; ?>" class="img-responsive asker-img"  />
                                    <?php } ?>
                                </span>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span id="iAskerCountry" class="lable-title"><?php echo isset($row_cur->country) ? "<strong>Country</strong><br>" . $row_cur->country : ''; ?></span>
                                <span id="iCountryImage" class="">
                                    <?php if (isset($row_cur->country)) { ?>
                                        <img alt="user-image" src="<?php echo base_url() . COUNTRY_FLAG . strtolower($row_cur->country) . ".png"; ?>" class="img-responsive asker-img"  />
                                            <!--<img src="<?php echo base_url() . IMAGE_COM . "default.png"; ?>" class="img-responsive asker-img" />-->
                                            <!--<img alt="user-image" src="<?php echo base_url() . IMAGE_COM . ""; ?>" class="img-responsive asker-img"  />-->
                                    <?php } ?>
                                </span>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <div id="iMemberSince" class="lable-title">
                                    <?php echo isset($row_cur->days) ? "<strong>Member</strong><br>Since" : ''; ?>                                    
                                </div>  
                                <?php if (isset($row_cur->days)) { ?>
                                    <div class="asker-round-info asker-round-info2">
                                        <?php echo isset($row_cur->days) ?"<strong>".$row_cur->days."</strong>"  . " day" : ''; ?>
                                    </div>
                                <?php } ?>
                            </div>                            
                        </div>
                        <div class="col-lg-12 ask-team-help" style="height: 318px;">
                            <h5 class="title-h5 text-center">Ask your team for help</h5> 
                            <div class="chat-div">
                                <input type="text" class="input-chat" name="" placeholder="Message"/>
                            </div>                            
                        </div>
                    </div>
                    <div class="col-lg-6 noPadding s5-middle ">
                        
                        <div class="parent">
                        <div class="col-lg-12 noPadding child1" style="min-height: 50px;">                            
                            <div id="QUESTION_CLARIFICATION" class="researchre-popup" style="display:none;">
                                <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('QUESTION_CLARIFICATION');"></i>
                                <?php echo @$r_question_instr->instructions; ?>
                            </div>
                            <div id="DUPLICATE_QUESTION_INSTRUCTIONS" class="researchre-popup" style="display:none;">
                                <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('DUPLICATE_QUESTION_INSTRUCTIONS');"></i>
                                <?php echo @$r_dup_question_instr->instructions; ?>
                            </div>
                            <!--                            <div class="question-approve-round-btn" style="display: none;">
                                                            <i id="iApproveSimQuestionIcone" onclick="approveSimQuestion();"   class="fa fa-check-circle question-approve-icon"  aria-hidden="true"></i>
                                                        </div>-->
                            <div  class="child1-half-ap-button"  >
                                <i  id="iApproveQuestion" onclick="approveQuestion('progress-36');"  class="fa fa-check-circle sim-question-approve-icon "  aria-hidden="true"></i>
                            </div>
                            <div class="child1-half-cnl-button" >
                                <i id="iCancelSimQuestionIcone" onclick="cancelSimQuestion()"  class="fa fa-times-circle sim-question-approve-icon  "  aria-hidden="true"   <?php if (!empty($row_coments)) { ?> style="color: red !important;" <?php }?> ></i>
                            </div>
                            <span class="q-latter" id="iquestion-icon" <?php if($row_cur->process_indicator=='progress-12' AND empty($row_coments)) { ?> style="color: red;" <?php } ?> >Q</span>
                            <!--input-question-->
                            <div class="" id="i-q-instruction" style="width: 100%;">
                                <div  id="iQuestion" class="div-content1">
                                    <?php echo $row_cur->updated_question!='' ? $row_cur->updated_question : $row_cur->questionTitle; ?>
                                </div>
                                <textarea id="edit_question"  class="input-comment" type="text" ></textarea>
                                <!-- <?php if (isset($row_cur->questionID) && $row_cur->questionID == 28) { ?>
                                    <span style="top: 41px;color:#5E5E5E;width: 15%;position: absolute;left: 0;right: 0;margin: auto;border: 0.5px solid #5E5E5E;"></span>
                                    <div id="iQuestion2" class="" style="padding: 0 26px; color: #939393;text-align: center;font-size: 15px; font-weight: bold;">
                                        The reason that Facebook users still mistrusted the
                                        company after Zuckerberg's testimony to Congress is that
                                        users were upset that Facebook did not inform them of
                                        the data leak when Facebook discovered this leak in 2015.
                                    </div>
                                <?php } ?> -->
                            </div>
                            <!--<textarea class="input-question" type="text" name="question" value=""  ></textarea>-->
                        </div>
                        <!--<div class="col-lg-12 noPadding comment-section">
                                <span class="comment-icon">C</span>                            
                                <textarea class="input-comment" type="text" name="question"  ></textarea>
                            </div>-->    
                        <?php ?>
                        <div class="col-lg-12 noPadding child2" style="min-height: 50px;">                            
                            <div id="COMMENT_INSTRUCTIONS" class="researchre-popup" style="display:none;top: -68px;">
                                <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('COMMENT_INSTRUCTIONS');" ></i>
                                <?php echo @$r_comment_instr->instructions; ?>
                            </div>
                            <div id="ASKER_NOT_RESPONDING" class="researchre-popup" style="display:none;top: -68px;" >
                                <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('ASKER_NOT_RESPONDING');" ></i>
                                <?php echo @$r_asker_not_resp->instructions; ?>
                            </div>
                            <div class="child2-half-ap-button" >
                                <i <?php if (@$row_comnt['questionBy'] != "" && @$row_comnt['questionBy'] == @$row_comnt['messageBy']) { ?> style="color:#25AF49;" <?php } ?> id="iApproveComment" onclick="approveComment()"  class="fa fa-check-circle comment-approve-icon disablebutton"  aria-hidden="true" ></i>
                            </div>                            
                            <span class="c-icon" id="iCommentIcone" style="cursor: pointer;">C</span> 
                            <input type="hidden" id="iSelectedAns" />
                            <form id="iFormComment" method="post" >     
                                <input type="hidden" id="iquestionID" name="questionID" value="<?php echo @$row_cur->questionID; ?>" />
                                <input type="hidden" id="iquestionBy" name="questionBy" value="<?php echo @$row_cur->questionBy; ?>" />
                                <input type="hidden" id="ianswerBy" name="answerBy" value="<?php echo @$row_cur->answerBy; ?>" />
                                <input type="hidden" id="imessageBy" name="messageBy" value="<?php echo @$row_cur->answerBy; ?>" />
                                <!--<input type="hidden" id="ireplyType" name="replyType"  value="Comment">-->
                                <div class="c-div-opt-btn">
                                    <select onchange="getStandradAns(this.value);" id="iCommentOption" class="r-comment-option" disabled>
                                        <option value="">Options</option>
                                        <?php foreach ($sql_st_ans as $row_st_ans) { ?>
                                            <option value="<?php echo @$row_st_ans['ans']; ?>"><?php echo @$row_st_ans['ans']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <br>
                                    <button <?php if (@$row_comnt['questionBy'] != "" && @$row_comnt['questionBy'] == @$row_comnt['messageBy']) { ?> style="background-color:#E40613;" <?php } ?> id="iCommentSend" type="button" class="r-comment-send-btn" disabled >Send</button>
                                    <button  disabled style="padding: 1px 7px;" type="button" class="r-comment-send-btn" disabled id="iQPause" >Pause <i class="fa fa-pause" ></i></button>
                                </div>
                                <!--c-divComment-box-->
                                <div id="iCommonCmntDiv" class="" <?php if (!empty($row_coments)) { ?> onclick="enableComment();" <?php } ?> >
                                    <?php if (!empty($row_coments)) { 
                                        
                                        ?>

                                        <div  class="div-content2"  >
                                             


                                            <div class="commentInput2  response_input"  <?php if($row_coments[0]['answerBy']==$row_coments[0]['messageBy']){ ?> style="display: none;"        <?php   } ?>>
                                               
 
                                            <input placeholder="Enter your response here …" autocomplete="off" id="response_researcher" class="" name="comment" type="text" style="">
                                            </div>

                                          
                                            <span id="waiting_response_msg" style="display: none;"><img style="margin: 8px 0;border: 1px solid #D5D5D5;width: 30px;height: 30px;border-radius: 56px;display: inline-block;" alt="user-image" src="<?php echo base_url() . USER_IMAGE . $row_cur->user_image; ?>" class="img-responsive asker-img"  /><span style="font-weight: normal;"> <i>Waiting for user response …</i></span> </span> 
                                             <div  id="question_answer_container">
                                                 
                                            
                                            <?php
                                            foreach ($row_coments as $row_comnt) {
                                                if ($row_comnt['answerBy'] != $row_comnt['messageBy']) {
                                                   
                                                     if (isset($row_cur->firstName)) {
                                                        ?>
                                                        <img style="margin: 8px 0;border: 1px solid #D5D5D5;width: 30px;height: 30px;border-radius: 56px;display: inline-block;" alt="user-image" src="<?php echo base_url() . USER_IMAGE . $row_cur->user_image; ?>" class="img-responsive asker-img"  />
                                                        <?php
                                                    }
                                                    echo "<i>" . preg_replace('/\s+/', ' ', $row_comnt['comment']) . "</i><br>";

                                                 
                                                } else { ?>

                                                      <input type="hidden" value="<?php echo $row_comnt['comment']; ?>" id="inewQue" />
                                                    <?php
                                                     if ($row_comnt['is_final']==1) {
                                                        echo "<span class='notify_msg'>" . preg_replace('/\s+/', ' ', $row_comnt['comment']) . "</span><br>";
                                                     }else{
                                                        echo "<span id='iSelAns'>" . preg_replace('/\s+/', ' ', $row_comnt['comment']) . "</span><br>";
                                                     }
                                                    
                                                }
                                            }
                                            ?>

                                            </div>
                                        </div>
                                    <?php } else { ?>
                                       <!--  <p contenteditable="true" id="iComentText" style="display: none;" class="input-comment" type="text" name="" > </p> -->

                                         <div  class="div-content2"   >
                                            

                                            <div class="commentInput2 response_input" style="display: none;">
                                               
 
                                            <input placeholder="Enter your response here …" autocomplete="off" id="response_researcher" class="input_question" name="comment" type="text" style="" >
                                            </div>
                                           <span id="waiting_response_msg" style="display: none;"><img style="margin: 8px 0;border: 1px solid #D5D5D5;width: 30px;height: 30px;border-radius: 56px;display: inline-block;" alt="user-image" src="<?php echo base_url() . USER_IMAGE . $row_cur->user_image; ?>" class="img-responsive asker-img"  /><span style="font-weight: normal;"> <i>Waiting for user response …</i></span> </span> 

                                             <div  id="question_answer_container">

                                       
                                       <!--  <textarea id="iComentText" style="display: none;" class="input-comment" type="text" name="comment" ></textarea> -->
                                        <div id="question_display">
                                            
                                        </div>
                                    </div>
                                        </div>
                                    <?php } ?>

                                </div>
                            </form>
                        </div>
                        <!--                        <div class="col-lg-12 noPadding answer-section">
                                                    <span class="answer-icon">A</span>
                                                    <textarea class="input-answer" type="text" name="question"  ></textarea>
                                                </div>-->


                        <div class="col-lg-12 noPadding child3" style="min-height: 50px;">
                            <form id="iFormAnswer" method="post" style="width:100%;" >  
                                <div id="ANSWER_INSTRUCTIONS" class="researchre-popup" style="display:none;top: -33px;">
                                    <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('ANSWER_INSTRUCTIONS');"></i>
                                    <?php echo @$r_answer_instr->instructions; ?>
                                </div>
                                <div id="ANSWER_TEMPLATE_INSTRUCTIONS" class="researchre-popup" style="display:none;top: -80px;">
                                    <i class="fa fa-times-circle instructions-popup-close" onclick="closeInstructions('ANSWER_TEMPLATE_INSTRUCTIONS');"></i>
                                    <?php echo @$r_answer_temp_instr->instructions; ?>
                                </div>

                                <div class="child3-half-ap-button"  >
                                    <i id="iApproveSimAnswerIcone" onclick="approveSimAnswer()"  class="fa fa-check-circle sim-answer-approve-icon"  aria-hidden="true"></i>
                                </div>
                                <div class="child3-half-cnl-button" >
                                    <i id="iCancelSimAnswerIcone" onclick="cancelSimAnswer()"  class="fa fa-times-circle sim-answer-cancel-icon"  aria-hidden="true"></i>
                                </div>
                                <span class="answer-icon" id="iAnswerIcone" style="cursor: pointer;">A</span>
                                <div class="c-div-opt-btn">
                                    <select disabled style="width: 13%;" onchange="getStandradAnsA(this.value);" id="iStAnswerOption" class="r-comment-option" >
                                        <option value="">Options</option>
                                        <?php foreach ($sql_st_ans_a as $row_st_ans_a) { ?>
                                            <option value="<?php echo @$row_st_ans_a['ans']; ?>"><?php echo @$row_st_ans_a['ans']; ?></option>
                                        <?php } ?>
                                    </select>
                                    <br>
                                    <div class="a-div-ans-btn">
                                        <button  id="iAnswerSend" type="button" class="r-answer-send-btn" disabled >Send</button>
                                    </div>
                                </div>
                                <!--a-divAnswer-box-->
                                <div class="div-content3">
                                    <textarea onkeyup="answringQuestion();" <?php if($row_cur->process_indicator!='progress-60') { ?> style="display: none;" <?php } ?>  id="iAnswerText" class="input-answer" type="text" name="answer"  ></textarea>
                                </div>

                            </form>
                        </div>

</div>
                        <div class="col-lg-12 noPadding" >
                            <span style="cursor: pointer;" class="add_new_url" id="addrow">
                                <i class="fa fa-plus-circle" style="font-size: 25px;color: #25AF49;"></i>
                                <!--<img class="img-responsive" src="<?php echo base_url() . IMAGE_COM . "add.png" ?>" />-->
                            </span>                        
                        </div>
                        <div id="source_url_ilst">
                            <div class="col-lg-12 noPadding source-url-section">                                
                                <input id="sourceURL" onblur="enableAnsSend(this.value)" type="text" name="sourceURL[]" value="" class="input-source-url" placeholder="Paste source URL here" />
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="col-lg-12 noPadding asker-section" style="min-height:133px;">
                            <h5 class="title-h5 text-center">Questions</h5>
                            <div class="col-lg-4 noPadding asker-lable" >
                                <span class="lable-title"><strong>Sessions</strong><br> total</span>
                                <div class="question-detail-count">
                                    <span>
                                        <?php echo @$r_data->sessions_total; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span class="lable-title"><strong>Questions</strong><br> answered</span>
                                <div class="question-detail-count">
                                    <?php echo @$r_ans_count->ans_count; ?>
                                </div>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span class="lable-title"><strong>Accepted</strong><br> answers</span>
                                <div class="question-detail-count">
                                    <?php echo @round($acpt_per) . "%"; ?>
                                </div>
                            </div>                            
                        </div>
                        <div class="col-lg-12 noPadding asker-section" style="min-height: 130px;padding: 0px 11px 5px 11px;">
                            <h5 class="title-h5 text-center">Leaderboard</h5>
                            <div class="col-lg-4 noPadding asker-lable" >
                                <span class="lable-title"><strong>Rank</strong> <br> total</span>
                                <div class="question-detail-count">
                                    <span style="color:red;">#<?php echo @$researcher_rank; ?></span>
                                </div>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span class="lable-title"><strong>Points</strong> <br>Total</span>
                                <div class="question-detail-count" id="iResearcherPoint">
                                    <?php echo @$r_data->researcher_points; ?>
                                </div>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span class="lable-title"><strong>Average</strong><br> answer time</span>
                                <div class="question-detail-count">
                                    <?php echo round(@$r_data->timeAvg) . "s"; ?>
                                </div>
                            </div>                            
                        </div>
                        <div class="col-lg-12 noPadding asker-section" style="min-height: 133px;">
                            <h5 class="title-h5 text-center">Your session</h5>
                            <div class="col-lg-4 noPadding asker-lable" >
<!--                                <span class="lable-title">Start <br> Pause</span>
                                <div class="question-detail-count" >
                                    <div id="timerButtonsstop" class="clsPause" style="cursor: pointer;"  >
                                        <i id="stop" style="font-size: 20px;vertical-align: -4px;" class="fa fa-pause"></i>                                        
                                    </div>
                                    <div id="timerButtonsstart" class="clsPlay" style="cursor: pointer;display: none;" >
                                        <i id="start" style="font-size: 20px;vertical-align: -4px;" class="fa fa-play"></i>
                                    </div>
                                </div>-->
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
                                <span class="lable-title"><strong>Time</strong> <br> total</span>
                                <div class="question-detail-count">
                                    <?php echo @date('H:i', strtotime($r_data->timeSum)); ?>
                                </div>
                            </div>
                            <div class="col-lg-4 noPadding asker-lable">
<!--                                <span class="lable-title">Time till break</span>
                                <div class="question-detail-count">
                                    -0:09
                                </div>-->
                            </div>                            
                        </div>
                        <div class="col-lg-12 noPadding">
                            <button class="res-search-btn" onclick="newSearchQuestion();" disabled="true" id="search_btn" style="background-color: #D5D5D5;">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo base_url(); ?>assets/js/stopwatch.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <?php include 'researcher_common.php'; ?> 


         <?php if($row_cur->process_indicator=='progress-12' AND !empty($row_coments)){ 

            
            ?>
                <script type="text/javascript">
                  
                   cancelSimQuestion();

                </script>
     <?php   } ?>
  



         <?php if($row_cur->process_indicator=='progress-36' || $row_cur->process_indicator=='progress-60'){ 

            
            ?>
                <script type="text/javascript">
                  
                     $("#iCommonCmntDiv").addClass('disablebutton');
                    
                    approveQuestion("<?php echo $row_cur->process_indicator;?>");

                </script>
     <?php   }

 if($row_cur->process_indicator=='progress-60'){?>
    <script type="text/javascript">
                $("#u_process_3").show();
                $("#u_process_1").hide();
                $("#u_process_2").hide();

                </script>
           <?php }
      ?>
        
        <!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5b990f86c666d426648ab1c6/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>-->
        <!--End of Tawk.to Script-->

    </body>
</html>
