        <style>


</style>
<div class="content">

    <div class="content_resize">
        <div class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg"  class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">
            <div class="col-lg-12 text-right">
                <form class="example" action="<?php echo site_url('ask_questions/search_questions'); ?>" method="post" style="    margin: 0 0 20px 0;
                      max-width: 100%;">
                    <input type="text" name="ser" value="<?php echo @$ser; ?>" placeholder="Search.." />
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <div class="col-lg-12">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a data-toggle="tab" href="#recent">Recent</a>
                    </li>
                    <!--                   <li><a data-toggle="tab" href="#popular">Popular</a></li>
                                        <li><a data-toggle="tab" href="#unanswered">Unanswered</a></li>-->
                </ul>

                <div class="tab-content">
                    <div id="recent" class="tab-pane fade in active">
                        <?php foreach ($questions as $row) { ?>
                            <div class="article">
                                
                                <h4><a style="color:#1D1D1B !important;" class="a_question" href="<?php echo site_url('ask_questions/answers_list/' . $row['id']); ?>" ><?php echo $row['questionTitle']; ?></a></h4>
                                
                                <div class="clr"></div> 
                                <p>
                                    <span class="date">On <?php echo date('j F, Y', strtotime($row['created'])); ?></span> Posted by <a href="#" style="color:#5DB166 !important;"><?php echo $row['firstName']; ?></a> &nbsp;                                    
                                    <a class="pull-right tran-question" href="<?php echo site_url('ask_questions/researcher_list/' . $row['id'] . '/' . $row['questionBy']); ?>"><i class="fa fa-share-square-o"></i> Transfer Question</a>
                                </p>
    <!--                                <img src="images/img1.jpg" width="625" height="205" alt="" />
                                <p>This is a free CSS website template by CoolWebTemplates.net. This work is distributed under the Creative Commons Attribution 3.0 License, which means that you are free to use it for any personal or commercial purpose provided you leave the credit links in the template footer intact.</p>-->
                                <p class="spec" style="display:flow-root;">
                                    <!--<a href="#" class="rm">Read more &raquo;</a>-->

                                    <?php if ($this->session->userdata('userType') == 2) { ?>
                                    
                                        <a href="<?php echo site_url('ask_questions/write_answers/' . $row['id'] . '/' . $row['questionBy']); ?>" class="com">

                                            <span>Write Answer</span> 
                                        </a>
                                    <?php } else { ?>
                                        <a href="<?php echo site_url('ask_questions/answers_list/' . $row['id']); ?>" class="com">
                                            <?php
                                            // echo "SELECT * FROM answer where questionID = ".$row['id']." ";
                                            $sql = "SELECT * FROM answer where questionID = " . $row['id'] . " ";
                                            $query = $this->db->query($sql);
                                            ?>
                                            <span><?php echo @$query->num_rows(); ?> Answers</span>
                                        </a>
                                    <?php } ?>
                                </p>
                            </div>

                        <?php } ?>
                    </div>
                    <div id="popular" class="tab-pane fade">
                        <div class="article">
                            <h2><span>Future</span> technology</h2>
                            <div class="clr"></div>
                            <p><span class="date">On 29 aug 2010</span> Posted by <a href="#">Owner</a> &nbsp;|&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a></p>
                            <img src="images/img2.jpg" width="625" height="205" alt="" />
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. Cras id urna. <a href="#">Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu posuere nunc justo tempus leo.</a> Donec mattis, purus nec placerat bibendum, dui pede condimentum odio, ac blandit ante orci ut diam. Cras fringilla magna. Phasellus suscipit, leo a pharetra condimentum, lorem tellus eleifend magna, eget fringilla velit magna id neque. Curabitur vel urna. In tristique orci porttitor ipsum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. Cras id urna. Morbi tincidunt, orci ac convallis aliquam.</p>
                            <p class="spec"><a href="#" class="rm">Read more &raquo;</a> <a href="#" class="com"><span>7</span> Comments</a></p>
                        </div>
                    </div>
                    <div id="unanswered" class="tab-pane fade">

                    </div>
                </div>
            </div>
            <!--<p class="pages"><small>Page 1 of 2 &nbsp;&nbsp;&nbsp;</small> <span>1</span> <a href="#">2</a> <a href="#">&raquo;</a></p>-->
        </div>
        <script>
            $(document).ready(function () {
                $("#MYQUESTION").removeClass().addClass('active');
                //$("#msg").delay(4000).fadeOut();
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);
            });
            
        </script>