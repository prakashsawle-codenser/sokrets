<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/slick/slick-theme.css">
<script src="<?php echo base_url(); ?>assets/slick/slick.js" charset="utf-8"></script>
<style>
    .slick-slider{
        width:85%;
        margin: auto;
    }
    .follow-up-questions{
        width:85%;
        margin: auto;
    }
    a:focus {
        outline: 0px auto -webkit-focus-ring-color;
    }

    

</style>
<script>
    javascript:(function () {
        function ats() {
            var styles = '*,p,div{user-select:text !important;-moz-user-select:text !important;-webkit-user-select:text !important;}';
            jQuery('head').append(jQuery('<style />').html(styles));
            var allowNormal = function () {
                return true;
            };
            jQuery('*[onselectstart], *[ondragstart], *[oncontextmenu], #songLyricsDiv').unbind('contextmenu').unbind('selectstart').unbind('dragstart').unbind('mousedown').unbind('mouseup').unbind('click').attr('onselectstart', allowNormal).attr('oncontextmenu', allowNormal).attr('ondragstart', allowNormal);
        }
        function atswp() {
            if (window.jQuery) {
                ats();
            } else {
                window.setTimeout(atswp, 100);
            }
        }
        if (window.jQuery) {
            ats();
        } else {
            var s = document.createElement('script');
            s.setAttribute('src', 'http://code.jquery.com/jquery-1.9.1.min.js');
            document.getElementsByTagName('body')[0].appendChild(s);
            atswp();
        }
    })();
</script>
<div class="content">
    <div class="content_resize">
        <div class="col-md-12" style="padding: 0;">
            <?php if ($this->session->flashdata('success')) : ?>
                <div  id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="home-main clearfix">
            <div class="mainbar" style="width:100%;">
               

             
                <div class="slider" id="slick">  
                 <?php foreach ($questions as $key => $question) { ?>                  
                    <div id="div-slider" data-item="<?php echo $question['question_id']; ?>" >
                        <div class="art-q-div"  >
                            <div class="article-question" style="">
                                <div class="clr"></div>
                                <div class="comment" style="text-align: center;" > 
                                    <!--<span class="q-box">Q</span>-->
                                    <p class="text-center home-q-title" style="line-height: 1;" >
                                        <?php echo $question['questionTitle']; ?>
                                    </p>                    
                                </div>
                            </div>
                        </div>
                        <div class="art-a-div">
                            <div class="article-answer" style="">
                                <div class="clr"></div>
                                <div class="comment" style="text-align: center;" > 
                                    <!--<span class="a-box">A</span>-->
                                    <div class="text-center" style="padding:10px;">                                    
                                        <p class="commentbx-home" id="answerBox<?php echo $question['question_id']; ?>" style="font: normal 23px Helvetica; overflow-x: scroll; max-height: 200px;" >

                                            <a style="line-height: 1;" onclick="openSourceUrl('<?php echo $question['sourceURL']; ?>');" href="javascript:void(0)" class="slider-ans-text">
                                                <?php echo $question['answer']; ?>
                                            </a> <span class="confidence-score" title="confidence score">(<?php echo $question['confidence_score']; ?>%)</span>                                            
                                        </p> 

                                      <?php if ($question['answer_source']=='A') {
                                        if ($question['ans_accept']=='N') { 
                                             if ($question['replyType']=='std_ans') { ?>
                                                  <div id="responseDiv<?php echo $question['question_id']; ?>">
                                                  <p>Do you want to save this question? <a href="#" class="response resYes" id="yes" data-id="<?php echo $question['question_id']; ?>" data-value="Y" data-url="<?php echo $question['sourceURL']; ?>">Y</a><a href="#" class="deleteQuestion resNo"   id="no" data-id="<?php echo $question['question_id']; ?>"data-value="N" data-url="<?php echo $question['sourceURL']; ?>">N</a></p>
                                            </div>
                                            <?php }else{ ?>
                                                 <div id="responseDiv<?php echo $question['question_id']; ?>">
                                                  <p>Does this answer your question? <a href="#" class="response resYes" id="yes" data-id="<?php echo $question['question_id']; ?>" data-value="Y" data-url="<?php echo $question['sourceURL']; ?>">Y</a><a href="#" class="response resNo"   id="no" data-id="<?php echo $question['question_id']; ?>"data-value="N" data-url="<?php echo $question['sourceURL']; ?>">N</a></p>
                                            </div>
                                           <?php 
                                             }

                                            ?>

                                           
                                        
                                      <?php  } ?>
                                         
                                    <?php  } ?>
                                        
                                                                           
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                         <div class="follow-up-questions">
                <form action="<?php echo site_url("ask_questions/submit_follow_up_questions/"); ?>" method="post" enctype="multipart/form-data" id="form-question">
                    <input type="hidden" name="userID" value="<?php echo $this->session->userdata('user_id'); ?>"  />
                    <input type="hidden" name="followUpQuestionsID" id="iQuestionID" value="<?php echo $question['question_id']; ?>" />
                    <ol>
                        <li>
                            <input placeholder="Type your follow-up question (on this topic)"  autocomplete="off" id="tags" class="input_question" name="questionTitle" type="text"  style="font-size: 21px;background-color: #ffffffa1 !important;height:60px;margin-top: 20px;" required />
                            <ul class="sugestion-tag" id="sugestion-tag" style="width:61.5%;"></ul>
                        </li>                
                        <li>
                            <div class="clr"></div>
                        </li>
                    </ol>
                </form>
            </div>
                    </div> 


                   

                       <?php   } ?>                   
                </div>

             
            </div>
            
        </div>

        <!--        <div class="ask_q_footer">
                    <div class="ask_q_footer_resize">
                        <div class="col-lg-12 noPadding">
                            <div id="mySidenavHome" class="ans-src-div">
                                <a href="javascript:void(0)" class="closebtn-ans-src" onclick="closeSrc()">&times;</a>
                                <div class="asq_foot_btn" >Answer Source</div>
                                <div class="ans-src-chk" style="">                    
                                    <label class="checkbox-inline qcustom-check"  >
                                        <input name="sources" type="checkbox" value="Internet" >
                                        Internet
                                        <span class="qcheckmark" ></span>
                                    </label>
                                    <label class="checkbox-inline qcustom-check" >
                                        <input name="sources" type="checkbox" value="My shoebox">
                                        My Library
                                        <span class="qcheckmark" ></span>
                                    </label>
                                </div>
                            </div>                        
                            <div class="asq_foot_btn" onclick="openSrc()" >Answer Source</div>             
        
                            <div class="asq_foot_btn">Progress <span class="header_q_count" style="padding: 0px 4px;"><?php echo @str_pad("50", 2, "0", STR_PAD_LEFT); ?></span></div>
        
                        </div>
                    </div>
                </div>-->
        <?php include 'footer_tabs.php'; ?>
        <?php include 'common.php'; ?>
                <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
        <script>
//            function openSrc() { 
//                document.getElementById("mySidenavHome").style.height = "50px";
//            }
//
//            function closeSrc() {
//                document.getElementById("mySidenavHome").style.height = "0";
//            }
            function openSourceUrl(url) {
                if (url!='') {
                      var str_array = url.split(',');
                for (var i = 0; i < str_array.length; i++) {
                    // Trim the excess whitespace.
                    win = "";
                    str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
                    // Add additional code here, such as:
                    //alert(str_array[i]);
                    var win = window.open(str_array[i]);
                    win.focus();
                }
                }
              
                //onclick = "window.open('your_html', '_blank')"
            }
            function getSugVal(val) {
                $('#tags').val(val);
                $('.sugestion-tag').hide();
            }
            $(document).ready(function () {

                $("#tags").on('keyup', function () {
                    var q = this.value;
                    var formData = new FormData();
                    formData.append('q', q);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/get_sugestion/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                            $('.sugestion-tag').show();
                            $('#sugestion-tag').html(data);
                        }
                    });
                });

                $('.slider').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                    infinite: true,
                    cssEase: 'linear',
                    autoplay: false
                });

                $("#HOME").removeClass().addClass('active');
                setTimeout(function () {
                    $('#msg').fadeOut();
                }, 5000);

                $('#slick').on('afterChange', function (event, slick, currentSlide, nextSlide) {
                    var $slides = $('#slick').slick("getSlick").$slides;
                    //alert($slides.eq(currentSlide).find('div div').attr('data-item'));
                    $('#iQuestionID').val($slides.eq(currentSlide).find('div div').attr('data-item'));
                    //console.log($(slick.$slides.get(currentSlide)).attr('id'));
//                    var $slides = $('#slick').slick("getSlick").$slides;  console.log($slides);
//                    var item = $slides.eq(currentSlide).data("item");  
//                    console.log(item);

                    //var item =  $(this).data('item');  alert(item);

//                    var $slides = $('#slick').slick("getSlick").$slides;
//                    var elt = slick.$slides.get(currentSlide);
                    //var item = $slides.eq(currentSlide).children().data("item");  
//                    console.log(item);
                    //console.log($(slick.$slides.get(currentSlide)).children().attr('data-item'));

                    //alert($slides.eq(currentSlide).find('div div').attr('data-item'));
                    //alert($slides.eq(currentSlide).find('div div').attr('data-item'));
                });
            });

            $(".response").click(function(){
               var qid= $(this).data('id');
               var response= $(this).data('value');
               var url=$(this).data('url');
               var formData = new FormData();
                   formData.append('qid', qid);
                   formData.append('response', response);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/addApiQuestionResponse/"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                          var data=$.parseJSON(data);
                            console.log(data);
                           $("#responseDiv"+qid).html(''); 
                           
                            if (response=='N') {
                                $("#answerBox"+qid).html("Let me find another answer and get back to you.");
                                //callanswerFromApi();
                                if (data.count==0) {
                                       setInterval(function(){                               
                                 window.location.href = "<?php echo site_url("ask_questions/submit_question/"); ?>"
                              }, 5000);
                                }
                             

                            }

                            if (response=='Y') {
                                if (data.response=='Y') {

                                    $("#responseDiv"+qid).html('<p>Save source to BookShelf? <a href="#" class="addbookshelf resYes" id="yes" data-id="'+qid+'" data-value="Y" data-url="'+url+'">Y</a><a href="#" class="nobookshelf resNo"   id="no" data-id="'+qid+'"data-value="N" data-url="'+url+'">N</a></p>')
                                }else{
                                     if (data.count==0) {
                                   window.location.href = "<?php echo site_url("ask_questions/"); ?>"
                              }
                                }
                            }
                          
                        }
                    });
            })


             $(".deleteQuestion").click(function(){
               var qid= $(this).data('id');
               var response= $(this).data('value');
               var formData = new FormData();
                   formData.append('qid', qid);
                   formData.append('response', response);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/delete_question"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                          window.location.href = "<?php echo site_url("ask_questions/"); ?>"
 
                        }
                    });
            })


            
            function callanswerFromApi(){                 
                    $.ajax({
                            url   : '<?php echo site_url("ask_questions/answerFromApi/"); ?>',
                            async : true //change this to false if you hate your users and want them to wait 
                        }).done(function() {
                            
                        });
                }

        
                $(document).on("click", ".addbookshelf", function(){
                    
                var url=$(this).data('url');
                 var qid=$(this).data('id');
               var formData = new FormData();
                   formData.append('url', url);
                   formData.append('qid', qid);
                    $.ajax({
                        url: '<?php echo site_url("ask_questions/addBookshelfDocument"); ?>',
                        type: "POST",
                        data: formData,
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data)
                        {
                           $("#responseDiv"+qid).html(''); 
                           
                    
                                $("#answerBox"+qid).html("Successfully added pdf in your BookShelf.");
                            

                        setInterval(function(){                               
                                 window.location.href = "<?php echo site_url("ask_questions/"); ?>"
                              }, 3000);

                            
                          
                        }
                    });
                })
           
             
                $(document).on("click", ".nobookshelf", function(){
                   
                      var qid=$(this).data('id');
                       $("#responseDiv"+qid).html(''); 
                })

        </script>
