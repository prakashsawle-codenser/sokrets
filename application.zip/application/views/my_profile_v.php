<div class="content">
    <div class="content_resize" style="padding: 0;">
        <div class="mainbar">
            <!--            <div class="article">
                            <h2><span>Contact</span></h2>
                            <div class="clr"></div>
                            <p>You can find more of my free template designs at my website. For premium commercial designs, you can check out DreamTemplate.com.</p>
                        </div>-->
            <div class="article my_pro_section">

                <h2 style="text-align: center;color: #757575;">Personal information</h2>
                <div class="clr"></div>
                <div class="row">
                    <?php  if ($this->session->flashdata('success')) : ?>

                        <div class="col-md-12">
                            <div id="msg" class="alert alert-success alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success:</strong> <?php echo $this->session->flashdata('success'); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
                if ($this->session->flashdata('error')) {
                    echo $this->session->flashdata('error');
                }
                ?>
                
                <form action="<?php echo site_url("register/update_profile"); ?>" method="post" enctype="multipart/form-data" >
                    <!--<input type="hidden" name="id" value="<?php //echo @$this->session->userdata('user_id');  ?>" />-->
                    <ol>
                        <li>
                            <label for="website">First Name (required)</label>
                            <input value="<?php echo @$user->firstName; ?>" class="form-control frm-l-s" type="text" name="firstName" class="text"  />
                        </li>
                        <li>
                            <label for="website">Last Name (required)</label>
                            <input value="<?php echo @$user->lastName; ?>" class="form-control frm-l-s" type="text" name="lastName" class="text"  />
                        </li>
                        <li>
                            <label for="website">Email (required)</label>
                            <input value="<?php echo @$user->email; ?>" class="form-control frm-l-s" type="text"  name="email" class="text" />
                        </li>
                        <li>
                            <label for="website">Country </label>
                            <select class="form-control frm-l-s" name="country" id="iCountry">
                                <option value="">Select Country</option>
                                <?php 
                                $sql_country = $this->db->query("SELECT * FROM `country`");
                                foreach ($sql_country->result_array() as $val_country) { ?>
                                <option value="<?php echo @$val_country['code']; ?>" <?php if(@$val_country['code'] == @$user->country){ echo 'selected';} ?>><?php echo @$val_country['countryname']; ?></option>    
                                <?php 
                                }
                                ?>
                                
                            </select>
                            
                        </li> 
                        <li>
                            <label for="website">User Image </label>
                            <input style="border-bottom: none;width: 50%;display: inline-block;" onchange="readURL(this);" class="form-control frm-l-s" type="file"  name="user_image" class="text" />
                            <!--<img id="blah" src="#" alt="your image" style="height: 85px;width: 85px;" />-->
                            <?php if(@$user->user_image != ""){ ?>
                            <img style="height: 85px;width: 85px;display: inline-block;" src="<?php echo base_url().USER_IMAGE.$user->user_image; ?>" alt="user-image" class="img-rounded" />
                            <?php } ?>
                        </li> 
                        
                        <li>
                            <button class="btn send" type="submit" style="color:#fff;background-color: #E40613;margin-bottom: 16px;">Update Profile</button>
                            <!--<input type="image" name="imageField" id="imageField" src="<?php //echo base_url();  ?>assets/images/submit.gif" class="send" />-->
                            <a style="background-color: #E40613;text-decoration: none;" href="<?php echo site_url("ask_questions/"); ?>" class="btn btn-danger" >Cancel</a>
                            <div class="clr"></div>
                        </li>
<!--                        <li>
                            <h2 style="text-align: center;"><?php //echo @$user->firstName; ?></h2>
                        </li>
                        <li>
                            <p style="text-align: center;" class="profile_card_title"><?php //echo @$user->email; ?></p>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="<?php //echo site_url("ask_questions/questions/"); ?>" class="btn btn-primary" >Cancel</a>
                        </li>-->
                    </ol>
                </form>     
            </div>
        </div>
         <?php include 'common.php'; ?>
        <script>
            $(document).ready(function () {
                $("#USERM").removeClass().addClass('dropdown active');
                $('#msg').delay(5000).fadeOut();
            });
            function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(150)
                        .height(200);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        </script>