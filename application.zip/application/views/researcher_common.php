<script>
    //var t = [0, 0, 0, 0, 0, 0, 0, 1];
// 0/1 = start/end
// 2 = state
// 3 = length, ms
// 4 = timer
// 5 = epoch
// 6 = disp el
// 7 = lap count
//    function ss() {
//        t[t[2]] = (new Date()).valueOf();
//        t[2] = 1 - t[2];
//
//        if (0 == t[2]) {
//            clearInterval(t[4]);
//            t[3] += t[1] - t[0];
////            var row = document.createElement('tr');
////            var td = document.createElement('td');
////            td.innerHTML = (t[7]++);
////            row.appendChild(td);
////            td = document.createElement('td');
////            td.innerHTML = format(t[1] - t[0]);
////            row.appendChild(td);
////            td = document.createElement('td');
////            td.innerHTML = format(t[3]);
////            row.appendChild(td);
////            document.getElementById('lap').appendChild(row);
//            t[4] = t[1] = t[0] = 0;
//            disp();
//        } else {
//            t[4] = setInterval(disp, 43);
//        }
//
//    }
//    function r() {
//        if (t[2])
//            ss();
//        t[4] = t[3] = t[2] = t[1] = t[0] = 0;
//        disp();
//        document.getElementById('lap').innerHTML = '';
//        t[7] = 1;
//    }

//    function disp() {
//        if (t[2])
//            t[1] = (new Date()).valueOf();
//        //t[6].value = format(t[3] + t[1] - t[0]);
//        document.getElementById('iStopwatch').innerHTML = format(t[3] + t[1] - t[0]);
//        document.getElementById('iStopwatchValue').value = format(t[3] + t[1] - t[0]);
//        myTimer();
//    }
//    function format(ms) {
//        // used to do a substr, but whoops, different browsers, different formats
//        // so now, this ugly regex finds the time-of-day bit alone
//        var d = new Date(ms + t[5]).toString()
//                .replace(/.*([0-9][0-9]:[0-9][0-9]:[0-9][0-9]).*/, '$1');
//        //var x=String(ms%1000); 
//        //while (x.length<3) x='0'+x;
//        //d+='.'+x; 	
//        return d;
//    }
//
//    function load() {
//
//        t[5] = new Date(1970, 1, 1, 0, 0, 0, 0).valueOf();
//        t[6] = document.getElementById('disp');
//
//        disp();
//
//
////        if (!window.opener && window == window.top) {
////            document.getElementById('remote').style.visibility = 'visible';
////        }
////        var watch_time = $('#iStopwatchValue').val();
////        alert(watch_time);
////        var cur_q_id = $('#icurrentQuestionID').val();
////        var formData = new FormData();
////        formData.append('cur_q_id', cur_q_id);
////        formData.append('totalTime', watch_time);
////        $.ajax({
////            url: '<?php //echo site_url("researcher/update_indicator/");            ?>',
////            type: "POST",
////            data: formData,
////            contentType: false,
////            cache: false,
////            processData: false,
////            success: function (data)
////            { //alert(data)
////            }
////        });
//    }

//    function remote() {
//        window.open(
//                document.location, '_blank', 'width=700,height=350'
//                );
//        return false;
//    }

    var myVar = setInterval(myTimer, 1000);
    function myTimer() {
        var watch_time = $('spn').text();
        $('spnn').text(watch_time);
        var cur_q_id = $('#icurrentQuestionID').val(); //alert(watch_time);
        var formData = new FormData();
        formData.append('id', cur_q_id);
        formData.append('totalTime', watch_time);
        if (watch_time != '00:00:00') {
            $.ajax({
                url: '<?php echo site_url("researcher/update_timer/"); ?>',
                type: "POST",
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                { //alert(data)
                }
            });
        }
    }
    function closeInstructions(val) {
        $('#' + val).hide();
        if (val == 'ANSWER_INSTRUCTIONS') {
            $('#ANSWER_TEMPLATE_INSTRUCTIONS').show();
        }
    }
    function newQuestion() {
        //timer();
        //$("#iCancelSimQuestionIcone").css({"color": "#E40613"});

        var formData = new FormData();
        //formData.append('ser', ser);          
        formData.append('process', 'progress-12');
        $.ajax({
            url: '<?php echo site_url("researcher/get_researcher_question/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            {
                
                var str = JSON.parse(data);
                
                window.location.reload();
                
                $('#icurrentQuestionID').val(str.curQueId);
                $('#iquestionID').val(str.r_question.id);
                $('#iquestionBy').val(str.r_question.questionBy);
                $('#ianswerBy').val(str.r_data.id);
                $('#imessageBy').val(str.r_data.id);
                $("figure").css("background-color", "#D5D5D5");
                $("figure").css("pointer-events", "none");
                $("#iquestion-icon").css("color", "red");


                if (str.r_question.id == '28') {
                    //--popup--//
                    $('#DUPLICATE_QUESTION_INSTRUCTIONS').show();
                    var q_html = "";
                    q_html += str.r_question.questionTitle + "<br/><div id='isim-q-old-div' style='border-bottom:2px solid gray;width:50px;margin:auto;'></div>";
                    q_html += "<span id='isim-q-old' style='color:#939393;'>What is the reason that Facebook users still mistrusted the company after Zuckerberg's testimony to Congress?</span>";
                    $('#iQuestion').html(q_html);
                    $('.question-approve-round-btn').hide();
                    $('.answer-approve-round-btn').hide();
                    $('.sim-question-approve-round-btn').show();
                    $('.sim-question-cancel-round-btn').show();
                    $('.sim-answer-approve-round-btn').show();
                    $('.sim-answer-cancel-round-btn').show();

                    //$('.sim-answer-cancel-round-btn').show();
                    //$('.answer-icon').css("color", "#25AF49");
                    $("#iApproveQuestion").css({"color": "#65BDEA"});
                    $("#iCancelSimQuestionIcone").css({"color": "#65BDEA"});
                    $("#iApproveSimAnswerIcone").css({"color": "#65BDEA"});
                    $("#iCancelSimAnswerIcone").css({"color": "#65BDEA"});
                    $("#u_process_2").show();
                    $('#iProgressPer').removeClass().addClass('progress-circle progress-36');
                    $('#iAnswerText').show();
                    $('#iAnswerText').html("The reason that Facebook users still mistrusted the company after Zuckerberg's testimony to Congress is that users were upset that Facebook did not inform them of the data leak when Facebook discovered this leak in 2015.")
                    $('#sourceURL').val('https://www.ft.com/content/171cc986-41b5-11e8-803a-295c97e6fd0b');
                } else {
                    //--popup--//
                    $('#QUESTION_CLARIFICATION').show();
                    $('#iQuestion').html(str.r_question.questionTitle);
                    $("#u_process_1").show();
                    $('#iProgressPer').removeClass().addClass('progress-circle progress-12');
                }
                $('#iAskerCountry').html('Country<br>' + str.r_question.country);
                $("#iCountryImage").html('<img src="<?php echo base_url(); ?>uploads/user_image/us-flage.png" class="img-responsive asker-img" />');
                $('#iAskerName').html('Name<br>' + str.r_question.firstName);
                $('#iMemberSince').html('Member<br>Since<div class="asker-round-info">' + str.r_question.days + ' day</div>');
                $("#iAskerImage").html('<img src="<?php echo base_url(); ?>uploads/user_image/'+str.r_question.user_image+'" class="img-responsive asker-img" />');

                $('#iResearcherPoint').html(str.r_data.researcher_points);
                //ss();
                timer();
            }
        });
    }
    function enableComment() {
        if ($('#iCommentOption').is(':disabled')) {
            $("#COMMENT_INSTRUCTIONS").show();
        }
        $("#iCommentOption").prop("disabled", false);
        $(".c-icon").css({"color": "#F7931D"});
        $("#iComentText").show();
    }
    function getStandradAns(val) {
       // var lastword= val.substring(val.length - 1, val.length);
       // val = val.substring(lastword, val.length - 1);
       //  $('#iComentText').html(val +"<span style='font-weight: initial;'>"+lastword+" </span>");
        // $('#iSelectedAns').val(val); 
          // $('#iComentText').val(val);
          $("#response_researcher").val(val)
        sessionStorage.setItem("SelectedAns", val);
        //var stAnsVal = sessionStorage.getItem("SelectedAns"); alert(stAnsVal);
        $('#response_researcher').focus();
        $("#iCommentSend").prop("disabled", false);
        $("#iCommentSend").css({"background-color": "#D7242E", "color": "#fff"});
        $(".child2").attr('style','flex-grow: 0;')
    }
    function getStandradAnsA(val) {
        $('textarea#iAnswerText').val(val);
        $('#iAnswerText').show();
        $('#iAnswerText').focus();
    }
    function enableAnswer() {
        if ($('#iAnswerSend').is(':disabled')) {
            $('#iAnswerInstructions').modal({show: true});
        }
        $("#iAnswerSend").prop("disabled", false);
        $("#iAnswerText").show();
        $('#iAnswerText').focus();
        $(".answer-icon").css({"color": "#25AF49"});
        //("#iCommentSend").prop("disabled", false);
        $("#iAnswerSend").css({"background-color": "#D7242E", "color": "#fff"});
    }
    function approveQuestion(process_indicator) {
           $("#iCommentIcone").css({"color": "#D5D5D5"});
           
           $("#COMMENT_INSTRUCTIONS").hide();
           // $("#iApproveComment").css({"color": "#D5D5D5"});
           // $("#iCancelSimQuestionIcone").addClass('disablebutton');
            $("#iquestion-icon").css({"color": "#D5D5D5"});
        $('#u_process_1').hide();
        $('#u_process_2').show();
        $('#u_process_3').hide();
        $("#search_btn").removeAttr("disabled");
        $("#iQuestion").removeAttr("onclick");
        $("#search_btn").removeAttr("style");
        $('#QUESTION_CLARIFICATION').hide();
        $("#iApproveQuestion").css({"color": "#25AF49"});
        $("#iCancelSimQuestionIcone").css({"color": "#D5D5D5"});
        $("#iCancelSimAnswerIcone").css({"color": "#D5D5D5"});
        if ($('#iAnswerSend').is(':disabled')) {
            //$('#iAnswerInstructions').modal({show: true});
            $("#ANSWER_INSTRUCTIONS").show();
        }
        $("#ANSWER_INSTRUCTIONS").show();
        
        $(".child3").removeClass('disablebutton');
        //var f_ans = $("textarea#iFirstAnswer").val();
        //$("textarea#iAnswerText").val(f_ans);
        $("#iStAnswerOption").prop("disabled", false);
        $("#iAnswerText").show();
        // $('#iAnswerText').focus();
        $(".answer-icon").css({"color": "#25AF49"});
        $("#iApproveQuestion").css({"color": "#25AF49"});
        //$("#iCommentSend").prop("disabled", false); 

        var cur_q_id = $('#icurrentQuestionID').val();
        $(".answer-approve-round-btn").hide();
        $(".sim-answer-approve-round-btn").show();
        $(".sim-answer-cancel-round-btn").show();
        //$("#iApproveSimAnswerIcone").css({"color": "#25AF49"});
        var question=$("#iQuestion").html().trim();
        var formData = new FormData();
        formData.append('cur_q_id', cur_q_id);
         formData.append('question', question);
        formData.append('process_indicator', process_indicator);
        $.ajax({
            url: '<?php echo site_url("researcher/getAnswerTemplate/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { 
                $("#iAnswerText").val(data);
            }
        });
        $('#iProgressPer').removeClass().addClass('progress-circle '+process_indicator);
    }
//    function approveSimQuestion() {
//        $("#iApproveSimQuestionIcone").css({"color": "#25AF49"});
//        $(".sim-answer-cancel-round-btn").show();
//        var cur_q_id = $('#icurrentQuestionID').val();
//        var formData = new FormData();
//        formData.append('cur_q_id', cur_q_id);
//        formData.append('process_indicator', 'progress-36');
//        $.ajax({
//            url: '<?php //echo site_url("researcher/update_indicator/");               ?>',
//            type: "POST",
//            data: formData,
//            contentType: false,
//            cache: false,
//            processData: false,
//            success: function ()
//            {
//            }
//        });
//        $('#iProgressPer').removeClass().addClass('progress-circle progress-36');
//    }
    function approveSimAnswer() {
        $("#iApproveSimAnswerIcone").css({"color": "#25AF49"});
        // $("#iAnswerSend").prop("disabled", false);
        // $("#iAnswerSend").css({"background-color": "#D7242E"});
    }
    function cancelSimQuestion() {

        $('#ANSWER_INSTRUCTIONS').hide();
        $(".notify_msg").next().remove();
        $(".notify_msg").remove();
        $("#search_btn").attr('disabled','disabled');
        $("#iApproveComment").removeClass('disablebutton');
        $("#iApproveQuestion").css({"color": "#D5D5D5"});
        $("#iApproveQuestion").addClass('disablebutton');
        $(".response_input").attr('style','display:block;');
$("#iCommonCmntDiv").removeClass('disablebutton');
$("#iAnswerIcone").css({"color": "#D5D5D5"});
$(".child3").addClass('disablebutton');
        // $(".child2").attr('style','flex-grow: 0;')
$("#iCancelSimQuestionIcone").css({"color": "#E40613"});
        if ($('#isim-q-old').text() != "") {
            $("#iApproveQuestion").css({"color": "#D5D5D5"});
            $("#iAnswerIcone").css({"color": "#25AF49"});
            $("#iCommentIcone").css({"color": "#D5D5D5","cursor":"pointer"});
            $('#isim-q-old-div').hide();
            $('#isim-q-old').hide();
            $('#sourceURL').val('');
            $('#ANSWER_INSTRUCTIONS').show();


        } else {
            $("#iCommentIcone").css({"color": "#F7931D"});
            $("#iCommentOption").prop("disabled", false);
            $("#iApproveComment").prop("disabled", false);
            //$("#iCommentSend").prop("disabled", false);            
            //$("#iCommentSend").css({"background-color": "#D7242E"});
            $('#iComentText').show();
            $('#COMMENT_INSTRUCTIONS').show();
        }
        //$("#iCommonCmntDiv").addClass("div-content2");

        //$("#iCommentIcone").css({"color": "#F7931D"});
        $('#QUESTION_CLARIFICATION').hide();
        $('#iAnswerText').html('');
        //$('input[name="sourceURL"]').val('');
        //$('.sim-question-approve-round-btn').hide();
        //$('.sim-question-cancel-round-btn').hide();
        $('.sim-answer-approve-round-btn').hide();
        $('.sim-answer-cancel-round-btn').hide();
        $('.question-approve-round-btn').show();
        $('.answer-approve-round-btn').show();
        $("#iquestion-icon").css({"color": "#D5D5D5"});
        $("#iCancelSimQuestionIcone").prop("disabled", false);
        $("#iCancelSimQuestionIcone").css({"color": "#E40613"});
         $('#iProgressPer').removeClass().addClass('progress-circle progress-12');
        $("#u_process_1").show();
        $("#u_process_3").hide();
          $("#u_process_2").hide();


         var cur_q_id = $('#icurrentQuestionID').val();
        var formData = new FormData();
        formData.append('cur_q_id', cur_q_id);
        formData.append('remove', 'remove');
        formData.append('process_indicator', 'progress-12');
        $.ajax({
            url: '<?php echo site_url("researcher/update_indicator_remove_notifymsg/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function ()
            {
            }
        });
       
         
        //$("#iAnswerText").css({"color": "#25AF49"});
        //--popup--//

        //$('#iAnswerText').val("Mark Zuckerberg's testimony before the US Congress has not restored trust among Facebook users because");
    }
    function approveAnswer() {
        $("#iApproveAnswer").css({"color": "#25AF49"});
        //$('#iProgressPer').removeClass().addClass('progress-circle progress-36');
    }
    function answringQuestion() {
         $('#u_process_1').hide();
        $('#u_process_2').hide();
        $('#u_process_3').show();
         // $('#iProgressPer').removeClass().addClass('progress-circle progress-60');
        if($('#iProgressPer').attr('class')!='progress-circle progress-60'){
             $('#iProgressPer').removeClass().addClass('progress-circle progress-60');
        var cur_q_id = $('#icurrentQuestionID').val();
      
        var formData = new FormData();
        formData.append('cur_q_id', cur_q_id);
        formData.append('process_indicator', 'progress-60');

        $.ajax({
            url: '<?php echo site_url("researcher/update_indicator/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function ()
            {
            }
        });
        }
       
        
    }
    function enableAnsSend(val) { 
        if (val != "") {
            $("#iAnswerSend").prop("disabled", false);
            $("#iAnswerSend").css({"background-color": "#D7242E", "color": "#fff"});
        }else{
            $("#iAnswerSend").prop("disabled", true);
            $("#iAnswerSend").css({"background-color": "#D5D5D5", "color": "#fff"});
        }
    }
    function approveComment() {
        var stAnsVal = sessionStorage.getItem("SelectedAns");
        $("#iApproveQuestion").removeClass('disablebutton');
        $("#iApproveComment").addClass('disablebutton');
        
        $("#iApproveComment").css({"color": "#25AF49"});
        if ($('#iCommentSend').is(':disabled')) {
            $('#iCommentInstructions').modal({show: false});
        }

        $("#iQuestion").attr("onclick","editQuestion()");
        $("#iquestion-icon").attr('style','color:red');
         $("#iCommentIcone").attr('style','color:rgb(213, 213, 213);');
        // if ($("#inewQue").val() != "") {
        //     $("#iQuestion").html('');
        //     var str = $('#iSelAns').html();
        //     var res = str.replace(stAnsVal, "");
        //     document.getElementById("iQuestion").innerHTML = res;
        //     //$("#iQuestion").html($("#inewQue").val());
        // }
        $("#question_answer_container").prepend("<span class='notify_msg'>Thanks! I will notify you when I have the answer.</span><br>")
     $(".response_input").css('display','none');

        $("#iAnswerSend").prop("disabled", false);
        $("#iStAnswerOption").prop("disabled", false);
        // $("#iAnswerText").show();
        $('#iAnswerText').focus();
        //$(".answer-icon").css({"color": "#25AF49"});
        //$("#u_process_1").hide();
        // $("#u_process_1").css({"color": "#DCDDDD"});
        // $("#u_process_2").show();
        //$("#clrmsg").show();

        var cur_q_id = $('#icurrentQuestionID').val();
        var formData = new FormData(document.getElementById("iFormComment"));
        formData.append('id', cur_q_id);

       
        $.ajax({
            url: '<?php echo site_url("researcher/add_researcher_comment_finish/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            {
                //alert(data)
            }
        });
        
       

    }
    function newSearchQuestion(){
        if ($('#iQuestion').html() != "") {
            var question = $('#iQuestion').html();
        }

        var answer = "";
        if ($('#iAnswerText').val() != "") {
            var answer = $('#iAnswerText').val();
        }else{
        
            var answer = $('#iQuestion').html().trim();
        }

     
           $('#i_nav_search').val(answer);
           searchQuestion();
        
    }

    function searchQuestion() {
        var url = '<?php echo site_url("researcher/get_nav_search/"); ?>';
        var question = "";
        if ($('#iQuestion').html() != "") {
            var question = $('#iQuestion').html();
        }

        var answer = "";
        if ($('#iAnswerText').val() != "") {
            var answer = $('#iAnswerText').val();
        }else{
        
            var answer = $('#iQuestion').html().trim();
        }

        if ($('#i_nav_search').val() != undefined) {
            var answer = $('#i_nav_search').val();
        }


        var className = $('#iProgressPer').attr('class');
        var var_html = "SearchMenuNav";
        var formData = new FormData();
        formData.append('question', question);
        formData.append('answer', answer);
        formData.append('iProgressPer', className);

        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { //alert(data);
                $("#" + var_html).html(data);
            }
        });
        //console.log(question);
        //$('textarea#i_nav_search').val(answer);
        // $('#iq-div').html(question);
        document.getElementById(var_html).style.width = "85%";
    }
    function closeNav() {
        document.getElementById('SearchMenuNav').style.width = "0";
    }

     function editQuestion(){
        var question=$("#iQuestion").html().trim();
        $("#iQuestion").attr('style','display:none');
        $("#edit_question").val(question);
        $("#edit_question").attr('style','display:block');
    }

    $('#edit_question').keypress(function (e) {
  if (e.which == 13) {
   var qid=$("#icurrentQuestionID").val();
   var update_question=$('#edit_question').val();
  var url = '<?php echo site_url("researcher/update_question/"); ?>';
        var formData = new FormData();
        formData.append('qid', qid);
        formData.append('update_question', update_question);
    

        $.ajax({
            url: url,
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            { 
                 $("#iQuestion").html(update_question);
        $("#iQuestion").attr('style','display:block');
        
        $("#edit_question").attr('style','display:none');
            }
        });
    return false;    
  }else{
    return true;
  }
});


    $(document).ready(function () {
        var counter = 1;
        $("#addrow").on("click", function () {
            counter++;
            var cols = "";
            cols += '<div class="col-lg-12 noPadding source-url-section"><input onkeyup="enableAnsSend(this.value)" type="text" name="sourceURL[]" value="" class="input-source-url" placeholder="Paste source URL here"  /><a class="deleteRow"><i style="cursor:pointer;font-size: 25px;position: absolute;right: -1%;top:0px;color:#DA2129;" class="fa fa-minus-circle"></i></a></div>';
            $("#source_url_ilst").append(cols);
        });

        $("#source_url_ilst").on("click", "a.deleteRow", function (event) {
            $(this).closest("div").remove();
        });
//        $('#iProgress').click(function () {
//            $('#iProgress').toggleClass('upProgress');
//        });

        $(".input-question").click(function () {
            //--popup--//
            $('#QUESTION_CLARIFICATION').show();
        });
//        $("#iQuestion").click(function () {
//            $("#iFirstAnswer").show();
//        });
        if (!$.trim($('#iQuestion').html()).length) {
        } else {
            $("figure").css("pointer-events", "none");
            $("figure").css("background-color", "#D5D5D5");
            // $("#iCancelSimQuestionIcone").css({"color": "#E40613"});
            if ($("#iProgressIndicator").val() == 'progress-12') {
                $("#u_process_1").show();
            }
            if ($("#iProgressIndicator").val() == 'progress-36') {
                $("#u_process_2").show();
            }
            if ($("#iProgressIndicator").val() == 'progress-48') {
                $("#u_process_3").show();
            }
            if ($("#iProgressIndicator").val() == 'progress-60') {
                $("#u_process_3").show();
            }
            if ($("#iProgressIndicator").val() == 'progress-85') {
                $("#u_process_4").show();
            }
        }
        if (!$.trim($('#iSelAns').html()).length) {
        } else {
            // $("#iCancelSimQuestionIcone").css({"color": "#D5D5D5"});
        }
            var pause_var;
        $("#iCommentSend").click(function () {
            //var check = $(this).attr('itemid');
         pause_var = setTimeout(pausebuttonfun, 60000);
            var formData = new FormData(document.getElementById("iFormComment"));
                  var response= $("#response_researcher").val();  
            $.ajax({
                url: '<?php echo site_url("researcher/add_researcher_comment/"); ?>',
                type: "POST",
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {  

                                    //$("#iUserResponse").show();
                   
                    if(response!='')
                    {
                         var ask_img = $('#iAskerImage').find('img').attr("src");
                        $("#question_answer_container").prepend("<span>"+response+"</span><br>");
                       
                          $("#waiting_response_msg").css('display','block');
                    $("#iCommentSend").prop("disabled", true);
                    $("#iCommentSend").css({"background-color": "#D5D5D5", "color": "#fff"});
                    $("#response_researcher").val(''); 
                    $(".response_input").attr('style','display:none;');

                    }else{
                         var question=$("#iComentText").val();
                    $("#iComentText").attr('style','display:none;');
                    var str='<span id="iSelAns">'+question+'</span><br>';
                    $("#question_display").html(str);
                  
                    
                   $("#waiting_response_msg").css('display','block');
                    $("#iCommentSend").prop("disabled", true);
                    $("#iCommentSend").css({"background-color": "#D5D5D5", "color": "#fff"});
                    }
                   

                    startTimer();
                }
            });
        });

        $("#iAnswerSend").click(function () {
            $("body").css({"opacity": "0.3"}); 

            //clearWatch();
            //$("#mydiv").load(location.href + " #mydiv")
            //var check = $(this).attr('itemid');
            $(".researchre-popup").hide();
            var q_id = $('#iquestionID').val();
            var q_by = $('#iquestionBy').val();
            var a_by = $('#ianswerBy').val();
            var watch_time = $('#iStopwatchValue').val();
            var cur_q_id = $('#icurrentQuestionID').val();
            $("#u_process_3").hide();
            $("#u_process_4").show();
            $('#iProgressPer').removeClass().addClass('progress-circle progress-85');
            var sourceURL = $("input[name='sourceURL[]']")
                    .map(function () {
                        return $(this).val();
                    }).get();

            var formData = new FormData(document.getElementById("iFormAnswer"));
            formData.append('cur_q_id', cur_q_id);
            formData.append('questionID', q_id);
            formData.append('questionBy', q_by);
            formData.append('answerBy', a_by);
            formData.append('replyType', 'Answer');
            formData.append('process', 'progress-85');
            formData.append('totalTime', watch_time);
            formData.append('sourceURL', sourceURL);
            $.ajax({
                url: '<?php echo site_url("researcher/add_researcher_Answer/"); ?>',
                type: "POST",
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {  //alert(data);
                    
                    setTimeout(function () {
                         $("body").css({"opacity": "0"}); 
                        $("#iAnswerSend").prop("disabled", true);
                        $("#iAnswerSend").css({"background-color": "#D5D5D5"});
                        $("figure").css("background-color", "#0F713A");
                        $("figure").css("pointer-events", "fill");
                        $("#iQuestion").html('');
                        $("#iQuestion2").html('');
                        $("#iComentText").html('');
                        $("#iAnswerText").html('');
                        $("#iApproveQuestion").css({"color": "#D5D5D5"});
                        $("#iApproveComment").css({"color": "#D5D5D5"});
                        $("#iApproveAnswer").css({"color": "#D5D5D5"});
                        $("#iCommentSend").prop("disabled", true);
                        $("#iCommentSend").css({"background-color": "#D5D5D5"});
                        $("#iAnswerSend").prop("disabled", true);
                        $("#iAnswerSend").css({"background-color": "#D5D5D5"});
                        $('input').val('');
                        $('textarea').val('');
                        $("#iquestion-icon").css({"color": "#D5D5D5"});
                        $("#iAnswerIcone").css({"color": "#D5D5D5"});
                        $("#iCommentIcone").css({"color": "#D5D5D5"});
                        window.location = "<?php echo site_url("researcher/"); ?>";
                    }, 4000);
                }
            });
            

        });

        $('#iQPause').click(function () {
            clearTimeout(t);
            var q_id = $('#iquestionID').val();
            var q_by = $('#iquestionBy').val();
            var a_by = $('#ianswerBy').val();
            var watch_time = $('#iStopwatchValue').val();
            var cur_q_id = $('#icurrentQuestionID').val();
            $("#u_process_1").hide();
            $("#u_process_3").hide();
            $("#u_process_4").show();
            var formData = new FormData(document.getElementById("iFormAnswer"));
            formData.append('cur_q_id', cur_q_id);
            formData.append('questionID', q_id);
            formData.append('questionBy', q_by);
            formData.append('answerBy', a_by);
            formData.append('replyType', 'Answer');
            formData.append('process', 'progress-0');
            formData.append('totalTime', watch_time);
            $.ajax({
                url: '<?php echo site_url("researcher/add_researcher_Answer_wait/"); ?>',
                type: "POST",
                data: formData,
                contentType: false,
                cache: false,
                processData: false,
                success: function (data)
                {  //alert(data);
                    $("#iAnswerSend").prop("disabled", true);
                    $("#iAnswerSend").css({"background-color": "#D5D5D5"});
                    $("figure").css("background-color", "#0F713A");
                    $("figure").css("pointer-events", "fill");
                    $("#iQuestion").html('');
                    $("#iQuestion2").html('');
                    $("#iComentText").html('');
                    $("#iAnswerText").html('');
                    $("#iApproveQuestion").css({"color": "#D5D5D5"});
                    $("#iApproveComment").css({"color": "#D5D5D5"});
                    $("#iApproveAnswer").css({"color": "#D5D5D5"});
                    $("#iCommentSend").prop("disabled", true);
                    $("#iCommentSend").css({"background-color": "#D5D5D5"});
                    $("#iAnswerSend").prop("disabled", true);
                    $("#iAnswerSend").css({"background-color": "#D5D5D5"});
                    $('input').val('');
                    $('textarea').val('');
                    $("#iquestion-icon").css({"color": "#D5D5D5"});
                    $("#iAnswerIcone").css({"color": "#D5D5D5"});
                    $("#iCommentIcone").css({"color": "#D5D5D5"});
                    window.location.reload();
                }
            });
        });

 var timerQ = 0;
    function startTimer()
    {
        //setInterval("timerUp()", 1000);
        rec_res = setInterval(function () {
            timerUp();
            getUserResponse();
        }, 2000);
    }

    function pausebuttonfun(){
         $("#iCommentSend").prop("disabled", true);
            $("#iCommentSend").css({"background-color": "#D5D5D5"});
            $("#iQPause").prop("disabled", false);
            $("#iQPause").css({"background-color": "#D7242E"});
            $("#COMMENT_INSTRUCTIONS").hide();
            $("#ASKER_NOT_RESPONDING").show();
    }
    function timerUp()
    {
        timerQ++;
        
        var resetat = 30; //change this number to adjust the length of time in seconds
        if (timerQ == resetat)
        {
           
        }
    }
    function getUserResponse() {
        var formData = new FormData(document.getElementById("iFormComment"));
        $.ajax({
            url: '<?php echo site_url("researcher/get_researcher_response/"); ?>',
            type: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData: false,
            success: function (data)
            {  
         

                if(data!=1)
                {
                    $("#waiting_response_msg").css('display','none');
                     clearTimeout(pause_var);
                     $("#iQPause").prop("disabled", true);
             $("#iQPause").css({"background-color": "rgb(213, 213, 213)"});
             $("#iQPause").css({"color": "rgb(255, 255, 255)"});

            
                        $(".response_input").attr('style','display:block');
                    $("#question_answer_container").html(data);
                }else{

                }
            
                
                //clearInterval(rec_res);
                //$("#iUserResponse").show();
                //$("#iCommentSend").prop("disabled", true);
                //$("#iCommentSend").css({"background-color": "#D5D5D5", "color": "#fff"});

                //startTimer();
            }
        });
    }


      $("body").click(function(){

         if($("#SearchMenuNav").css('width')!='0px'){

         $("#SearchMenuNav").attr('style','width:0px');
      }
    })

      $("#SearchMenuNav").click(function(e){
         e.stopPropagation();
      })


    $("#response_researcher").keyup(function(){
        $("#iCommentSend").prop("disabled", false);
        $("#iCommentSend").css({"background-color": "#D7242E", "color": "#fff"});
    })

    $("#iCommentIcone").click(function(){
        $('#COMMENT_INSTRUCTIONS').show();
    })

  
   

    




        
    });

  $("#iAnswerIcone").click(function(){
           $('#ANSWER_INSTRUCTIONS').show();
    })
</script>