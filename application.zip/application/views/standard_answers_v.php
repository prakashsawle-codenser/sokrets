
<div class="content">
    <div class="content_resize">
        <div  class="col-md-12">
            <?php if ($this->session->flashdata('success')) : ?>

                <div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> <?php echo $this->session->flashdata('success'); ?>
                </div>

            <?php endif; ?>
        </div>
        <div class="mainbar">

            <div class="article file-div" style="padding-top: 23px">

                <div class="col-lg-12 text-right" style="padding: 0">
<!--                    <form class="example" action="<?php echo site_url('standard_answers'); ?>" method="post" style="   margin: 0 0 20px 0;">
                        <input type="text" value="<?php echo @$ser; ?>" name="ser" placeholder="Search.." />
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>-->
                </div>

                <div style="clear: both">
                    <?php if ($this->uri->segment(2) == 'search_file') { ?>
                        <h3 style="display: inline-block;font-size: 20px;margin-top: 10px;"><span>Search result..</span> </h3>
                    <?php } else { ?>
                        <h3 style="color:#1D1D1B;display: inline-block;font-size: 20px;margin-top: 10px;">Standard Answers</h3>
                        <a href="javascript:void(0)"  data-toggle="modal" data-target="#addans" title="Add"  class="btn btn-success pull-right" style="text-decoration:none;" > Add Message</a>
                    <?php } ?>
                    <div class="clr"></div>
                    <div class="comment" style="padding:0 !important;"> 
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr style="color: #1D1D1B;font-size: 17px;">
                                    <th width="80%">Message</th>
                                    <th width="20%">Action</th>
                                </tr>
                                <?php
                                //print_r($this->session->userdata('upload_file'));    
                                foreach ($st_ans_list as $row_st) {
                                    ?>
                                    <tr style="font-size: 17px;">
                                        <td>                                            
                                            <?php echo @$row_st['ans']; ?>
                                        </td>                                        
                                        <td>
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#editans<?php echo @$row_st['id']; ?>" title="Edit" ><i class="fa fa-edit"></i></a>
                                            &nbsp; <a href="<?php echo site_url('standard_answers/delete_s_ans/'.$row_st['id']); ?>" onclick="return confirm('Are you sure you want to delete this item?');"  title="Delete" ><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="editans<?php echo @$row_st['id']; ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    <h4 class="modal-title">Update Answer</h4>
                                                </div>
                                                <form method="post" action="<?php echo site_url('standard_answers/update_s_ans/'); ?>" >
                                                    <input type="hidden" name="id" value="<?php echo @$row_st['id']; ?>" />
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="usr">Answer:</label>
                                                            <input type="text" name="ans" value="<?php echo @$row_st['ans']; ?>" class="form-control frm-l-s" id="usr">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success" >Update</button>
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Modal -->
        <div class="modal fade" id="addans" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title" style="color:#1D1D1B;font-weight: bold;">Add Answer</h4>
                    </div>
                    <form method="post" action="<?php echo site_url('standard_answers/add_s_ans/'); ?>" >
                        
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="usr">Answer:</label>
                                <input type="text" name="ans" value="" placeholder="" class="form-control frm-l-s" id="usr">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" >Submit</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>

            $(document).ready(function () {

                $("#a11").removeClass().addClass('active');
                $('#msg').delay(4000).fadeOut();
            });

        </script>

