<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Researcher_login extends CI_Controller {

    public function __construct() {

        parent::__construct();
    }

    public function index() {

        if ($this->session->userdata('user_id') != '') {
            redirect('researcher');
            // if ($this->session->userdata('userType') == 1) {
            //     redirect('ask_questions');
            // } else {
                
            // }
        } else {

            //$this->load->view('common/header');
            $this->load->view('researcher_login');
            // $this->load->view('common/footer');
        }
    }

    public function check_login() {
           
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('login_c');
        } else {
            $this->load->model('login_m');
            $user = $this->login_m->login_researcher($email, md5($password));
            // 
            if ($user) {
                $ses_tot = $user->sessions_total + 1;
                $this->login_m->add_session($user->id, $ses_tot);
               
                if ($this->input->post('remember_me')=='yes') {
                   setcookie("email", $email, time() + (86400 * 30*30), "/");
                   setcookie("password", $password, time() + (86400 * 30*30), "/");
                }else{

                    setcookie("email", "", time() - 3600,"/");
                    setcookie("password", "", time() - 3600,"/");

               
                }
                $this->session->set_userdata('email', $user->email);
                $this->session->set_userdata('pass', $user->password);
                $this->session->set_userdata('user_id', $user->id);
                $this->session->set_userdata('userType', $user->userType);
                $this->session->set_userdata('firstName', $user->firstName);
                $this->session->set_userdata('user_image', $user->user_image);
                $this->session->set_userdata('sokrates_permission', $user->sokrates_permission);
                $this->session->set_userdata('login_status', 'Y');
              
              $user = $this->login_m->isLogged_user($user->id);
                    redirect('researcher');
                // if ($user->userType == 1) {
                //     $this->session->set_flashdata('login_success', 'You are now logged in.');
                //     redirect('ask_questions');
                // } else {
                //     $user = $this->login_m->isLogged_user($user->id);
                //     redirect('researcher');
                // }
            } else {
                redirect('researcher_login');
            }
        }
    }


    public function create_sokretsId()
    {

          $this->load->model('login_m');
        if (!empty($this->input->post())) {
            
           $input= array('firstName' =>$this->input->post('first_name') , 'lastName' =>$this->input->post('last_name'), 'email' =>$this->input->post('email'), 'password' => md5($this->input->post('password')), 'userType' =>1, 'country' =>$this->input->post('country'));
             $user = $this->login_m->createSokretsid($input);
             if ($user) {
                  $this->session->set_flashdata('register_success', 'You have successfully create sokrets id.');
                    redirect('login_c');
             }else{
                
                  $this->session->set_flashdata('register_error', 'You have failed create sokrets id.');
                    $this->load->view('create_sokrets_v');
             }

        }else{

            $str = file_get_contents(base_url().'assets/countries.json'); 
                $json = json_decode($str, true);
                $data['countries']= $json; 
                                        
              $this->load->view('create_sokrets_v',$data);
        }

       
    }

}
