<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription extends CI_Controller {

    public function __construct() {

        parent::__construct();
        $this->load->model('subscription_m');
        $this->isvalidate();
        $this->lastActivity();
    }

    private function isvalidate() {
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }
    }
    
    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;

        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }
    
    public function index() {
        $id = $this->session->userdata('user_id');
        
        $data['subscription_plan'] = $this->subscription_m->get_plan();
        $data['user'] = $this->subscription_m->get_user($id);     
        $data['current_plan'] = $this->subscription_m->cur_plan($data['user']->subscriptionID);
        $this->load->view('common/header');
        $this->load->view('subscription_v', $data);
        $this->load->view('common/footer');
    }
    
    public function buy_plan() {
        $planid = $this->uri->segment(3);
        //$plan = $this->subscription_m->cur_plan($planid);        
        $id = $this->session->userdata('user_id'); 
        $status = $this->subscription_m->update_plan($id, $planid); 
        if($status){ 
            $this->session->set_flashdata('success', 'Your Plan updated successfully.');
            redirect("subscription");
        }
    }

    public function sample(){
          $input=array();
        $input['qid']=100;
        $input['tag']="Hello00";
         $input['createDate']=date("Y-m-d H:i:s");
         $this->db->insert('question_tag', $input);
    }
}
