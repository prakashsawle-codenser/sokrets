<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH.'libraries/pdfparser/vendor/autoload.php');
class My_files extends CI_Controller {

    public function __construct() {

        parent::__construct();
        $this->isvalidate();
        $this->lastActivity();
        
    }
private $upload_path = TEMP_FILES;
    private function isvalidate() {
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;

        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {

        $this->load->model('my_files_m');
        $id = $this->session->userdata('user_id');
        $files_count = $this->my_files_m->get_files_count($id);
        $data['files_count'] = $files_count;
        $data['files'] = $this->my_files_m->get_files($id);
        $this->load->view('common/header');
        $this->load->view('files_v', $data);
        $this->load->view('common/footer');
    }

    public function upload_files() {

        
        $this->load->model('my_files_m');
        $id = $this->session->userdata('user_id');

        $files = scandir(TEMP_FILES);
        $source = TEMP_FILES;
        $destination = USER_FILES;
        
        
        foreach ($files as $file) {
            if (in_array($file, array(".", "..")))
                continue;
            // If we copied this successfully, mark it for deletion
           $ext = pathinfo($file, PATHINFO_EXTENSION);
        // if ($ext=='pdf' OR  $ext=='PDF') {
        //    $image=$this->preViewPDF($file);
        // }else{
        //     $image='';
        // }
        $url= $this->upload_path .$file;
        $newurl=base_url().$url; 
        $ext = pathinfo($url, PATHINFO_EXTENSION); 
        //  if ($ext=='doc') {               
        //          $content= $this->read_document_api($url);
        //          }
        //  if ($ext=='docx') {
        //      $content= $this->read_document_api($url);
        //              //$content=$this->read_docx($url,$ext,$file);                    
        //          }               
        // if ($ext=='pdf') {
        //             $content=$this->readpdf($url,$ext,$file);
        //          }

        
         $image=$this->getThumbnailofDoc($newurl); 
         $content= $this->read_document_api($newurl);
           
            $uploadData = array(
                'user_id' => $id,
                'tagName' => '',
                'file_name' => $file,
                'comment' => '',
                 'thumbnil'=>$image,
                 'content'=>$content,
                 'url'=>base_url().'uploads/files/'.$file
            );
            $insert = $this->my_files_m->insert_files($uploadData);
            if (copy($source . $file, $destination . $file)) {
                $delete[] = $source . $file;
            }
        }
        foreach ($delete as $file) {
            unlink($file);
        }

        //$this->session->set_flashdata('success', 'Files uploaded successfully.'); 
        $suc_msg = '<div id="msg" class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Message:</strong> Files uploaded successfully.
                </div>';
        $this->load->model('my_files_m');
        $id = $this->session->userdata('user_id');
        $files_count = $this->my_files_m->get_files_count($id);
        $data['files_count'] = $files_count;
        $data['library_data'] = $this->my_files_m->get_files($id);
        //$data['suc_msg'] = $suc_msg;
         $data['word_count']= $this->my_files_m->get_filesContents($id);
        $this->load->view('my_library_v', $data);

        //redirect('my_files');
        // If file upload form submitted
//        if (!empty($_FILES['files']['name'])) { //echo 'fsdg'; exit;
//            $filesCount = count($_FILES['files']['name']);
//            for ($i = 0; $i < $filesCount; $i++) {
//                $_FILES['file']['name'] = $_FILES['files']['name'][$i];
//                $_FILES['file']['type'] = $_FILES['files']['type'][$i];
//                $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
//                $_FILES['file']['error'] = $_FILES['files']['error'][$i];
//                $_FILES['file']['size'] = $_FILES['files']['size'][$i];
//
//                // File upload configuration
//                $config['upload_path'] = USER_FILES;
//                $config['allowed_types'] = '*';
//
//                // Load and initialize upload library
//                $this->load->library('upload', $config);
//                $this->upload->initialize($config);
//
//                // Upload file to server
//                if ($this->upload->do_upload('file')) {
//                    // Uploaded file data
//                    $fileData = $this->upload->data();
//                    $uploadData['file_name'] = $fileData['file_name'];
//                }
//                // print_r($uploadData);  exit;
//                $insert = $this->my_files_m->insert_files($uploadData);
//            }
//            $this->session->set_flashdata('success', 'Files uploaded successfully.');
//            redirect('my_files');
//            //print_r($uploadData);  exit;
////            if (!empty($uploadData)) {
////                // Insert files data into the database
////                
////                //$insert = $this->file->insert($uploadData);
////                $insert = $this->my_files_m->insert_files($uploadData);
////                // Upload status message
////                $statusMsg = $insert ? 'Files uploaded successfully.' : 'Some problem occurred, please try again.';
////                $this->session->set_flashdata('statusMsg', $statusMsg);
////            }
//        }
    }
    
 function preViewPDF($filenames)
{
    if (!extension_loaded('imagick'))
    echo 'imagick not installed';
    
    
    $file_name =mt_rand(). ".jpg";
    $pathimage='./uploads/doc_image/'.$file_name;
     $dir ='./uploads/temp/';

    
    $im             = new Imagick();
    $im->setResolution(160,220);

    $ig = 0;

   
     
        $im->readimage($dir.$filenames."[$ig]");
        $im->setImageBackgroundColor('white');
        $im->setImageAlphaChannel(imagick::ALPHACHANNEL_REMOVE);
        $im->mergeImageLayers(imagick::LAYERMETHOD_FLATTEN);
        $im->setImageFormat('jpg'); 
        $im->writeImage($pathimage); 
        $im->clear(); 
        $im->destroy();
    
return $file_name;
}

public function getThumbnailofDoc($url)
   {
   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8001/getthumbnail");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          $server_output = curl_exec($ch);
        curl_close ($ch); 
        $filename = basename($server_output);
        copy($server_output, "/home/they/web_app/sokrets/uploads/doc_image/".$filename);
        $img_url=base_url()."uploads/doc_image/".$filename;
        return $img_url;
       
   }

    public function search_file() {
        if ($this->input->post('ser') == "") {
            redirect('my_files');
        }
        $id = $this->session->userdata('user_id');
        $this->load->model('my_files_m');
        $ser = $this->input->post('ser');
        // print_r($ser); exit;
        $files_count = $this->my_files_m->get_files_count($id);
        $data['files_count'] = $files_count;
        $data['files'] = $this->my_files_m->get_serch_file($id, $ser);
        $data['ser'] = $ser;
        //print_r($data['questions']); exit;
        $this->load->view('common/header');
        $this->load->view('files_v', $data);
        $this->load->view('common/footer');
    }

    public function get_my_files() {
        $this->load->model('my_files_m');
        $id = $this->session->userdata('user_id');
        $data['files_count'] = $this->my_files_m->get_files_count($id);
        //$data['used_space'] = $this->get_filesize($id);
        $data['used_space'] = "";
        $data['library_data'] = $this->my_files_m->get_files($id);
        $data['word_count']= $this->my_files_m->get_filesContents($id);
        
        //print_r($data); exit;
        $this->load->view('my_library_v', $data);
    }

    public function commnFunLibrary() {
        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = $this->input->post('ser');
        $data['file_name'] = $this->input->post('sort_fname');
        $data['tagName'] = $this->input->post('sort_tag');
        $data['comment'] = $this->input->post('sort_comment');
        $data['created'] = $this->input->post('sort_date');
        $data['delete'] = $this->input->post('delete');
        $this->load->model('my_files_m');
        if (@$data['delete'] != "") {
            
            $this->my_files_m->delete_lib_file($data['delete']);
        }
        $library_data = $this->my_files_m->get_library_data($data);
       
      // $this->load->model('my_files_m');
      //   $id = $this->session->userdata('user_id');
      //   $files_count = $this->my_files_m->get_files_count($id);
      //   $data['files_count'] = $files_count;
         $data['library_data'] =$library_data;
      //   //$data['suc_msg'] = $suc_msg;
      //    $data['word_count']= $this->my_files_m->get_filesContents($id);
       $this->load->view('search_library_result', $data);

    }
    public function update_library_data() { 
        $this->load->model('my_files_m');
        $data['column'] = $this->input->post('column');
        $data['editval'] = ltrim($this->input->post('editval'));
        $data['id'] = $this->input->post('id');
        
        $this->my_files_m->update_lib_file($data);
    }


    public function read_doc($url_file,$extension,$name) {
        $fileHandle = fopen($url_file, "r");
        $line = @fread($fileHandle, filesize($url_file));   
        $lines = explode(chr(0x0D),$line);
        $outtext = "";
        foreach($lines as $thisline)
          {
            $pos = strpos($thisline, chr(0x00));
            if (($pos !== FALSE)||(strlen($thisline)==0))
              {
              } else {
                $outtext .= $thisline." ";
              }
          }
         $outtext = preg_replace("/[^a-zA-Z0-9\s\,\.\-\n\r\t@\/\_\(\)]/","",$outtext);
       
         return $outtext;
        //  $com = array(
        //             'url' => base_url().'uploads/files/'.$name,
        //             'content' => $outtext,
        //             'type' => $extension,
        //             'uid' =>$this->session->userdata('user_id'),
        //             'created_at' => date("Y-m-d H:i:s")
        //         );
        // $this->db->insert('library_documents', $com);

    }

    public function read_docx($url_file,$extension,$name){

        $striped_content = '';
        $content = '';

        $zip = zip_open($url_file);

        if (!$zip || is_numeric($zip)) return false;

        while ($zip_entry = zip_read($zip)) {

            if (zip_entry_open($zip, $zip_entry) == FALSE) continue;

            if (zip_entry_name($zip_entry) != "word/document.xml") continue;

            $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

            zip_entry_close($zip_entry);
        }// end while

        zip_close($zip);

        $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
        $content = str_replace('</w:r></w:p>', "\r\n", $content);
        $striped_content = strip_tags($content);
        return $striped_content;
        //  $com = array(
        //             'url' => base_url().'uploads/files/'.$name,
        //             'content' => $striped_content,
        //             'type' => $extension,
        //             'uid' =>$this->session->userdata('user_id'),
        //             'created_at' => date("Y-m-d H:i:s")
        //         );
        // $this->db->insert('library_documents', $com);
    }

    public function read_document_api($url)
    {
         $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8002/webscrap/api/getresult");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        if (empty($server_output)) {
           $server_output= "";
        }else{
            $txtApiRes=json_decode($server_output,true);
            $server_output=$txtApiRes['content'];
        }
        return $server_output;
    }


    public function readpdf($url_file,$extension,$name)
{
   
error_reporting(0);
$parser = new \Smalot\PdfParser\Parser();
$pdf = $parser->parseFile($url_file); 

if ( $pdf==false) {
  $text=$name;
}else{
    $text = $pdf->getText();
}
return $text;

// $com = array(
//                     'url' => base_url().'uploads/files/'.$name,
//                     'content' => $text,
//                     'type' => $extension,
//                     'uid' =>$this->session->userdata('user_id'),
//                     'created_at' => date("Y-m-d H:i:s")
                    
//                 );
// $this->db->insert('library_documents', $com);
}

//    public function update_library_data() {
//        print_r($_P0ST);
//        exit;
//
//        $columns = array(
//            0 => 'file_name',
//            1 => 'tagName',
//            2 => 'comment'
//        );
//        $error = false;
//        $colVal = '';
//        $colIndex = $rowId = 0;
//
//        $msg = array('status' => !$error, 'msg' => 'Failed! updation in mysql');
//
//
//        if (isset($_POST['val']) && !empty($_POST['val']) && !$error) {
//            $colVal = $_POST['val'];
//            $error = false;
//        } else {
//            $error = true;
//        }
//        if (isset($_POST['index']) && $_POST['index'] >= 0 && !$error) {
//            $colIndex = $_POST['index'];
//            $error = false;
//        } else {
//            $error = true;
//        }
//        if (isset($_POST['id']) && $_POST['id'] > 0 && !$error) {
//            $rowId = $_POST['id'];
//            $error = false;
//        } else {
//            $error = true;
//        }
//
//        if (!$error) {
//            $this->my_files_m->update_lib_file($columns[$colIndex], $colVal);
//        } else {
//            $msg = array('error' => $error, 'msg' => 'Failed! updation in mysql');
//        }
//    }

//    public function get_filesize($id) {
//        $id = $this->session->userdata('user_id');
//        $this->load->model('my_files_m');
//        $data['library_data'] = $this->my_files_m->get_files($id);
//        $tot = "";
//        foreach ($data['library_data'] as $row) {
//            $tot += $this->filesize_formatted(USER_FILES . $row['file_name']);
//        }
//        return $tot;
//    }
//
//    public function filesize_formatted($path) {
//        $size = filesize($path);
//        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
//        $power = $size > 0 ? floor(log($size, 1024)) : 0;
//        //return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
//        return $bytes = number_format($size / 1048576, 2) . ' MB';
//    }

}
