<?php 

class Logout extends CI_Controller {
    
    public function index(){ 
        $this->db->set('isLogged',0);
        $this->db->where('id',$this->session->userdata('user_id'));
        $this->db->update('user'); 
        $userType= $this->session->userdata('userType');

        $ar = array('user_id','email','logged_in');
        $this->session->unset_userdata($ar);
        $this->session->sess_destroy();
        $this->session->set_flashdata('logout_success','You are logged out successfully!');
        if ($userType==1) {
           redirect('login_c');
        }else{
             redirect('researcher_login');
        }
       
    }
    
}