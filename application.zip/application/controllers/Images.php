<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require_once(APPPATH.'libraries/pdfparser/vendor/autoload.php');
class Images extends CI_Controller {

    private $upload_path = TEMP_FILES;

    public function index() {
        $this->load->model('my_files_m');
        $id = $this->session->userdata('user_id');
        $files_count = $this->my_files_m->get_files_count($id);
        $data['files_count'] = $files_count;
        $data['files'] = $this->my_files_m->get_files($id);
        $this->load->view('common/header');
        $this->load->view("files_v_multi_drug");
        $this->load->view('common/footer');
        $this->load->helper('url');

    }

    public function upload() {
        //return $_FILES;
        if (!empty($_FILES)) {
            $config["upload_path"] = $this->upload_path;
            $config["allowed_types"] = "*";
            $config['max_size'] = '0';
            $config['overwrite'] = FALSE;
             $config['encrypt_name'] = true;
            $this->load->library('upload', $config);

            if (!$this->upload->do_upload("file")) {
                 $errors = $this->upload->display_errors();
                 print_r($errors);
                echo "failed to upload file(s)";
            }else{
                $upload_data = $this->upload->data(); //Returns array of containing all of the data related to the file you uploaded.
            
                  $name =$upload_data['file_name']; 
                 $ext =  $upload_data['file_ext']; 
                $url= $this->upload_path . $name; 
                 

                
            }
        }
    }

    public function remove() {
        $file = $this->input->post("file");
        if ($file && file_exists($this->upload_path . "/" . $file)) {
            unlink($this->upload_path . "/" . $file);
        }
    }



    public function read_txt($url_file,$extension,$name){
        $myfile = fopen($url_file, "r"); 
        $file_contents= fread($myfile,filesize($url_file));
        fclose($myfile);
         $com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $file_contents,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                );
        $this->db->insert('library_documents', $com);

    }



     public function read_doc($url_file,$extension,$name) {
        $fileHandle = fopen($url_file, "r");
        $line = @fread($fileHandle, filesize($url_file));   
        $lines = explode(chr(0x0D),$line);
        $outtext = "";
        foreach($lines as $thisline)
          {
            $pos = strpos($thisline, chr(0x00));
            if (($pos !== FALSE)||(strlen($thisline)==0))
              {
              } else {
                $outtext .= $thisline." ";
              }
          }
         $outtext = preg_replace("/[^a-zA-Z0-9\s\,\.\-\n\r\t@\/\_\(\)]/","",$outtext);
       

         $com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $outtext,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                );
        $this->db->insert('library_documents', $com);

    }

    public function read_docx($url_file,$extension,$name){

        $striped_content = '';
        $content = '';

        $zip = zip_open($url_file);

        if (!$zip || is_numeric($zip)) return false;

        while ($zip_entry = zip_read($zip)) {

            if (zip_entry_open($zip, $zip_entry) == FALSE) continue;

            if (zip_entry_name($zip_entry) != "word/document.xml") continue;

            $content .= zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));

            zip_entry_close($zip_entry);
        }// end while

        zip_close($zip);

        $content = str_replace('</w:r></w:p></w:tc><w:tc>', " ", $content);
        $content = str_replace('</w:r></w:p>', "\r\n", $content);
        $striped_content = strip_tags($content);

         $com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $striped_content,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                );
        $this->db->insert('library_documents', $com);
    }

    public function read_xlsx($url_file,$extension,$name){
    $xml_filename = "xl/sharedStrings.xml"; //content file name
    $zip_handle = new ZipArchive;
    $output_text = "";
    if(true === $zip_handle->open($url_file)){
        if(($xml_index = $zip_handle->locateName($xml_filename)) !== false){
            $xml_datas = $zip_handle->getFromIndex($xml_index);
            $xml_handle = DOMDocument::loadXML($xml_datas, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
            $output_text = strip_tags($xml_handle->saveXML());
        }else{
            $output_text .="";
        }
        $zip_handle->close();
    }else{
    $output_text .="";
    }

   
    $com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $output_text,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                );
        $this->db->insert('library_documents', $com);
}


public function read_pptx($url_file,$extension,$name){
    $zip_handle = new ZipArchive;
    $output_text = "";
    if(true === $zip_handle->open($url_file)){
        $slide_number = 1; //loop through slide files
        while(($xml_index = $zip_handle->locateName("ppt/slides/slide".$slide_number.".xml")) !== false){
            $xml_datas = $zip_handle->getFromIndex($xml_index);
            $xml_handle = DOMDocument::loadXML($xml_datas, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
            $output_text .= strip_tags($xml_handle->saveXML());
            $slide_number++;
        }
        if($slide_number == 1){
            $output_text .="";
        }
        $zip_handle->close();
    }else{
    $output_text .="";
    }
    
    $com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $output_text,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                );
        $this->db->insert('library_documents', $com);
}


public function readpdf($url_file,$extension,$name)
{
   
error_reporting(0);
$parser = new \Smalot\PdfParser\Parser();
$pdf = $parser->parseFile($url_file); 

if ( $pdf==false) {
  $text=$name;
}else{
    $text = $pdf->getText();
}

$com = array(
                    'url' => base_url().'uploads/files/'.$name,
                    'content' => $text,
                    'type' => $extension,
                    'uid' =>$this->session->userdata('user_id'),
                    'created_at' => date("Y-m-d H:i:s")
                    
                );
$this->db->insert('library_documents', $com);
}





//    public function upload() {
//        $this->load->model('my_files_m');
//        $id = $this->session->userdata('user_id');
//        if (!empty($_FILES)) {
//
//            $this->load->library('upload');
//            $this->upload->initialize($this->set_upload_options());
//
//            $data = array(
//                'user_id' => $id
//            );
//
//            if ($this->upload->do_upload('file')) {
//                $dataInfo = $this->upload->data();
//                $data['file_name'] = $dataInfo['file_name'];
//            }
//
//            $insert = $this->my_files_m->insert_files($data);
//
////            if ($this->upload->do_upload("file")) {
////                echo "failed to upload file(s)";
////            }
//        }
//    }
//    public function remove() {
//        $this->load->model('my_files_m');
//        $id = $this->session->userdata('user_id');
//        $file = $this->input->post("file");
//        //$delete = 
//        if ($file && file_exists($this->upload_path . "/" . $file)) {
//            unlink($this->upload_path . "/" . $file);
//        }
//        $this->my_files_m->delete_files($id, $file);
//    }

    public function list_files() {
        $this->load->helper("file");
        $files = get_filenames($this->upload_path);
        // we need name and size for dropzone mockfile
        foreach ($files as &$file) {
            $file = array(
                'name' => $file,
                'size' => filesize($this->upload_path . "/" . $file)
            );
        }

        header("Content-type: text/json");
        header("Content-type: application/json");
        echo json_encode($files);
    }

//    private function set_upload_options() {
//        //upload an image options
//        $config = array();
//        $config['upload_path'] = USER_FILES;
//        $config['allowed_types'] = '*';
//        $config['max_size'] = '0';
//        $config['overwrite'] = FALSE;
//
//        return $config;
//    }
}
