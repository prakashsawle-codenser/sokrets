<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ask_questions extends CI_Controller {

    public function __construct() {

        parent::__construct();
         $this->load->library('session');
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }
        $this->lastActivity();
         $this->load->model('ask_question_m');
    
        $this->load->model('researcher_m');
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {
        $sql_gn = $this->db->query("set global sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'" );
            $sql_gn = $this->db->query("set session sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'" );
        //if ($this->session->userdata('userType') == 2) {
        //    redirect('ask_questions/questions');
        //} else {
            $this->load->model('ask_question_m');
            $id = $this->session->userdata('user_id');
            $data['udata'] = $this->ask_question_m->getUser($id);

            $this->load->view('common/header');
            $this->load->view('ask_question_v', $data);
       // }
    }

//    public function questions() {
//        $id = $this->session->userdata('user_id');
//        $this->load->model('ask_question_m');
//        $data['questions'] = $this->ask_question_m->get_questions($id);
//        $this->ask_question_m->read_questions($id);
//        //print_r($data['questions']); exit;
//        $this->load->view('common/header');
//        $this->load->view('questions_list', $data);
//        $this->load->view('common/footer');
//    }

    public function search_questions() { //echo 'hgh'; exit;
        $id = $this->session->userdata('user_id');
        $this->load->model('ask_question_m');
        $ser = $this->input->post('ser');
        // print_r($ser); exit;
        $data['questions'] = $this->ask_question_m->get_serch_questions($id, $ser);
        $data['ser'] = $ser;
        //print_r($data['questions']); exit;
        $this->load->view('common/header');
        $this->load->view('questions_list', $data);
        $this->load->view('common/footer');
    }

    public function search_answer() { //echo 'hgh'; exit;
        $q_id = $this->uri->segment(3);
        if ($this->input->post('ser') == "") {
            redirect('ask_questions/answers_list/' . $q_id);
        }
        $q_id = $this->uri->segment(3);
        $id = $this->session->userdata('user_id');
        $this->load->model('ask_question_m');
        $ser = $this->input->post('ser');
        // print_r($ser); exit;
        $answer_count = $this->ask_question_m->get_answers_count($q_id);
        //print_r($answer_count);  exit;
        $data['answer_count'] = $answer_count;
        $data['answers'] = $this->ask_question_m->get_search_answers($q_id, $ser);
        $data['ser'] = $ser;
        //print_r($data['questions']); exit;
        $this->load->view('common/header');
        $this->load->view('answers_v', $data);
        $this->load->view('common/footer');
    }

    public function submit_question() {
        //print_r($_POST); exit;
        $this->form_validation->set_rules('questionTitle', 'Question Title', 'required');
        //$this->form_validation->set_rules('questionCategory', 'Select a Question Category', 'required');

        if ($this->form_validation->run() == FALSE) {           // print_r(validation_errors());  exit;
            $this->session->set_flashdata('error', validation_errors());
            redirect('ask_questions');
        } else { // print_r($_POST); exit;
            $this->load->model('ask_question_m');

              $id = $this->session->userdata('user_id');
            $user = $this->ask_question_m->getUser($id);
            $qid = $this->ask_question_m->question_insert($_POST,$user);
            if ($user->answerSource=='A') {

             $this->ask_question_m->addQuestion_current($_POST,$user,$qid );
            }


             $param= $id;
           $command = "php ".FCPATH."index.php Login_c answerFromApi $param > /dev/null &";
          set_time_limit(0);
           exec($command);
         $ary=array();
         $ary['uid']=$user->id;
         $ary['question_name']=$_POST['questionTitle'];
         $ary['status']=0;
         $ary['created_date']=date("Y-m-d H:i:s");
         $ary['qid']= $qid;         
        $this->db->insert('user_question_count', $ary);
            
            $this->load->view('get_reponse_carousel');
//            if ($call) {
//                $this->session->set_flashdata('success', 'Your question submited successfully');
//                redirect('ask_questions');
//            } else {
//                redirect('ask_questions');
//            }
        }
    }

    public function answers_list() {
        $answerById = $this->session->userdata('user_id');
        $q_id = $this->uri->segment(3);
        $this->load->model('ask_question_m');
        $this->load->model('pro_message_m');
        $this->load->model('standard_answers_m');
        $data['pro_messages'] = $this->pro_message_m->get_pro_messages();
        $data['st_ans_list'] = $this->standard_answers_m->get_st_ans_list();
        $data['question'] = $this->ask_question_m->get_question_data($q_id);

        //print_r($data); exit;
        $data['answer_count'] = $this->ask_question_m->get_answers_count($q_id);
        $data['answers'] = $this->ask_question_m->get_answers($q_id, $data['answer_count']);
        $data['p_status'] = $this->ask_question_m->get_user_pro_status($q_id, $answerById);
        //print_r($data); exit;
        $this->load->view('common/header');
        $this->load->view('answers_v', $data);
        $this->load->view('common/footer');
    }

    public function change_progress_status() {
        $this->load->model('ask_question_m');
        $qid = $this->input->post('questionID');
        $aBy = $this->input->post('answerBy');
        $qBy = $this->input->post('questionBy');
        $progress_status = $this->input->post('progress_status');
        $res = $this->ask_question_m->check_p_status($qid, $aBy, $progress_status);
        $res2 = $this->ask_question_m->get_last_status($qid, $aBy, $progress_status);

        $data = $_POST;
        $data['DateTime'] = date("Y-m-d h:i:s");
        if (!empty($res2)) {
            $this->ask_question_m->p_status_dateto($res2->id, $data['DateTime']);
        }

        if ($res) {
            $this->session->set_flashdata('error', 'You already set this status.');
            redirect('ask_questions/answers_list/' . $qid);
        } else {

            $mail = $this->ask_question_m->p_status_insert($data);
        }
        if ($mail) {
            $res_qby = $this->ask_question_m->get_q_user($qBy);
            $res_pst = $this->ask_question_m->get_p_status($progress_status);

            //echo $res_qby->email;  exit;
            $to = $res_qby->email;
            //$to = 'ilt.hardikpatel@gmail.com';
            $subject = 'Sokrates Progress Message';
            $from = 'no-reply@sokrets.com';

            // To send HTML mail, the Content-type header must be set
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

            // Create email headers
            $headers .= 'From: ' . $from . "\r\n" .
                    'Reply-To: ' . $from . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();

            $bodyContent = '<html><body><span><h1>Hi, ' . $res_qby->firstName . '</h1><br/> Researcher <b>' . $res_pst->message . '</b><br/></span></body></html>';
            //$bodyContent = 'Researcher given your question answer, Pleae check your sokrets.';
            if (mail($to, $subject, $bodyContent, $headers)) {
                $this->session->set_flashdata('success', 'Progress Status updated successfully');
                redirect('ask_questions/answers_list/' . $qid);
            }
        } else {
            redirect('ask_questions/answers_list/' . $qid);
        }

        //        $this->session->set_flashdata('success', 'Progress Status updated successfully');
        //        redirect('ask_questions/answers_list/'.$qid);
    }

    public function submit_reply() {

        $this->load->model('ask_question_m');
        $call = $this->ask_question_m->reply_insert($_POST);
        if ($call) {
            $this->session->set_flashdata('success', 'Your reply submited successfully');
            redirect('ask_questions/answers_list/' . $this->input->post('questionID'));
        } else {
            redirect('ask_questions/answers_list/' . $this->input->post('questionID'));
        }
    }

    public function write_answers() {
        $this->load->model('ask_question_m');
        $q_id = $this->uri->segment(3);
        $question = $this->ask_question_m->get_question_row($q_id);
        $data['question'] = $question;
        $this->load->view('common/header');
        $this->load->view('write_answer_v', $data);
        $this->load->view('common/footer');
    }

    public function submit_answer() {
        $this->load->model('ask_question_m');
        $q_id = $this->uri->segment(3);
        $user = $this->ask_question_m->get_user_and_question($q_id);
        //echo $user->email; exit;        
        $this->form_validation->set_rules('answer', 'Answer', 'required');

        if ($this->form_validation->run() == FALSE) {

            $this->session->set_flashdata('error', validation_errors());
            redirect('ask_questions/write_answers/');
        } else {
            $this->load->model('ask_question_m');
            $call = $this->ask_question_m->answer_insert($_POST);

            if ($call) {

                $to = $user->email;
                $subject = 'Sokrates Answer';
                $from = 'no-reply@sokrets.com';

                // To send HTML mail, the Content-type header must be set
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                // Create email headers
                $headers .= 'From: ' . $from . "\r\n" .
                        'Reply-To: ' . $from . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();

                $bodyContent = '<html><body><span><h1>Hi, ' . $user->firstName . '</h1><br/> Researcher given your question <b>' . $user->questionTitle . '</b> answer.<br/> Pleae check your sokrets.</span></body></html>';
                //$bodyContent = 'Researcher given your question answer, Pleae check your sokrets.';
                if (mail($to, $subject, $bodyContent, $headers)) {
                    $this->session->set_flashdata('success', 'Your Answer submited successfully.');
                    redirect('ask_questions/questions');
                }
            } else {
                redirect('ask_questions/questions');
            }
        }
    }

    public function post_my_comment() {
        $this->load->model('ask_question_m');
        $data = $_POST;
        $ans = $this->input->post('ans');
        if ($ans != "") {
            $data['answer'] = $ans;
        }
        unset($data['ans']);
        //print_r($data);  exit;
        $call = $this->ask_question_m->post_comment($data);
        if ($call) {
            $this->session->set_flashdata('success', 'Your Comment submited successfully.');
            redirect('ask_questions/answers_list/' . $this->uri->segment(3));
        }
    }

    public function get_sugestion() {
       //  $q = $this->input->post('q');
       //  $url = sprintf("http://suggestqueries.google.com/complete/search?hl=en&ds=yt&client=youtube&hjson=t&cp=1&q=%s&alt=json", urlencode($q));
       // // print_r($url);  exit;
       //  $json = file_get_contents($url);

       //  $results = json_decode($json);

       //  foreach ($results[1] as $result) {
          
       
           
       // }
$newArr=  array();
 $q = $this->input->post('q');
         $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "http://suggestqueries.google.com/complete/search?hl=en&ds=yt&client=youtube&hjson=t&cp=1&q=".urlencode($q)."&alt=json");
    curl_setopt($ch, CURLOPT_POST, 0);
    curl_setopt($ch, CURLOPT_HTTPGET, 1);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $results = curl_exec ($ch);
    curl_close ($ch);
    $results = json_decode($results);
//print_r($results[1]);

    if (isset($results[1]) AND count($results[1]) != 0) {
        $newArr=$results[1];
    }
    
     foreach ($newArr as $result) { ?>
      <?php $var= ucfirst($result[0]).'?'; ?>
       <li style="cursor: pointer;" onclick="getSugVal('<?php echo $var;?>')" > <?php echo $var ; ?> </li>   
       
   <?php }
}

    public function get_my_question() {

        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = "";
        $data['sort_date'] = "";
        $data['sort_abc'] = "";
        $this->load->model('ask_question_m');

        $data['questions_answer'] = $this->ask_question_m->get_questions_ans($data);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        //prin_r($data);  exit;
        $this->load->view('my_questions_v', $data);
    }

    public function delete_seen_answer() {
        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = "";
        $data['sort_date'] = "";
        $data['sort_abc'] = "";
        $data['questionId'] = $this->uri->segment(3);
        $this->load->model('ask_question_m');
        if (@$data['questionId'] != "") {
            $this->ask_question_m->delete_question($data['questionId']);
        }
        $data['questions_answer'] = $this->ask_question_m->get_questions_ans($data);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        //print_r($data);  exit;
        $this->load->view('my_questions_v', $data);
    }

    public function serQuestionPro() {
        $id = $this->session->userdata('user_id');
        //$sort_date = $data['sort_date'];
        //$sort_abc = $data['sort_abc'];
        //$ser = $data['ser'];

        $ser = $this->input->post('ser');
        $sort_date = $this->input->post('sort_date');
        $sort_abc = $this->input->post('sort_abc');
        $order = "";

        $whr = "";
        if ($sort_date != "") {
            $order = "ORDER BY a.qiestion_id $sort_date";
        } else if ($sort_abc != "") {
            $order = "ORDER BY b.questionTitle $sort_abc";
        } else if ($ser != "") {
            $whr = "AND (a.questionTitle like '%$ser%') ";
        }
        $sql_p = $this->db->query("SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '" . $id . "' AND (b.isCompleted IS NULL OR b.isCompleted = 0) $whr $order");
        $user_pro_data = $sql_p->result_array();
        ?>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/progress-circle.css">

        <div class="row text-left" style="padding: 10px 180px;" >    
            <?php
            $sql_c_arr = $this->db->query("SELECT questionID FROM `tbl_mycomments` WHERE questionBy = '" . $this->session->userdata('user_id') . "' and messageBy != '" . $this->session->userdata('user_id') . "' AND isRead = 0 AND isDeleted = 0 GROUP BY questionID");
            $sql_c_arr->result_array();
            if (!empty($sql_c_arr->result_array())) {
                foreach ($sql_c_arr->result_array() as $rowcid) {
                    $cmntid[] = $rowcid['questionID'];
                }
            } else {
                $cmntid[] = "";
            }
            foreach ($user_pro_data as $row_pro) {
                ?>
                                            <!--<h4 style="font-size: 16px; font-weight: 600;color: #666564;;"><?php echo @$row_pro['questionTitle']; ?></h4>-->
                <div class="col-md-12 main-pro-div-pos <?php
                if (in_array($row_pro['qiestion_id'], $cmntid)) {
                    echo "res-com-act";
                } else {
                    echo "res-com-inct";
                }
                ?>" >
                         <?php if (in_array($row_pro['qiestion_id'], $cmntid)) { ?>
                        <span class="progress-comment"><a href="<?php echo site_url('ask_questions/give_input/' . $row_pro['qiestion_id'] . "/" . $row_pro['answerBy']); ?>" class="" style="text-decoration: none;color:#fff;">Click this box to give input</a></span><br/>
                    <?php } ?>
                    <h4 class="text-left" style="font-size: 13px; font-weight: 600;color: #666564;margin-bottom: 0px;">
                        <?php echo @$row_pro['questionTitle']; ?>
                    </h4>
                    <?php if (@$row_pro['process_indicator'] == 'progress-12') { ?>
                        <div class="user-progress-text1"  id="u_process_1" ><b>Understanding</b> your<br/> question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-36') {
                        ?>
                        <div class="user-progress-text2"  id="u_process_2" ><b>Researching</b> your<br/> question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-60') {
                        ?>
                        <div class="user-progress-text3"  id="u_process_3" ><b>Answering</b> your<br/> question.</div>
                        <?php
                    }
                    if (@$row_pro['process_indicator'] == 'progress-85') {
                        ?>
                        <div class="user-progress-text4"  id="u_process_3" ><b>Briefing</b> you on the<br/> answer.</div>
                        <?php
                    }
                    if ($row_pro['isCompleted'] == "") {
                        $process_indicator = 'progress-0';
                    } else {
                        $process_indicator = $row_pro['process_indicator'];
                    }
                    ?>
                    <div class="progress-circle <?php echo @$process_indicator; ?>">
                        <span><?php //echo @$pro_per[1];          ?></span>
                    </div>
                    <div class="" style="float: right;">
                        <span><?php //echo $row_pro['message'];     ?></span>
                    </div>
                </div>
            <?php } ?>
        </div>
        <?php
    }

    public function serQuestion() {

        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = $this->input->post('ser');
        $data['sort_date'] = $this->input->post('sort_date');
        $data['sort_abc'] = $this->input->post('sort_abc');
        $data['questionId'] = $this->input->post('del_question');

        $tab = $this->uri->segment(3);
        $this->load->model('ask_question_m');
//       
//        if (@$data['questionId'] != "") {
//            $this->ask_question_m->delete_question($data['questionId']);
//        }

        if ($tab == "MYQuestion") {
            $data1['questions_answer'] = $this->ask_question_m->get_questions_ans($data);
        }

        if ($tab == "NEWAnswers") {
            $data1['questions_answer'] = $this->ask_question_m->get_home_data_model($data);
        }

        //$data['questions_answer'] = $this->ask_question_m->get_home_data_model($data['id']);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        ?>
        <!--<h4 style="color: red;">New answers <span class="header_q_count" style="font-size: 11px;padding: 4px;border-radius: 14px;"> <?php echo @str_pad($ans_count->ans_count, 2, "0", STR_PAD_LEFT); ?></span></h4>-->
        <?php
        $month_str = "";
        foreach ($data1['questions_answer'] as $q) {
            @$monthName = date('F Y', strtotime($q['created']));
            $month_str .= $monthName . ',';
            @$dateArray[$monthName][] = $q;
        }

        $month = rtrim($month_str, ',');

        $monthArray = explode(',', $month);
        $monthArray = array_unique($monthArray);

        foreach ($data1['questions_answer'] as $q) {
            if (@$q['followUpQuestionsID'] != "") {
                $sql_follup = "SELECT * FROM `answer` WHERE questionID = '" . $q['question_id'] . "' and questionBy = '" . $this->session->userdata('user_id') . "' ";
                $exe_follup = $this->db->query($sql_follup);
                if ($exe_follup->num_rows() > 0) {
                    ?>
                    <h4>
                        <i style="font-weight: bold;color: #000;" class="fa fa-angle-right"></i> 
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>">
                            <?php echo @$q['questionTitle']; ?> <span style="color: #A5A4A4;font-weight: normal;font-size: 14px;">(<?php echo date('j F, Y', strtotime($q['created'])); ?>)</span>
                        </a>
                    </h4>
                    <span class="q-answer">
                        &nbsp; &nbsp; <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>"><?php echo @$exe_follup->first_row()->answer; ?></a>
                    </span>
                    <?php
                }
            } else {
                ?>
                <div class="q-a-width">
                    <h4>
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['questionTitle']; ?></a>

                    </h4>
                    <span class="q-answer">
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['answer']; ?></a>
                    </span>
                    <div class="delete-my-q-div">
                        <!--onclick="serQuestion('deleteQue-<?php //echo @$q['question_id'];    ?>');"-->
                        <a  alt="Delete"  onclick="openNav('Delete_It-<?php echo @$q['question_id']; ?>');"  href="javascript:void(0)"  >
                            <i style="color:gray;" class="fa fa-trash-o" ></i>
                        </a>
                    </div>
                </div>
                <?php
            }
        }
    }

    public function serQuestionNewA() {

        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = $this->input->post('ser');
        $data['sort_date'] = $this->input->post('sort_date');
        $data['sort_abc'] = $this->input->post('sort_abc');
        $data['questionId'] = $this->input->post('del_question');

        $tab = $this->uri->segment(3);
        $this->load->model('ask_question_m');

        if ($tab == "MYQuestion") {
            $data1['questions_answer'] = $this->ask_question_m->get_questions_ans($data);
        }

        if ($tab == "NEWAnswers") {
            $data1['questions_answer'] = $this->ask_question_m->get_home_data_model($data);
        }

        //$data['questions_answer'] = $this->ask_question_m->get_home_data_model($data['id']);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        ?>
        <!--<h4 style="color: red;">New answers <span class="header_q_count" style="font-size: 11px;padding: 4px;border-radius: 14px;"> <?php echo @str_pad($ans_count->ans_count, 2, "0", STR_PAD_LEFT); ?></span></h4>-->
        <?php
        foreach ($data1['questions_answer'] as $q) {
            if (@$q['followUpQuestionsID'] != "") {
                $sql_follup = "SELECT * FROM `answer` WHERE questionID = '" . $q['question_id'] . "' and questionBy = '" . $this->session->userdata('user_id') . "' ";
                $exe_follup = $this->db->query($sql_follup);
                if ($exe_follup->num_rows() > 0) {
                    ?>
                    <h4>
                        <i style="font-weight: bold;color: #000;" class="fa fa-angle-right"></i> 
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>">
                            <?php echo @$q['questionTitle']; ?> <span style="color: #A5A4A4;font-weight: normal;font-size: 14px;">(<?php echo date('j F, Y', strtotime($q['created'])); ?>)</span>
                        </a>
                    </h4>
                    <span class="q-answer">
                        &nbsp; &nbsp; <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $exe_follup->first_row()->id); ?>"><?php echo @$exe_follup->first_row()->answer; ?></a>
                    </span>
                    <?php
                }
            } else {
                ?>
                <div class="q-a-width">
                    <h4>
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['questionTitle']; ?></a>
                    </h4>
                    <span class="q-answer">
                        <a href="<?php echo site_url('ask_questions/question_answer/' . $q['question_id'] . '/' . $q['answer_id']); ?>"><?php echo @$q['answer']; ?></a>
                    </span>
                    <div class="seen-ans-div">
                        <a class="seen-it" alt="Delete"  onclick="openNav('Seen_It-<?php echo @$q['answer_id']; ?>');" href="javascript:void(0)"  >
                            Seen it
                        </a>
                    </div>
                </div>
                <?php
            }
        }
    }

    public function researcher_list($q_id, $q_by) {
        $this->load->model('ask_question_m');
        $q_id = $this->uri->segment(3);
        $q_by = $this->uri->segment(4);
        $data['ser'] = $this->input->post('ser');
        $data['researcher'] = $this->ask_question_m->get_researcher();

        $this->load->view('common/header');
        $this->load->view('researcher_list_v', $data);
        $this->load->view('common/footer');
    }

    public function transfer_researcher() {
        $this->load->model('ask_question_m');
        $data['assignFrom'] = $this->session->userdata('user_id');
        $data['assignTo'] = $this->session->userdata('user_id');
        $data['questionID'] = $this->uri->segment(3);
        $data['questionBy'] = $this->uri->segment(4);
        $data['questionBy'] = $this->uri->segment(5);
        $call = $this->ask_question_m->transfer_other_researcher($data);
        if ($call) {
            $this->session->set_flashdata('success', 'Your question assign successfully.');
            redirect('ask_questions/questions/');
        }
    }

    public function submit_follow_up_questions() {
        $this->load->model('ask_question_m');
        $id=$_POST['userID'];
            $user = $this->ask_question_m->getUser($id);
           // $qid = $this->ask_question_m->question_insert($_POST,$user);
        $qid = $this->ask_question_m->insert_follow_up_questions($_POST,$user);
     

            if ($user->answerSource=='A') {

             $this->ask_question_m->addQuestion_current($_POST,$user,$qid );
        }
            $param= $id;
           $command = "php ".FCPATH."index.php Login_c answerFromApi $param > /dev/null &";
            set_time_limit(0);
           exec($command);
            redirect($_SERVER['HTTP_REFERER']);
    
    }

    public function question_answer() {
        $id = $this->session->userdata('user_id');
        $q_id = $this->uri->segment('3');
        $a_id = $this->uri->segment('4');
        $this->load->model('ask_question_m');
        if ($q_id !='' && $a_id!='') {
           $data['questions'] = $this->ask_question_m->get_que_ans($id, $q_id, $a_id); # code...
        }else{
             $data['questions'] = $this->ask_question_m->getall_que_ans($id); # code...
        }
       
       
        $this->load->view('common/header');
        $this->load->view('question_answer_v', $data);
    }

     

    public function give_input() {
        $id = $this->session->userdata('user_id');
        @$q_id = $this->uri->segment('3');
        @$a_by = $this->uri->segment('4');
        $this->load->model('ask_question_m');
        $this->load->model('register_m');
        $userid = $this->session->userdata('user_id');
        $data['user_pro'] = $this->register_m->get_profile($userid);
        if ($q_id != "" && $a_by != "") {

            $data['comments'] = $this->ask_question_m->get_process_comment($id, $q_id, $a_by);
        } else {
            $data['comments'] = $this->ask_question_m->get_comment($id);
        }
        $data['u_cmnt_cnt'] = $this->ask_question_m->get_u_cmnt_cnt($id);
        
        if (empty($data['comments'])) {
            redirect('ask_questions/index');
        }
        $this->load->view('common/header');
        $this->load->view('give_input_v', $data);
    }

    public function submit_user_comment() {
        $data = $_POST; 
        @$q_id = $this->uri->segment('3');
        @$a_by = $this->uri->segment('4');
        $this->load->model('ask_question_m');
        $this->ask_question_m->submitUserComment($data);
        redirect('ask_questions/give_input/' . $this->input->post('questionID'). "/" . $this->input->post('answerBy')); 
    }

    public function readAnswer() {
        $id = $this->session->userdata('user_id');
        $a_id = $this->input->post('answer_id');
        $this->load->model('ask_question_m');
        $call = $this->ask_question_m->updateReadAns($a_id);
    }

    public function get_researcher_question() {
        $id = $this->session->userdata('user_id');
        $q_id = 9;
        $this->load->model('ask_question_m');
        $data['dialogue'] = $this->ask_question_m->get_dialogue($id, $q_id);

        $this->load->view('common/header');
        $this->load->view('dialogue_v', $data);
    }

    public function get_new_answer() {
        $data['id'] = $this->session->userdata('user_id');
        $data['ser'] = "";
        $data['sort_date'] = "";
        $data['sort_abc'] = "";
        $this->load->model('ask_question_m');
        $sql_p = $this->db->query("SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '" . $data['id'] . "' AND a.isDeleted = 0 AND a.followUpQuestionsID=NULL ORDER BY a.id DESC ");
        $data['user_pro_data1'] = $sql_p->result_array();
        
        if (!empty($data['user_pro_data1'])) {
            foreach ($data['user_pro_data1'] as $row_ind) {
                if (@$row_ind['process_indicator'] == 'progress-85' && $row_ind['isCompleted'] != "1") {
                    $this->ask_question_m->updateProcess($row_ind['id']);
                    $this->ask_question_m->updateAnswerStatus($row_ind['answerId']);
                }
            }
        }
        $data['questions_answer'] = $this->ask_question_m->get_home_data_model($data);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        //print_r($data);
        $this->load->view('my_answer_v', $data);
    }

    public function seen_new_answer() {
        $data['id'] = $this->session->userdata('user_id');
        $a_id = $this->uri->segment('3');
        $data['ser'] = "";
        $data['sort_date'] = "";
        $data['sort_abc'] = "";
        $this->load->model('ask_question_m');
        $call = $this->ask_question_m->updateReadAns($a_id);
        $followid = $this->ask_question_m->getFollowup($a_id);
         
        if(@$followid->id != ""){
            //$impid = implode(",", $followid);
           
            $this->ask_question_m->updatefollowReadAns($followid->id);
        }
        $data['questions_answer'] = $this->ask_question_m->get_home_data_model($data);
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        $this->load->view('my_answer_v', $data);
    }

//    public function delete_question_answer() {
//        $data['id'] = $this->session->userdata('user_id');
//        $data['questionId'] = $this->uri->segment('3');
//        $data['ser'] = "";
//        $data['sort_date'] = "";
//        $data['sort_abc'] = "";
//        $this->load->model('ask_question_m');
//        $this->ask_question_m->delete_question($data['questionId']);
//        $data['questions_answer'] = $this->ask_question_m->get_questions_ans($data['id']);
//        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
//        
//        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
//        
//        $this->load->view('my_question_v', $data);
//    }




   public function delete_question() {
      $qid = $this->input->post('qid');
      $this->db->where('questionID', $qid);
      $this->db->delete('answer');
      $this->db->where('qid', $qid);
      $this->db->delete('question_search_result');
      $this->db->where('questionID', $qid);
      $this->db->delete('tbl_researcher_current_questions');
      $this->db->where('id', $qid);
      $this->db->delete('questions');
   }



    public function get_progress_result() {
        $this->load->model('ask_question_m');
        $data['id'] = $this->session->userdata('user_id');
        //$sql_p = $this->db->query("SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '" . $data['id'] . "' AND a.isDeleted = 0 ORDER BY a.id DESC ");                           
        //$sql_p = $this->db->query("SELECT a.id as qiestion_id, a.questionTitle, a.followUpQuestionsID ,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '" . $data['id'] . "' AND (b.isCompleted IS NULL OR b.isCompleted = 0) ORDER BY a.id DESC");
       $uid= $data['id'];

         $sql_p = $this->db->query(" SELECT a.id AS qiestion_id,a.questionTitle,a.followUpQuestionsID ,a.created AS created_datetime,b.* FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID LEFT JOIN answer ON a.id=answer.questionID WHERE a.userID = $uid AND (answer.isRead=0 OR answer.isRead IS NULL ) AND a.isDeleted = 0 ORDER BY a.id DESC");

      
        $data['user_pro_data'] = $sql_p->result_array();
//        if (!empty($data['user_pro_data1'])) {
//            foreach ($data['user_pro_data1'] as $row_ind) {
//                if (@$row_ind['process_indicator'] == 'progress-85' && $row_ind['isCompleted'] != "1") {
//                    $this->ask_question_m->updateProcess($row_ind['id']);
//                    $this->ask_question_m->updateAnswerStatus($row_ind['answerId']);
//                }
//                if (@$row_ind['isCompleted'] != "1") {
//                    $proarr[] = $row_ind;
//                }
//            }
//        }
        //$data['user_pro_data'] = $proarr;
        $data['ser'] = "";
        $data['sort_date'] = "";
        $data['sort_abc'] = "";
        $data['ans_count'] = $this->ask_question_m->get_ans_count($data['id']);
        $data['progress_count'] = $this->ask_question_m->get_progress_count($data['id']);
        $this->load->view('my_progress_v', $data);
    }

    public function submit_permission() {
        $id = $this->session->userdata('user_id');
        if (isset($_POST['allow'])) {
            $per = "1";
        } else {
            $per = "2";
        }
        $this->load->model('ask_question_m');
        $call = $this->ask_question_m->updatePermission($id, $per);
        redirect('ask_questions/');
    }
    
    public function update_version() {
        $this->load->view('version_message');
    }

     public function add_questiontag() {
        $input=$this->input->post();
        $this->load->model('ask_question_m');
        $this->ask_question_m->addquestiontag($input);
        $tag_arr=$this->ask_question_m->getQuestionTag($input);
        foreach ($tag_arr as $key => $value) {
           echo '<a href="javascript:void(0)"> '.$value['tag'].', <i class="fa fa-times" aria-hidden="true" data-id=" '.$value['id'].'" data-qid="'.$input['qid'].'" onclick="closefun( '.$value['id'].','.$input['qid'].')" ></i></a>';
        }
    }

    public function remove_questiontag()
    {
         $input=$this->input->post();
        $this->load->model('ask_question_m');
        $this->ask_question_m->removequestiontag($input);
        $tag_arr=$this->ask_question_m->getQuestionTag($input);
        foreach ($tag_arr as $key => $value) {
           echo '<a href="javascript:void(0)"> '.$value['tag'].', <i class="fa fa-times" aria-hidden="true" data-id="'.$value['id'].'" data-qid="'.$input['qid'].'" onclick="closefun( '.$value['id'].','.$input['qid'].')" ></i></a>';
        }
    }

    public function update_answer_source() {
       
        $input=$this->input->post();
        $this->load->model('ask_question_m');
        $this->ask_question_m->updateAnswerSource($input);
       
    }

    public function answerFromApi(){
$user_id=$this->session->userdata('user_id');
            $questions=$this->ask_question_m->getQuestionforApi($user_id);
            foreach ($questions as $key => $question) {
                 $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID'] );
                 $book_res= count($sql_gn->result_array());
                if ($book_res==0) {
                     $data = array('process_indicator' => "progress-36" );
            $responce = $this->researcher_m->update_indicator_process($question['questionID'], $data);
                    $bookShelfRes =$this->researcher_m->library_search($question['questionTitle'],'api',$user_id);
                    foreach ($bookShelfRes as $key1 => $bookShelf) {
                     if ($key1<10) {
                            $input=array();
                            $input['count']=$key1+1;
                            $input['content']=$bookShelf['url'];
                            $input['qid']=$question['questionID'];
                            $input['type']='bookshelf';
                            $input['txt_response']=$bookShelf['content'];
                            $input['status']='pending';
                            $input['created_at']=date("Y-m-d H:i:s");
                            $input['update_at']=date("Y-m-d H:i:s");  
                            $this->db->insert('question_search_result', $input);
                     }
                 }
            
            $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']);
            $previous_res= count($sql_gn->result_array());
            $addInternetRes=10-$previous_res; 
            $counter=$previous_res;
            if ($addInternetRes>0) {
                $accessKey = '379bfe6adde24750bfd9c2fe5ca49dc3';
                $endpoint = 'https://api.cognitive.microsoft.com/bing/v7.0/search';
                $res = $this->BingWebSearch($endpoint, $accessKey, $question['questionTitle']);
               $results=@$res->webPages->value;
                foreach ($results as $key_data => $result) {               
                      if ($addInternetRes>$key_data) {
                          $counter++;
                           $input=array();
                            $input['count']=$counter;
                            $input['content']=$result->url;
                            $input['qid']=$question['questionID'];
                            $input['type']='internet';
                            $input['status']='pending';
                            $input['created_at']=date("Y-m-d H:i:s");
                            $input['update_at']=date("Y-m-d H:i:s");                              
                            $this->db->insert('question_search_result', $input);
                      }

                }
            }
        }

         $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']." AND status='pending'"  );
         $search_results= $sql_gn->result_array();
         foreach ($search_results as $search_key => $search_result) {

            $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']." AND status='reject'"  );
                    $reject_res= $sql_gn->result_array();
                if (count($reject_res)==6) {
                    $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $this->session->userdata('user_id'),
                    'answerBy' =>0,
                    'answer' => "I cannot find a good answer. Please reformulate your question and try again.",
                    'progress_status' => 4,
                    'sourceURL' => '',
                    'replyType' => 'Answer',
                    'isRead'=>1
                    );  
                    $answerid = $this->researcher_m->insert_researcher_answer($form_data);
                    $this->db->set('ans_accept', 'Y');
                    $this->db->where('id', $question['questionID']); 
                    $this->db->update('questions');
                    break; 
                }

                if ($search_result['type']=='bookshelf') {
                    $txtApiRes= array();
                      $txtApiRes['response']=1;
                      $txtApiRes['content']=$search_result['txt_response'];                     
                }else{
                     $txtApiRes=  $this->txtMakerApi($search_result['content']); 
                     $txtApiRes=json_decode($txtApiRes,true); 
                }
                    
             if ($txtApiRes['response']==-1 AND $txtApiRes['content']=='') {
                    $this->db->set('status', 'no_ans'); 
                    $this->db->where('id', $search_result['id']); 
                    $this->db->update('question_search_result'); 
                }else{                        
                $ansApiRes=$this->getAnswerApi($question['questionTitle'],$txtApiRes['content']);                    
                    $ansApiRes=json_decode($ansApiRes,true);
                  
                if (empty($ansApiRes)) {
                    $this->db->set('status', 'no_ans'); 
                    $this->db->where('id', $search_result['id']); 
                    $this->db->update('question_search_result'); 

                }else{
                    $data = array('process_indicator' => "progress-60" );
                $responce = $this->researcher_m->update_indicator_process($question['questionID'], $data);
                 $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $this->session->userdata('user_id'),
                    'answerBy' =>0,
                    'answer' => $ansApiRes[0]['text'],
                    'progress_status' => 4,
                    'sourceURL' => $search_result['content'],
                    'replyType' => 'Answer'
                    );

            $this->db->set('answer', $ansApiRes[0]['text']); 
            $this->db->set('txt_response', $txtApiRes['content']); 
            $this->db->set('status', 'has_ans');
            $this->db->where('id', $search_result['id']); 
            $this->db->update('question_search_result');             
            $answerid = $this->researcher_m->insert_researcher_answer($form_data);
            $cur_q_id =$question['id'];
            $data = array('process_indicator' => "progress-85","isCompleted"=>1 );
            $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data);
            break; 
                }
               
                }   

           
         }
         if (count($search_results)==0) {
               $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $this->session->userdata('user_id'),
                    'answerBy' =>0,
                    'answer' => "I cannot find a good answer. Please reformulate your question and try again.",
                    'progress_status' => 4,
                    'sourceURL' => '',
                    'replyType' => 'Answer',
                    'isRead'=>1
                    );  
                    $answerid = $this->researcher_m->insert_researcher_answer($form_data);
         }


     }
            
    }


    public function BingWebSearch($url, $key, $query) {
        /* Prepare the HTTP request.
         * NOTE: Use the key 'http' even if you are making an HTTPS request.
         * See: http://php.net/manual/en/function.stream-context-create.php.
         */
        $headers = "Ocp-Apim-Subscription-Key: $key\r\n";
        $options = array('http' => array(
                'header' => $headers,
                'method' => 'GET'));

        // Perform the request and get a JSON response.
        $context = stream_context_create($options);
        $result = file_get_contents($url . "?q=" . urlencode($query), false, $context);

        // Extract Bing HTTP headers.
        $headers = array();
        foreach ($http_response_header as $k => $v) {
            $h = explode(":", $v, 2);
            if (isset($h[1]))
                if (preg_match("/^BingAPIs-/", $h[0]) || preg_match("/^X-MSEdge-/", $h[0]))
                    $headers[trim($h[0])] = trim($h[1]);
        }

        //return array($headers, $result);
        return json_decode($result);
    }

       public function addJobsinqueue(){

       //$this -> jobs -> clear('high');
      $this -> jobs->worker('worker', 'high', null);
          

       //$this -> jobs -> create('high', 'ask_questions', 'addnew_questiontag', '', '','18');
       echo $this -> jobs -> get_queue_size('high');
    }

     public function addnew_questiontag() {
        
         $input=array();
        $input['qid']=100;
        $input['tag']="Hello00";
         $input['createDate']=date("Y-m-d H:i:s");
         $this->db->insert('question_tag', $input);
       // $this->ask_question_m->addquestiontag($input);
        
    }

    public function addApiQuestionResponse()
    {
        $uid=$this->session->userdata('user_id');
        $input=$this->input->post();
        if ($input['response']=='Y') {
          $this->db->set('ans_accept', 'Y');
            $this->db->where('id', $input['qid']); 
            $this->db->update('questions');

         $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$input['qid']." AND status='has_ans'" );
         $search_results= $sql_gn->row();
         if ($search_results->type=="internet") {
           $var= "Y";
         }else{
           $var= "N";
         }
         
             $this->db->set('status', 'accept');
            $this->db->where('qid', $input['qid']); 
            $this->db->where('status', 'has_ans');   
            $this->db->update('question_search_result');
            
        $this->db->where('questionID', $input['qid']);
        $this->db->set('isRead', 1);
        $this->db->update('answer');

         $sql_q = "SELECT count(*) as q_count FROM questions INNER JOIN answer on questions.id=answer.questionID WHERE answer.isDeleted = 0 and answer.isRead = 0 AND answer.questionBy = $uid AND answer.replyType = 'Answer' ORDER BY answer.id  ";          
  $query_q = $this->db->query($sql_q);
  $my_question_counter= $query_q->first_row()->q_count;
  echo json_encode(["response"=>$var,"count"=>$my_question_counter]);
        }else{
            $this->db->set('status', 'reject');
            $this->db->where('qid', $input['qid']); 
            $this->db->where('status', 'has_ans');   
            $this->db->update('question_search_result');

            $this->db->set('isCompleted', 0);
            $this->db->set('process_indicator', 'progress-36');
            $this->db->where('questionID', $input['qid']); 
            $this->db->update('tbl_researcher_current_questions');

            $this->db->where('questionID', $input['qid']);
            $this->db->delete('answer');
           $param= $this->session->userdata('user_id');
           $command = "php ".FCPATH."index.php Login_c answerFromApi $param > /dev/null &";
           set_time_limit(0);
           exec($command);
            $sql_q = "SELECT count(*) as q_count FROM questions INNER JOIN answer on questions.id=answer.questionID WHERE answer.isDeleted = 0 and answer.isRead = 0 AND answer.questionBy = $uid AND answer.replyType = 'Answer' ORDER BY answer.id  ";          
  $query_q = $this->db->query($sql_q);
  $my_question_counter= $query_q->first_row()->q_count;
  echo json_encode(["response"=>"Your response stored.","count"=>$my_question_counter]);

             


        }
    }

    public function txtMakerApi($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8002/webscrap/api/getresult");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        if (empty($server_output)) {
           $server_output=json_encode(array('response' =>-1 , "content"=>""));
        }
       
        return $server_output;
    }


   public function getAnswerApi($question,$context)
   {
     $dara='[{"probability":0.9612194686265066,"text":"Airplanes"},{"probability":0.02791164240670989,"text":"Igi airport"},{"probability":0.003283938142241936,"text":"Airplanes etc."},{"probability":0.0020482309636505195,"text":"Marine vessels, airplanes"},{"probability":0.0008846971205521158,"text":"I"},{"probability":0.0007969964649480403,"text":"Airport"},{"probability":0.0006310153649209266,"text":"Airplanes etc. )"},{"probability":0.0005824748117042068,"text":"Vessels, airplanes"},{"probability":0.00048486547608508006,"text":"Airplanes etc. ), waste disposal landfills, open burning etc."},{"probability":0.0004044977539120342,"text":"Mobile sources ( e.g. vehicular emission, marine vessels, airplanes"},{"probability":0.0003912499050642828,"text":"Jeep"},{"probability":0.0002865673816609498,"text":"Igi"},{"probability":0.00021785169850611222,"text":"Airplanes etc. ), waste disposal landfills, open burning etc. 3. air pollutants"},{"probability":0.00017299555218996905,"text":"Igi airport, it"},{"probability":0.00016042567759797348,"text":"Once"},{"probability":0.00013336643311969267,"text":"Cars and jeep"},{"probability":0.00010561669754323736,"text":"Anand viha r isbt, igi airport"},{"probability":0.00010188187784893857,"text":"Dwarka, igi airport"},{"probability":9.876147160547133e-05,"text":"Igi airport, it o"},{"probability":8.345617363179302e-05,"text":"N"}]';
     return $dara;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "http://52.178.25.154:8004/predict");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        $data = array(
            'context' => $context,
            'question' => $question
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
       if (empty($output)) {
         $output=array(); 
       }
       return $output;
       
   }

    public function partialResponse()
    {
        $response=array();
        ignore_user_abort(true);
        ob_start();
        echo json_encode($response);
        header("Status: 200");
        header($_SERVER["SERVER_PROTOCOL"] . " 200 Ok");
        header("Content-Type: application/json");
        header('Content-Length: '.ob_get_length());
        ob_end_flush();
        ob_flush();
        flush();
    }

   public function execFunction(){
    echo "dadas";
         $input['qid']=100;
          $input['tag']="Hello00";
         $input['createDate']=date("Y-m-d H:i:s");
         $this->db->insert('question_tag', $input);
   } 

    public function execRunFunction(){
         ini_set('display_errors', 1);
        $param = 2;
         $command = "php ".FCPATH."index.php Login_c answerFromApi $param > /dev/null &";
        exec($command);
        echo $command ;
   } 

   public function addBookshelfDocument()
   {
         $input=$this->input->post();
         $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$input['qid']." AND status='accept' Order By id DESC "  );
         $responase= $sql_gn->row_array();
         $path=$this->getUrltoPdf($input['url']);
         $filename = basename($path);
         copy($path, "/home/they/web_app/sokrets/uploads/files/".$filename);
         $inputArr=array();
        $inputArr['file_name']=$filename;
        $inputArr['user_id']=$this->session->userdata('user_id');
        $inputArr['content']=$responase['txt_response'];
        $inputArr['url']=base_url().'uploads/files/'.$filename;
        $inputArr['thumbnil']=$this->getThumbnailofDoc($inputArr['url']);
        
         $this->db->insert('tbl_files', $inputArr);
   }


   public function getUrltoPdf($url)
   {
    //$url="https://en.wikipedia.org/wiki/Fighter_aircraft";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8001/urltopdf");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         $server_output = curl_exec($ch);
        curl_close ($ch);    
        return $server_output;


       //  $ch = curl_init();
       //  $headers=array();
       //  curl_setopt($ch, CURLOPT_URL, 'http://104.40.153.156:8001/urltopdf/'.$url);
       //  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
       //  curl_setopt($ch, CURLOPT_HEADER, 0);
       //  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       //  $output = curl_exec($ch);
       //  $info = curl_getinfo($ch);
       //  curl_close($ch);
       // return $output;
       
   }

   public function getThumbnailofDoc($url)
   {
//$url="https://demo.sokrates.ai/uploads/files/Economist_-_Tech%E2%80%99s_new_stars_have_it_all%E2%80%94except_a_path_to_high_profits_-_The_trouble_with_tech_unicorns.pdf";
     $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8001/getthumbnail");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          $server_output = curl_exec($ch);
        curl_close ($ch); 
        $filename = basename($server_output);
        copy($server_output, "/home/they/web_app/sokrets/uploads/doc_image/".$filename);
        $img_url=base_url()."uploads/doc_image/".$filename;
        return $img_url;
      //   $str = preg_replace('#^https?://#', '', $url);
      //   $ch = curl_init();
      //   $headers=array();
      //   curl_setopt($ch, CURLOPT_URL, 'http://104.40.153.156:8001/getthumbnail/'.$str);
      //   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      //   curl_setopt($ch, CURLOPT_HEADER, 0);
      //   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      //    $output = curl_exec($ch);
      //   $info = curl_getinfo($ch);
      //   curl_close($ch);
      //    $filename = basename($output);
      //   copy($output, "/home/they/web_app/sokrets/uploads/doc_image/".$filename);
        
      //    $img_url=base_url()."uploads/doc_image/".$filename;
      // // echo  $output;
      //  //print_r($info);
      //  return $img_url;
       
   }

   public function txtMakerApiDemo(){
        $url="https://en.wikipedia.org/wiki/Fighter_aircraft";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://52.178.25.154:8002/webscrap/api/getresult");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        if (empty($server_output)) {
           $server_output=json_encode(array('response' =>-1 , "content"=>""));
        }
        print_r($server_output) ;
    }

    public function delete_question_per()
    {
        $input=$this->input->post();
        $responce = $this->researcher_m->deleteQuestion($input['qid']);
        
    }


}
