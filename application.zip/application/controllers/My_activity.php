<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_activity extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }

        $this->lastActivity();
        $this->load->model('my_activity_m');
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {
        $id = $this->session->userdata('user_id');
        $data['score'] = $this->my_activity_m->get_my_score($id);
        $data['st_count'] = $this->my_activity_m->get_status_count($id);
        $this->load->view('common/header');
        $this->load->view('my_activity_v', $data);
        $this->load->view('common/footer');
    }

    public function update_pro_message() {
        $id = $this->input->post('id');
        $res = $this->pro_message_m->edit_pro_message($id, $_POST);
        if ($res) {
            $this->session->set_flashdata('success', 'Progress messag updated successfully');
            redirect('pro_message');
        } else {
            redirect('pro_message');
        }
    }
    
    public function get_researcher_activity() {
        $id = $this->session->userdata('user_id');
        $data['activity'] = $this->pro_message_m->researcher_activity($id);        
    }

}
