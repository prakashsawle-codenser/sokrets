<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Researcher extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('researcher_m');
        if ($this->session->userdata('user_id') == '') {
            redirect("researcher_login");
        }
        $this->lastActivity();
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {
        $data['r_question_instr'] = $this->researcher_m->get_researcher_instructions('QUESTION_INSTRUCTIONS');
        $data['r_comment_instr'] = $this->researcher_m->get_researcher_instructions('COMMENT_INSTRUCTIONS');
        $data['r_answer_instr'] = $this->researcher_m->get_researcher_instructions('ANSWER_INSTRUCTIONS');
        $data['r_dup_question_instr'] = $this->researcher_m->get_researcher_instructions('DUPLICATE_QUESTION_INSTRUCTIONS');
        $data['r_dup_question_instr'] = $this->researcher_m->get_researcher_instructions('ANSWER_INSTRUCTIONS');
        $data['r_answer_temp_instr'] = $this->researcher_m->get_researcher_instructions('ANSWER_TEMPLATE_INSTRUCTIONS');
        $data['r_asker_not_resp'] = $this->researcher_m->get_researcher_instructions('ASKER_NOT_RESPONDING');
        $data['sql_st_ans'] = $this->researcher_m->get_standard_ans('C');
        $data['sql_st_ans_a'] = $this->researcher_m->get_standard_ans('A');
        $data['row_cur'] = $this->researcher_m->get_current_queation();

        $data['r_data'] = $this->researcher_m->get_researcher_data();
        //print_r($data['r_data']);  exit;
        if (@$data['row_cur']->questionID != "") {
            $data['row_coments'] = $this->researcher_m->get_comments($data['row_cur']->questionID);
        }
        //$data['similer_question'] = $this->researcher_m->get_similar_q($data['r_question']->id, "Zuckerberg's testimony");
        //$data['r_question_script'] = $this->researcher_m->get_researcher_instructions('RESEARCHER_QUESTION');
        $this->load->view('researcher_home_v', $data);
    }

    public function get_researcher_question() {
        $id = $this->session->userdata('user_id');
        $data['r_data'] = $this->researcher_m->get_researcher_detail();
        $data['r_question'] = $this->researcher_m->get_researcher_q();

        //$data['r_duplicate_script'] = $this->researcher_m->get_researcher_instructions('DUPLICATE_QUESTION');
        //$data['similer_question'] = $this->researcher_m->get_similar_q($data['r_question']->id, "testimony");
        //print_r($data['similer_question']);  exit;
        $form_data = array(
            'questionBy' => $data['r_question']->questionBy,
            'answerBy' => $data['r_data']->id,
            'questionID' => $data['r_question']->id,
            'process_indicator' => $this->input->post('process'),
            'start_time' => date('Y-m-d H:i:s')
        );
        $data['curQueId'] = $this->researcher_m->add_current_queation($form_data);
        $this->researcher_m->add_new_queation_point();
        echo json_encode($data);
    }

    public function add_researcher_comment() {
        $data = $_POST;
        $responce = $this->researcher_m->insert_researcher_comment($data);
    }

    public function add_researcher_Answer() {
        //$data = $_POST; print_r($data); exit;
        $cur_q_id = $this->input->post('cur_q_id');
        @$s_url = $this->input->post('sourceURL');
        $imp_url = $s_url;
//        if ($s_url != "") {
//            $imp_url = implode(",", $s_url);
//        } else {
//            $imp_url = "";
//        }
        $form_data = array(
            'questionID' => $this->input->post('questionID'),
            'questionBy' => $this->input->post('questionBy'),
            'answerBy' => $this->input->post('answerBy'),
            'answer' => $this->input->post('answer'),
            'progress_status' => 4,
            'sourceURL' => $imp_url,
            'replyType' => 'Answer'
        );

        $answerid = $this->researcher_m->insert_researcher_answer($form_data);
        $cur_q_id = $cur_q_id;
        $data_post['process_indicator'] = $this->input->post('process');
        $data_post['totalTime'] = $this->input->post('totalTime');
        $data_post['end_time'] = date('Y-m-d H:i:s');
        $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data_post);
      $user=  $this->researcher_m->get_question_user($this->input->post('questionBy'));
       $question=  $this->researcher_m->get_question($this->input->post('questionID'));
      $this->researcher_m->sendMail($user,$this->input->post('questionID'),$answerid,$question->questionTitle);
    }

    public function add_researcher_Answer_wait() {
        $form_data = $_POST; //print_r($data); exit;
        $cur_q_id = $this->input->post('cur_q_id');
        @$s_url = $this->input->post('sourceURL');
        if ($s_url != "") {
            $imp_url = implode(",", $s_url);
        } else {
            $imp_url = "";
        }

        $form_data['sourceURL'] = $imp_url;
        $responce = $this->researcher_m->insert_researcher_answer_wait($form_data);
        $cur_q_id = $cur_q_id;
        $data_post['process_indicator'] = $this->input->post('process');
        $data_post['totalTime'] = $this->input->post('totalTime');
        $data_post['end_time'] = date('Y-m-d H:i:s');
        $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data_post);
    }

    public function add_researcher_comment_finish() {
        $cur_q_id = $this->input->post('id');
        //$data_post = $_POST;
        $com = array(
            'questionID' => $this->input->post('questionID'),
            'questionBy' => $this->input->post('questionBy'),
            'answerBy' => $this->input->post('answerBy'),
            'messageBy' => $this->input->post('answerBy'),
            'comment' => 'Thanks! I will notify you when I have the answer.',
            'is_final'=>1
        );
        $responce = $this->researcher_m->insert_researcher_comment($com);
        $cur_q_id = $cur_q_id;
        //$data_post['cur_q_id'] = $cur_q_id;;
        //$data_post['process_indicator'] = $this->input->post('process_indicator');
        //$data_post['totalTime'] = $this->input->post('totalTime');
       // $data_post['end_time'] = date('Y-m-d H:i:s');
        //print_r($data_post); exit;
        //$responce = $this->researcher_m->update_indicator_process($cur_q_id, $data_post);
    }

    public function update_indicator() {
        $cur_q_id = $this->input->post('cur_q_id');
        $data = array('process_indicator' => $this->input->post('process_indicator') );

        // print_r($data); exit;
        $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data);

          }

          public function update_indicator_remove_notifymsg() {
       $cur_q_id = $this->input->post('cur_q_id');
        $data = array('process_indicator' => $this->input->post('process_indicator') );

        // print_r($data); exit;
          $this->researcher_m->update_indicator_process($cur_q_id, $data);
           
           $responce= $this->researcher_m->get_tempory_question($cur_q_id);
           $this->researcher_m->deleteNotifyComments($responce);
           
          }

    public function getAnswerTemplate(){

        //$cur_q_id = $this->input->post('cur_q_id');
        //$data = array('process_indicator' => $this->input->post('process_indicator') );

        // print_r($data); exit;
        //$responce = $this->researcher_m->update_indicator_process($cur_q_id, $data);

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL,"http://52.178.25.154:8005/webscrap/api/getresult");
        $payload = json_encode( array( "url"=> "https://en.wikipedia.org/wiki/Fighter_aircraft" ) );
       
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);
        
        echo  $server_output;
        curl_close ($ch);
      
    }


    public function checkapifun(){

 $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://52.178.25.154:8004/predict");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, true);

$data = array(
    'context' => 'basketball is a sport',
    'question' => 'what is basketball?'
);

curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$output = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);
print_r($output);
//         $ch = curl_init();

// curl_setopt($ch, CURLOPT_URL,"http://52.178.25.154:8004/predict");
// curl_setopt($ch, CURLOPT_POST, 1);
//   curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:multipart/form-data'));
// curl_setopt($ch, CURLOPT_POSTFIELDS,
//             "question=What is Basketball?&context=Basketball is a sport, it can be played by 10 people at a time.");

// // In real life you should use something like:
// // curl_setopt($ch, CURLOPT_POSTFIELDS, 
// //          http_build_query(array('postvar1' => 'value1')));

// // Receive server response ...
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// $server_output = curl_exec($ch);
// if (curl_errno ( $ch )) {
//     echo "adsd";
//             echo curl_error ( $ch );
//             curl_close ( $ch );
//             exit ();
//         }
        
// curl_close ($ch);
// print_r($server_output);
    }



    public function update_timer() {
        $data = $_POST;
        $responce = $this->researcher_m->update_stopwatch($data['id'], $data);
    }

    public function get_nav_search() {
     
        error_reporting(0);
        $ser = $this->input->post('question');
        $ans = $this->input->post('answer');
        $data['iProgressPer'] = $this->input->post('iProgressPer');
        //print_r($_POST);  exit;
        //$accessKey = '8c571fd887c94e138ff4d2d400bc6737';
        //$accessKey = 'cedfca46ae024f5cb6a02f6bcba0587e';
        $accessKey = '379bfe6adde24750bfd9c2fe5ca49dc3';
        
        $endpoint = 'https://api.cognitive.microsoft.com/bing/v7.0/search';
        @$term = $ans;
   //  $term = "Mark Zuckerberg’s testimony before the US Congress has not restored trust among Facebook users because";
        if ($term != "") {
           
            $res = $this->BingWebSearch($endpoint, $accessKey, $term);
            $data['ser'] = @$res->webPages->value;
        
        } else {
            $res = "";
            $data['ser'] = "";
        }
       // print_r($res); exit;
        $data['question'] = $ser;
        $data['answer'] = $ans;
        $ans=trim($ans);
        $data['library_result'] =$this->researcher_m->library_search($ans,'researcher');
       

        $this->load->view('researcher_nav_search_v', $data);
    }

    public function BingWebSearch($url, $key, $query) {
        /* Prepare the HTTP request.
         * NOTE: Use the key 'http' even if you are making an HTTPS request.
         * See: http://php.net/manual/en/function.stream-context-create.php.
         */
        $headers = "Ocp-Apim-Subscription-Key: $key\r\n";
        $options = array('http' => array(
                'header' => $headers,
                'method' => 'GET'));

        // Perform the request and get a JSON response.
        $context = stream_context_create($options);
        $result = file_get_contents($url . "?q=" . urlencode($query), false, $context);

        // Extract Bing HTTP headers.
        $headers = array();
        foreach ($http_response_header as $k => $v) {
            $h = explode(":", $v, 2);
            if (isset($h[1]))
                if (preg_match("/^BingAPIs-/", $h[0]) || preg_match("/^X-MSEdge-/", $h[0]))
                    $headers[trim($h[0])] = trim($h[1]);
        }

        //return array($headers, $result);
        return json_decode($result);
    }

    public function get_researcher_response() {

        $row_coments = $this->researcher_m->get_researcher_res($_POST);
        $q_user = $this->researcher_m->get_question_user($this->input->post('questionBy'));
        $uread_count=  $this->researcher_m->get_unread_count($_POST);
        $uread_count=count($uread_count);
        if ( $uread_count >0) {
            echo 1; 
            die;
        }else{
        $this->researcher_m->update_read_status($_POST);  
        }
        ?>

    <?php
            foreach ($row_coments as $row_comnt) {
                if ($row_comnt['answerBy'] != $row_comnt['messageBy']) {
                 

                    if (isset($q_user->firstName)) {
                        ?>
                        <img style="margin: 8px 0;border: 1px solid #D5D5D5;width: 30px;height: 30px;border-radius: 56px;display: inline-block;" alt="user-image" src="<?php echo base_url() . USER_IMAGE . $q_user->user_image; ?>" class="img-responsive asker-img"  />
                        <?php
                    }
                    echo "<i>" . preg_replace('/\s+/', ' ', $row_comnt['comment']) . "</i><br>";
                   

                } else {  ?>

                     <input type="hidden" value="<?php echo $row_comnt['comment']; ?>" id="inewQue" />
                    <?php
                    echo "<span id='iSelAns'>" . preg_replace('/\s+/', ' ', $row_comnt['comment']) . "</span><br>";
                 }
            }
            ?>
           
      
    <?php
    }


    public function update_question()
    {
            $cur_q_id = $this->input->post('qid');
        $data = array('updated_question' => $this->input->post('update_question') );
     $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data);
    }

     public function sendMail($user,$qid,$aid,$question)
    {
        $message='';
        $message.="<p>Hi ".$user->firstName.", You have received an answer to your question:</p>";
        $message.="<p style='color:red;'>".$question."</p>";
         $message.="<a href='http://cmldemo.com/new_sokrets/ask_questions/question_answer/".$qid."/".$aid."'>(click to see the answer)</a> <br>";
         $message.="<img src='http://cmldemo.com/new_sokrets/assets/images//login-logo.png' style='width:9%; display: block;max-width: 100%;height: auto;'>"; 
        $this->load->library('email');
        $config['protocol']    = 'smtp';
        $config['smtp_host']    = 'ssl://smtp.gmail.com';
        $config['smtp_port']    = '465';
        $config['smtp_timeout'] = '7';
        $config['smtp_user']    = 'prakashsawle@gmail.com';
        $config['smtp_pass']    = '9527Pss309515';
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
        $config['validation'] = TRUE; // bool whether to validate email or not      
        $this->email->initialize($config);
        $this->email->from('prakashsawle@gmail.com', 'prakash');
        $this->email->to('p.sawle@codensernetworks.com'); 
        $this->email->subject('Sokrates You have received an answer to your question.');
        $this->email->message($message);  
        $this->email->send();
        
    }


      
  
}
