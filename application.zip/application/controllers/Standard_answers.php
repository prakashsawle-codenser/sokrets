<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Standard_answers extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }

        $this->lastActivity();
        $this->load->model('standard_answers_m');
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {
        $data['st_ans_list'] = $this->standard_answers_m->get_st_ans_list();
        $this->load->view('common/header');
        $this->load->view('standard_answers_v', $data);
        $this->load->view('common/footer');
    }

    public function update_s_ans() {
        $id = $this->input->post('id');
        $res = $this->standard_answers_m->edit_s_ans($id, $_POST);
        if ($res) {
            $this->session->set_flashdata('success', 'Message updated successfully');
            redirect('standard_answers');
        } else {
            redirect('standard_answers');
        }
    }
    
    public function add_s_ans() {
       
        $res = $this->standard_answers_m->add_s_ans($_POST);
        if ($res) {
            $this->session->set_flashdata('success', 'Answer Add successfully');
            redirect('standard_answers');
        } else {
            redirect('standard_answers');
        }
    }
    
    public function delete_s_ans() {
        $id = $this->uri->segment(3);
        $res = $this->standard_answers_m->delete_s_ans($id);
        if ($res) {
            $this->session->set_flashdata('success', 'Answer deleted successfully');
            redirect('standard_answers');
        } else {
            redirect('standard_answers');
        }
    }
   
}
