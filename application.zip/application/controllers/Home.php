<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct() {

        parent::__construct();
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }
        $this->lastActivity();
        //$this->sendNotification();
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {

        $this->load->model('ask_question_m');
        $id = $this->session->userdata('user_id');
        $data['questions'] = $this->ask_question_m->get_home_data($id);
        //$questions = $this->ask_question_m->get_questions($id);
        if ($this->session->userdata('userType') == 2) {
            redirect('ask_questions/questions');
        } else {
            $this->load->view('common/header');
            $this->load->view('home', $data);
            // $this->load->view('common/footer');
        }
    }

    public function navigation() {
        $this->load->view('navigation');
    }

//    public function sendNotification() {
//        $id = $this->session->userdata('user_id');
//        $sql = "SELECT * FROM `answer` WHERE questionBy = $id AND notificationStatus = 0";
//
//        $query = $this->db->query($sql);
//
//        if ($query->num_rows() > 0) {
//            //print_r($row->id); exit;
//            foreach ($query->result() as $row) { 
//                echo $row->id;
//               // $d['id'] = $row->id;
//               // $notify[] = $d;
//               
////                $sql1 = "UPDATE `answer` SET `notificationStatus` = '1' WHERE `questionBy` = $id and `id` = $row->id ";
////                $query1 = $this->db->query($sql1);
//            }
//            
//           // return $notify;
//        }
//    }
//    public function register() {
//
//        // create the data object
//        $data = new stdClass();
//
//        // load form helper and validation library
//        $this->load->helper('form');
//        $this->load->library('form_validation');
//
//        // set validation rules
//        $this->form_validation->set_rules('username', 'Username', 'trim|required|alpha_numeric|min_length[4]|is_unique[users.username]', array('is_unique' => 'This username already exists. Please choose another one.'));
//        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');
//        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
//        $this->form_validation->set_rules('password_confirm', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');
//
//        if ($this->form_validation->run() === false) {
//
//            // validation not ok, send validation errors to the view
//            $this->load->view('header');
//            $this->load->view('user/register/register', $data);
//            $this->load->view('footer');
//        } else {
//
//            // set variables from the form
//            $username = $this->input->post('username');
//            $email = $this->input->post('email');
//            $password = $this->input->post('password');
//
//            if ($this->user_model->create_user($username, $email, $password)) {
//
//                // user creation ok
//                $this->load->view('header');
//                $this->load->view('user/register/register_success', $data);
//                $this->load->view('footer');
//            } else {
//
//                // user creation failed, this should never happen
//                $data->error = 'There was a problem creating your new account. Please try again.';
//
//                // send error to the view
//                $this->load->view('header');
//                $this->load->view('user/register/register', $data);
//                $this->load->view('footer');
//            }
//        }
//    }

    /**
     * login function.
     * 
     * @access public
     * @return void
     */
//    public function login() {
//
//        // create the data object
//        $data = new stdClass();
//
//        // load form helper and validation library
//        $this->load->helper('form');
//        $this->load->library('form_validation');
//
//        // set validation rules
//        $this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric');
//        $this->form_validation->set_rules('password', 'Password', 'required');
//
//        if ($this->form_validation->run() == false) {
//
//            // validation not ok, send validation errors to the view
//            $this->load->view('header');
//            $this->load->view('user/login/login');
//            $this->load->view('footer');
//        } else {
//
//            // set variables from the form
//            $username = $this->input->post('username');
//            $password = $this->input->post('password');
//
//            if ($this->user_model->resolve_user_login($username, $password)) {
//
//                $user_id = $this->user_model->get_user_id_from_username($username);
//                $user = $this->user_model->get_user($user_id);
//
//                // set session user datas
//                $_SESSION['user_id'] = (int) $user->id;
//                $_SESSION['username'] = (string) $user->username;
//                $_SESSION['logged_in'] = (bool) true;
//                $_SESSION['is_confirmed'] = (bool) $user->is_confirmed;
//                $_SESSION['is_admin'] = (bool) $user->is_admin;
//
//                // user login ok
//                $this->load->view('header');
//                $this->load->view('user/login/login_success', $data);
//                $this->load->view('footer');
//            } else {
//
//                // login failed
//                $data->error = 'Wrong username or password.';
//
//                // send error to the view
//                $this->load->view('header');
//                $this->load->view('user/login/login', $data);
//                $this->load->view('footer');
//            }
//        }
//    }

    /**
     * logout function.
     * 
     * @access public
     * @return void
     */
//    public function logout() {
//
//        // create the data object
//        $data = new stdClass();
//
//        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
//
//            // remove session datas
//            foreach ($_SESSION as $key => $value) {
//                unset($_SESSION[$key]);
//            }
//
//            // user logout ok
//            $this->load->view('header');
//            $this->load->view('user/logout/logout_success', $data);
//            $this->load->view('footer');
//        } else {
//
//            // there user was not logged in, we cannot logged him out,
//            // redirect him to site root
//            redirect('/');
//        }
//    }
}
