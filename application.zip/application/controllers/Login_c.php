<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_c extends CI_Controller {

    public function __construct() {

        parent::__construct();
           $this->load->model('ask_question_m');
    
        $this->load->model('researcher_m');
    }

    public function index() {
      $sql_gn = $this->db->query("set global sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'" );
            $sql_gn = $this->db->query("set session sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'" );

        if ($this->session->userdata('user_id') != '') {
             redirect('ask_questions');
            // if ($this->session->userdata('userType') == 1) {
               
            // } else {
            //     redirect('researcher');
            // }
        } else {
            
            //$this->load->view('common/header');
            $this->load->view('login_v');
            // $this->load->view('common/footer');
        }
    }

    public function terms() {
   
        $this->load->view('terms_view');
    }
     public function privacy() {   
        $this->load->view('privacy_view');
        
    }

    public function check_login() {
           
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('login_c');
        } else {
            $this->load->model('login_m');
            $user = $this->login_m->login_user($email, md5($password));
            // 
            if ($user) {
                $ses_tot = $user->sessions_total + 1;
                $this->login_m->add_session($user->id, $ses_tot);
               
                if ($this->input->post('remember_me')=='yes') {
                   setcookie("email", $email, time() + (86400 * 30*30), "/");
                   setcookie("password", $password, time() + (86400 * 30*30), "/");
                }else{

                    setcookie("email", "", time() - 3600,"/");
                    setcookie("password", "", time() - 3600,"/");

               
                }
                $this->session->set_userdata('email', $user->email);
                $this->session->set_userdata('pass', $user->password);
                $this->session->set_userdata('user_id', $user->id);
                $this->session->set_userdata('userType', $user->userType);
                $this->session->set_userdata('firstName', $user->firstName);
                $this->session->set_userdata('user_image', $user->user_image);
                $this->session->set_userdata('sokrates_permission', $user->sokrates_permission);
                $this->session->set_userdata('login_status', 'Y');
                  $this->session->set_flashdata('login_success', 'You are now logged in.');
                    redirect('ask_questions');
              
                // if ($user->userType == 1) {
                //     $this->session->set_flashdata('login_success', 'You are now logged in.');
                //     redirect('ask_questions');
                // } else {
                //     $user = $this->login_m->isLogged_user($user->id);
                //     redirect('researcher');
                // }
            } else {
                redirect('login_c');
            }
        }
    }
    public function execFunction(){
      $ques="what is love";
      
 $ansApiRes=$this->getAnswerApi($ques,$txtApiRes['content']);                    
                    $ansApiRes=json_decode($ansApiRes,true);

    //  set_time_limit(0); 
    //  sleep(600);
    // echo "dadas";
    //      $input['qid']=100;
    //       $input['tag']="Hello00";
    //      $input['createDate']=date("Y-m-d H:i:s");
    //      $this->db->insert('question_tag', $input);
   } 

    public function execRunFunction(){
         ini_set('display_errors', 1);
        $param = 2;
         $command = "php ".FCPATH."index.php Login_c execFunction $param > /dev/null &";
        exec($command);
        echo $command ;
   } 


    public function create_sokretsId()
    {

          $this->load->model('login_m');
        if (!empty($this->input->post())) {
            
           $input= array('firstName' =>$this->input->post('first_name') , 'lastName' =>$this->input->post('last_name'), 'email' =>$this->input->post('email'), 'password' => md5($this->input->post('password')), 'userType' =>1, 'country' =>$this->input->post('country'));
             $user = $this->login_m->createSokretsid($input);
             if ($user) {
                  $this->session->set_flashdata('register_success', 'You have successfully create sokrets id.');
                    redirect('login_c');
             }else{
                
                  $this->session->set_flashdata('register_error', 'You have failed create sokrets id.');
                    $this->load->view('create_sokrets_v');
             }

        }else{

            $str = file_get_contents(base_url().'assets/countries.json'); 
                $json = json_decode($str, true);
                $data['countries']= $json; 
                                        
              $this->load->view('create_sokrets_v',$data);
        }

       
    }


 public function answerFromApi($user_id){
            $questions=$this->ask_question_m->getQuestionforApi($user_id);
             $user= $this->ask_question_m->getUser($user_id);
            foreach ($questions as $key => $question) {
                 $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID'] );
                 $book_res= count($sql_gn->result_array());
                if ($book_res==0) {
                     $data = array('process_indicator' => "progress-36" );
            $responce = $this->researcher_m->update_indicator_process($question['questionID'], $data);
            if($user->questionAnswerSource=='B' OR $user->questionAnswerSource=='Both')
            {
                $bookShelfRes =$this->researcher_m->library_search($question['questionTitle'],'api',$user_id);
                    foreach ($bookShelfRes as $key1 => $bookShelf) {
                     if ($key1<10) {
                            $input=array();
                            $input['count']=$key1+1;
                            $input['content']=$bookShelf['url'];
                            $input['qid']=$question['questionID'];
                            $input['type']='bookshelf';
                            $input['txt_response']=$bookShelf['content'];
                            $input['status']='pending';
                            $input['created_at']=date("Y-m-d H:i:s");
                            $input['update_at']=date("Y-m-d H:i:s");  
                            $this->db->insert('question_search_result', $input);
                     }
                 }
            }
                    
            
            $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']);
            $previous_res= count($sql_gn->result_array());
            if ($user->questionAnswerSource=='B') {
                if ($previous_res==0) {
                   $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $user_id,
                    'answerBy' =>0,
                    'answer' => "I cannot find an answer in BookShelf.",
                    'progress_status' => 4,
                    'sourceURL' => '',
                    'replyType' => 'std_ans',
                    'isRead'=>0
                    ); 
                     $cur_q_id =$question['questionID'];
                 $data = array('process_indicator' => "progress-85","isCompleted"=>1 );
                 $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data); 
                    $answerid = $this->researcher_m->insert_researcher_answer($form_data);
                    $this->db->set('ans_accept', 'N');
                    $this->db->where('id', $question['questionID']); 
                    $this->db->update('questions');
                    break; 
                }
            }
           if($user->questionAnswerSource=='I' OR $user->questionAnswerSource=='Both')
            { 
            $addInternetRes=10-$previous_res; 
            $counter=$previous_res;
            if ($addInternetRes>0) {
                $accessKey = '379bfe6adde24750bfd9c2fe5ca49dc3';
                $endpoint = 'https://api.cognitive.microsoft.com/bing/v7.0/search';
                $res = $this->BingWebSearch($endpoint, $accessKey, $question['questionTitle']);
               $results=@$res->webPages->value;
                foreach ($results as $key_data => $result) {               
                      if ($addInternetRes>$key_data) {
                          $counter++;
                           $input=array();
                            $input['count']=$counter;
                            $input['content']=$result->url;
                            $input['qid']=$question['questionID'];
                            $input['type']='internet';
                            $input['status']='pending';
                            $input['created_at']=date("Y-m-d H:i:s");
                            $input['update_at']=date("Y-m-d H:i:s");                              
                            $this->db->insert('question_search_result', $input);
                      }

                }
            }

          }
        }

         $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']." AND status='pending'"  );
         $search_results= $sql_gn->result_array();
         foreach ($search_results as $search_key => $search_result) {

            $sql_gn = $this->db->query("SELECT * FROM question_search_result WHERE qid =".$question['questionID']." AND status='reject'"  );
                    $reject_res= $sql_gn->result_array();
                if (count($reject_res)==6) {
                    $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $user_id,
                    'answerBy' =>0,
                    'answer' => "I cannot find a good answer. Please reformulate your question and try again.",
                    'progress_status' => 4,
                    'sourceURL' => '',
                    'replyType' => 'std_ans',
                    'isRead'=>0
                    );  
                    $answerid = $this->researcher_m->insert_researcher_answer($form_data);
                    $this->db->set('ans_accept', 'N');
                    $this->db->where('id', $question['questionID']); 
                    $this->db->update('questions');
                    break; 
                }

                if ($search_result['type']=='bookshelf') {
                    $txtApiRes= array();
                      $txtApiRes['response']=1;
                      $txtApiRes['content']=$search_result['txt_response'];                     
                }else{
                     $txtApiRes=  $this->txtMakerApi($search_result['content']); 
                     $txtApiRes=json_decode($txtApiRes,true); 
                }
                    
             if ($txtApiRes['response']==-1 AND $txtApiRes['content']=='') {
                    $this->db->set('status', 'no_ans'); 
                    $this->db->where('id', $search_result['id']); 
                    $this->db->update('question_search_result'); 
                }else{ 
                  $answerurl="http://52.178.25.154:8004/predict";
                if ($user_id==13) {
                          $answerurl="http://35.187.61.190:8004/predict";  
                             }                       
                $ansApiRes=$this->getAnswerApi($question['questionTitle'],$txtApiRes['content'],$answerurl);                    
                    $ansApiRes=json_decode($ansApiRes,true);
                  
                if (empty($ansApiRes)) {
                    $this->db->set('status', 'no_ans'); 
                    $this->db->where('id', $search_result['id']); 
                    $this->db->update('question_search_result'); 

                }else{
                    $data = array('process_indicator' => "progress-60" );
                $responce = $this->researcher_m->update_indicator_process($question['questionID'], $data);
                $this ->db->where('questionID', $question['questionID']);
               $this ->db->delete('answer');
              $confidence_score=round(($ansApiRes[0]['probability']*100),1); 
                 $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $user_id,
                    'answerBy' =>0,
                    'answer' => $ansApiRes[0]['text'],
                    'progress_status' => 4,
                    'sourceURL' => $search_result['content'],
                    'replyType' => 'Answer',
                    'confidence_score'=>$confidence_score
                    );

            $this->db->set('answer', $ansApiRes[0]['text']); 
            $this->db->set('txt_response', $txtApiRes['content']); 
            $this->db->set('status', 'has_ans');
            $this->db->where('id', $search_result['id']); 
            $this->db->update('question_search_result');             
            $answerid = $this->researcher_m->insert_researcher_answer($form_data);
            $cur_q_id =$question['id'];
            $data = array('process_indicator' => "progress-85","isCompleted"=>1 );
            $responce = $this->researcher_m->update_indicator_process($cur_q_id, $data);
            break; 
                }
               
                }   

           
         }
         if (count($search_results)==0) {
               $form_data = array(
                    'questionID' => $question['questionID'],
                    'questionBy' => $user_id,
                    'answerBy' =>0,
                    'answer' => "I cannot find a good answer. Please reformulate your question and try again.",
                    'progress_status' => 4,
                    'sourceURL' => '',
                    'replyType' => 'std_ans',
                    'isRead'=>0
                    );  
                    $answerid = $this->researcher_m->insert_researcher_answer($form_data);
         }


     }
            
    }



     public function BingWebSearch($url, $key, $query) {
        /* Prepare the HTTP request.
         * NOTE: Use the key 'http' even if you are making an HTTPS request.
         * See: http://php.net/manual/en/function.stream-context-create.php.
         */
        $headers = "Ocp-Apim-Subscription-Key: $key\r\n";
        $options = array('http' => array(
                'header' => $headers,
                'method' => 'GET'));

        // Perform the request and get a JSON response.
        $context = stream_context_create($options);
        $result = file_get_contents($url . "?q=" . urlencode($query), false, $context);

        // Extract Bing HTTP headers.
        $headers = array();
        foreach ($http_response_header as $k => $v) {
            $h = explode(":", $v, 2);
            if (isset($h[1]))
                if (preg_match("/^BingAPIs-/", $h[0]) || preg_match("/^X-MSEdge-/", $h[0]))
                    $headers[trim($h[0])] = trim($h[1]);
        }

        //return array($headers, $result);
        return json_decode($result);
    }



      public function txtMakerApi($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://104.40.153.156:8002/webscrap/api/getresult");
        $payload = json_encode( array( "url"=> $url ) );      
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );

        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2100);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        if (empty($server_output)) {
           $server_output=json_encode(array('response' =>-1 , "content"=>""));
        }
        return $server_output;
    }


   public function getAnswerApi($question,$context,$answerurl)
   {
     // $dara='[{"probability":0.9612194686265066,"text":"Airplanes"},{"probability":0.02791164240670989,"text":"Igi airport"},{"probability":0.003283938142241936,"text":"Airplanes etc."},{"probability":0.0020482309636505195,"text":"Marine vessels, airplanes"},{"probability":0.0008846971205521158,"text":"I"},{"probability":0.0007969964649480403,"text":"Airport"},{"probability":0.0006310153649209266,"text":"Airplanes etc. )"},{"probability":0.0005824748117042068,"text":"Vessels, airplanes"},{"probability":0.00048486547608508006,"text":"Airplanes etc. ), waste disposal landfills, open burning etc."},{"probability":0.0004044977539120342,"text":"Mobile sources ( e.g. vehicular emission, marine vessels, airplanes"},{"probability":0.0003912499050642828,"text":"Jeep"},{"probability":0.0002865673816609498,"text":"Igi"},{"probability":0.00021785169850611222,"text":"Airplanes etc. ), waste disposal landfills, open burning etc. 3. air pollutants"},{"probability":0.00017299555218996905,"text":"Igi airport, it"},{"probability":0.00016042567759797348,"text":"Once"},{"probability":0.00013336643311969267,"text":"Cars and jeep"},{"probability":0.00010561669754323736,"text":"Anand viha r isbt, igi airport"},{"probability":0.00010188187784893857,"text":"Dwarka, igi airport"},{"probability":9.876147160547133e-05,"text":"Igi airport, it o"},{"probability":8.345617363179302e-05,"text":"N"}]';
     // return $dara;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $answerurl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, true);
        $data = array(
            'context' => $context,
            'question' => $question
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2100);
        $output = curl_exec($ch);
        $info = curl_getinfo($ch);
        $curl_errno = curl_errno($ch);
        $curl_error = curl_error($ch);
        curl_close($ch);
       if (empty($output)) {
         $output=array(); 
       }
        if ($curl_errno > 0) {
        echo "cURL Error ($curl_errno): $curl_error\n";
    }
       return $output;
       
   }



}
