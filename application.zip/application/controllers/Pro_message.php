<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pro_message extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('user_id') == '') {
            redirect("login_c");
        }

        $this->lastActivity();
        $this->load->model('pro_message_m');
    }

    private function lastActivity() {
        $time_since = strtotime(date('Y-m-d H:i:s')) - strtotime($this->session->userdata('lastActivity'));
        $interval = 300;
        // Do nothing if last activity is recent
        if ($time_since < $interval)
            return;

        // Update database
        $updated = $this->db
                ->set('lastActivity', date('Y-m-d H:i:s'))
                ->where('id', $this->session->userdata('user_id'))
                ->update('user');
    }

    public function index() {
        $data['pro_messages'] = $this->pro_message_m->get_pro_messages();
        $this->load->view('common/header');
        $this->load->view('progress_messages_v', $data);
        $this->load->view('common/footer');
    }

    public function update_pro_message() {
        $id = $this->input->post('id');
        $res = $this->pro_message_m->edit_pro_message($id, $_POST);
        if ($res) {
            $this->session->set_flashdata('success', 'Progress messag updated successfully');
            redirect('pro_message');
        } else {
            redirect('pro_message');
        }
    }
    
    public function get_progress_status() {
        $data['id'] = $this->session->userdata('user_id');
        $data['user_pro_data'] = $this->pro_message_m->get_user_pro_count($data);
        //print_r($data['user_pro_data']); exit;
        $this->load->view('footer_progress_v',$data);
    }
}
