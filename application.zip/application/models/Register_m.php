<?php

class Register_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function register_user($user) {
        $this->db->insert('user', $user);
        return TRUE;
    }

    public function emailcheck($email) {
        $this->db->where('email', $email);
        $r = $this->db->get('user');
        if ($r->num_rows() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function passcheck($pass, $id) {
        $this->db->where('id', $id);
        $this->db->where('password', $pass);
        $r = $this->db->get('user');
        if ($r->num_rows() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function change_password($user,$id) {
        $this->db->where('id', $id);
        return $this->db->update('user', $user);
    }
    
    public function check_forget_email($email) {
        $this->db->where('email', $email);
        $r = $this->db->get('user');
       // print_r($r->first_row()->id);  exit;
        if ($r->num_rows() > 0) {
            return $r->first_row();
        } else {
            return FALSE;
        }
    }
    
    public function get_profile($id) { //echo $id;  exit;
        $this->db->where('id', $id);
        $r = $this->db->get('user');
        if ($r->num_rows() > 0) {
            return $r->first_row();
        } else {
            return FALSE;
        }
    }
    
    public function profile_update($arr,$id) {
        $this->db->where('id', $id);
        return $this->db->update('user', $arr);
    }

    public function update_indicator_process($id,$arr){
         $this->db->where('id', $id);
        return $this->db->update('tbl_researcher_current_questions', $arr);
    }

}
