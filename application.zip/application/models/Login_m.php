<?php 
class Login_m extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }
    
    public function login_user($email,$password) {
        //print_r($email);    print_r($password); exit;
        $this->db->where('email',$email);
        $this->db->where('password',$password);
        $this->db->where('userType',1);
        $result = $this->db->get('user');
        
        if($result->num_rows() == 1) {
            //print_r($result->first_row());  exit;
            return $result->first_row();
        }
        else {
            $this->session->set_flashdata('error','Email or Password is incorrect');
            return false;
        }
    }

    public function login_researcher($email,$password) {
        //print_r($email);    print_r($password); exit;
        $this->db->where('email',$email);
        $this->db->where('userType',2);
        $this->db->where('password',$password);
        $result = $this->db->get('user');
        
        if($result->num_rows() == 1) {
            //print_r($result->first_row());  exit;
            return $result->first_row();
        }
        else {
            $this->session->set_flashdata('error','Email or Password is incorrect');
            return false;
        }
    }
    
//    public function last_activity($id) { 
//        //print_r($email);    print_r($password); exit;
//        $this->db->set('lastActivity',date('Y-m-d H:i:s'));
//        $this->db->where('id',$id);
//        $this->db->update('user');
//        
//    }
    
    public function add_session($id, $tot) { 
        $this->db->set('sessions_total',$tot);
        $this->db->where('id',$id);
        $this->db->update('user'); 
    }
     public function isLogged_user($id) { 
        $this->db->set('isLogged',1);
        $this->db->where('id',$id);
        $this->db->update('user'); 
    }
    public function isLogged_out($id) { 
        $this->db->set('isLogged',0);
        $this->db->where('id',$id);
        $this->db->update('user'); 
    }
    
     public function ckack_old_password($password,$id) {
        $this->db->where('id',$id);
        $this->db->where('password',$password);
        $result = $this->db->get('user');
        
        if($result->num_rows() == 1) {
            return $result->row(0)->id;
        }
        else {
            $this->session->set_flashdata('error','old password is incorrect');
            return false;
        }
     }

      public function createSokretsid($input) {
     return $this->db->insert('user', $input);
     }
}