<?php

class Pro_message_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function get_pro_messages() {

        $sql = $this->db->query("SELECT * FROM `tbl_progress_messages` WHERE isDeleted = 0");
        $res = $sql->result_array();
        return $res;
    }

    public function edit_pro_message($id, $array) {
        //print_r($array);  exit;
        $this->db->where('id', $id);
        $this->db->update('tbl_progress_messages', $array);
        return true;
    }
    
    public function get_user_pro_count($data) {       
        $sql = $this->db->query("select * from (select a.*, b.questionTitle, c.message from tbl_progress_status a, questions b, tbl_progress_messages c WHERE a.isDeleted = 0 and a.questionBy = '".$data['id']."' AND a.questionID = b.id AND a.progress_status = c.id order by questionID, progress_status desc) x group by `questionID`");
        $res = $sql->result_array();
        return $res;
    }

}
