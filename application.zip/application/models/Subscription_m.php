<?php

class Subscription_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function insert_files($ary) {
        $this->db->insert('tbl_files', $ary);
        return TRUE;
    }
    public function buy_plan($ary) {
        $this->db->insert('tbl_subscription', $ary);
        return TRUE;
    }
    
    public function get_plan() {
        $sql = $this->db->query("SELECT * FROM `tbl_subscription` WHERE isDeleted = 0");
        $res = $sql->result_array();
        return $res;
    }
    
    public function get_user($id) {
        //echo "SELECT * FROM `user` WHERE id = $id and isDeleted = 0";  exit;
        $sql = $this->db->query("SELECT * FROM `user` WHERE id = $id and isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }
    
    public function cur_plan($id) {
        $sql = $this->db->query("SELECT * FROM `tbl_subscription` WHERE id = $id and isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }
    
    public function update_plan($u_id,$plan_id) {
        $this->db->where('id', $u_id);
        $this->db->set('subscriptionID', $plan_id);
        return $this->db->update('user', $user);
    }
}
