<?php

class Standard_answers_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function get_st_ans_list() {

        $sql = $this->db->query("SELECT * FROM `tbl_standard_answers` WHERE isDeleted = 0");
        $res = $sql->result_array();
        return $res;
    }

    public function edit_s_ans($id, $array) {
        //print_r($array);  exit;
        $this->db->where('id', $id);
        $this->db->update('tbl_standard_answers', $array);
        return true;
    }
    
    public function delete_s_ans($id) {
        //print_r($array);  exit;
        $this->db->where('id', $id);
        $this->db->set('isDeleted', 1);
        $this->db->update('tbl_standard_answers', $array);
        return true;
    }
    
}
