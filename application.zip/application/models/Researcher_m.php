<?php

class Researcher_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
        $this->researcher_id = $this->session->userdata('user_id');
        $this->new_quwstion_point = 10;
    }

    public function get_researcher_q() {
        //a.id= 28 and SELECT * FROM `questions` WHERE id NOT IN(SELECT `questionID` FROM `tbl_researcher_current_questions` WHERE `isCompleted` = 1) AND isDeleted = 0
        //$sql = $this->db->query("SELECT a.*,b.id as questionBy, b.firstName, b.user_image, b.country, b.created, DATEDIFF(CURDATE(),STR_TO_DATE(b.created, '%Y-%m-%d')) AS days FROM `questions` a, `user` b WHERE a.isAssign = 0 AND a.userID = b.id ORDER BY RAND() LIMIT 1");
        $query=$this->db->query("SELECT * FROM tbl_mycomments WHERE answerBy='".$this->session->userdata('user_id')."' AND isRead=0 AND messageBy!= '".$this->session->userdata('user_id')."'");
        $result = $query->result_array();

        if (count($result)>=1) {
           
         $this->db->set('isRead', 1);
        $this->db->where('id', $result[0]['id']);
        $this->db->update('tbl_mycomments');
           $sql = $this->db->query("SELECT a.*,b.id as questionBy, b.firstName, b.user_image, b.country, b.created, DATEDIFF(CURDATE(),STR_TO_DATE(b.created, '%Y-%m-%d')) AS days FROM questions a, `user` b WHERE a.id='".$result[0]['questionID']."'  AND a.userID = b.id  LIMIT 1");
        $res = $sql->first_row();
        $res->new_que='false';
        }else{
             $sql = $this->db->query("SELECT a.*,b.id as questionBy, b.firstName, b.user_image, b.country, b.created, DATEDIFF(CURDATE(),STR_TO_DATE(b.created, '%Y-%m-%d')) AS days FROM questions a, `user` b WHERE a.isAssign = 0 AND a.isDeleted = 0 AND a.userID = b.id AND a.id NOT IN (SELECT questionID FROM answer )  ORDER BY a.id ASC LIMIT 1");

  
        $res = $sql->first_row();
        $res->new_que='true';
        }


           
       
        // $res = $sql->result_array();        
        return $res;
    }

    public function add_new_queation_point() {
        
        $this->db->set('researcher_points', 'researcher_points + ' . (int) $this->new_quwstion_point, FALSE);
        $this->db->where('id', $this->researcher_id);
        $this->db->update('user');
        return true;
        
//        $sql = $this->db->query("UPDATE `user` SET `researcher_points`= $this->new_quwstion_point WHERE `id` = $this->researcher_id");
//        return true;
    }

    public function get_researcher_detail() {
        $sql = $this->db->query("SELECT * FROM `user` WHERE id = $this->researcher_id");
        $res = $sql->first_row();
        return $res;
    }

    public function get_researcher_instructions($var) {
        $sql = $this->db->query("SELECT * FROM `tbl_instructions` WHERE instructionFor = '" . $var . "' AND isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }

    public function insert_researcher_comment($arr) {
        $this->db->insert('tbl_mycomments', $arr);
        $insert_id = $this->db->insert_id();
        $this->db->where('questionBy', $arr['questionBy']);
        $this->db->where('questionID', $arr['questionID']);
        $this->db->set('commentId', $insert_id);
        $this->db->update('tbl_researcher_current_questions');
        return true;
    }

    public function insert_researcher_answer($arr) {
        $this->db->insert('answer', $arr);
        $insert_id = $this->db->insert_id();
        $this->db->where('questionBy', $arr['questionBy']);
        $this->db->where('questionID', $arr['questionID']);
        $this->db->set('isCompleted', 1);
        $this->db->set('answerId', $insert_id);
        $this->db->update('tbl_researcher_current_questions');
        return $insert_id;
    }
    
    public function insert_researcher_answer_wait($arr) {
       
        $this->db->where('questionBy', $arr['questionBy']);
        $this->db->where('questionID', $arr['questionID']);
        $this->db->set('isCompleted', 1);
        $this->db->update('tbl_researcher_current_questions');
        return true;
    }

    public function add_current_queation($data) {
        $this->db->insert('tbl_researcher_current_questions', $data);
        return $insert_id = $this->db->insert_id();        
    }

    public function get_current_queation() {
        $sql_cur = $this->db->query("SELECT a.*, b.questionTitle,c.firstName, c.country, c.user_image, DATEDIFF(CURDATE(),STR_TO_DATE(c.created, '%Y-%m-%d')) AS days FROM tbl_researcher_current_questions a, questions b, user c WHERE a.isCompleted = 0 AND a.questionID = b.id AND a.answerBy = $this->researcher_id and a.questionBy=c.id ORDER BY `a`.`answerBy` DESC LIMIT 1");
        return  $sql_cur->first_row();
    }
    public function get_comments($q_id) {       
        //$sql_cur = $this->db->query("SELECT * FROM `answer` WHERE questionID = $q_id AND replyType = 'Comment' ORDER BY id ASC");
        $sql_cur = $this->db->query("SELECT * FROM tbl_mycomments WHERE questionID = $q_id AND answerBy = $this->researcher_id ORDER BY id desc ");
        return  $sql_cur->result_array();
    }

    public function update_indicator_process($cur_q_id, $data){ 
        $this->db->where('id', $cur_q_id);
        $this->db->update('tbl_researcher_current_questions', $data);
       
        return true;
    }
    
    public function update_stopwatch($id, $data){ 
        $this->db->where('id', $id);
        $this->db->update('tbl_researcher_current_questions', $data);
        return true;
    }
    
    public function get_researcher_data() {        
        $sql_u = $this->db->query("SELECT a.answerBy as researcherId, SEC_TO_TIME( SUM( TIME_TO_SEC( a.totalTime) ) ) AS timeSum, AVG( TIME_TO_SEC( a.totalTime)) AS timeAvg, b.firstName, b.sessions_total, b.researcher_points, b.user_image FROM tbl_researcher_current_questions a, user b WHERE a.answerBy = $this->researcher_id AND a.isCompleted = 1 AND a.answerBy = b.id");
        return  $sql_u->first_row();
    }
    
    public function get_standard_ans($for){ 
        $sql = $this->db->query("SELECT * FROM `tbl_standard_answers` WHERE isDeleted = 0 and AnswerFor = '".$for."' ");
        $res = $sql->result_array();
        return $res;
    }
    
    public function get_researcher_res($data){ 
        $sql = $this->db->query("SELECT * FROM `tbl_mycomments` WHERE questionBy = '".$data['questionBy']."' AND answerBy = '".$data['answerBy']."' AND questionID = '".$data['questionID']."'  AND isDeleted = 0 ORDER BY id desc" );
        $res = $sql->result_array();
        return $res;
    }
    
    public function get_question_user($id){ 
        $sql = $this->db->query("SELECT * FROM `user` WHERE id = '".$id."' AND isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }
    public function get_question($id){ 
        $sql = $this->db->query("SELECT * FROM `questions` WHERE id = '".$id."' AND isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }

     public function get_tempory_question($id){ 
        $sql = $this->db->query("SELECT * FROM `tbl_researcher_current_questions` WHERE id = ".$id );
        $res = $sql->first_row();
        return $res;
    }

    public function get_unread_count($data){ 
        $sql = $this->db->query("SELECT * FROM `tbl_mycomments` WHERE questionBy = '".$data['questionBy']."' AND answerBy = '".$data['answerBy']."' AND questionID = '".$data['questionID']."' AND messageBy='".$this->session->userdata('user_id')."'  AND isDeleted = 0 AND isRead = 0"  );
        $res = $sql->result_array();
        return $res;
    }


      public function update_read_status($data){ 
        // $sql = $this->db->query("UPDATE tbl_mycomments SET isRead = 1 WHERE questionBy = '".$data['questionBy']."' AND answerBy = '".$data['answerBy']."' AND questionID = '".$data['questionID']."' AND messageBy!='".$this->session->userdata('user_id')."' "  );
         $newdata= array('isRead' => 1 );
       $this->db->where('questionBy', $data['questionBy']);
       $this->db->where('answerBy', $data['answerBy']);
       $this->db->where('questionID', $data['questionID']);
       $this->db->where('messageBy', $data['questionBy']);
       $this->db->update('tbl_mycomments', $newdata);
      
        return true;
    }

    public function  library_search($var,$type,$user_id) {
$var=trim($var);
$searchString= strtolower($var);
$searchString = str_replace("'", '', $searchString);
        $stopwords= "a able about above abroad according accordingly across actually adj after afterwards again against ago ahead ain't all allow allows almost alone along alongside already also although always am amid amidst among amongst an and another any anybody anyhow anyone anything anyway anyways anywhere apart appear appreciate appropriate are aren't around as a's aside ask asking associated at available away awfully b back backward backwards be became because become becomes becoming been before beforehand begin behind being believe below beside besides best better between beyond both brief but by c came can cannot cant can't caption cause causes certain certainly changes clearly c'mon co co. com come comes concerning consequently consider considering contain containing contains corresponding could couldn't course c's currently d dare daren't definitely described despite did didn't different directly do does doesn't doing done don't down downwards during e each edu eg eight eighty either else elsewhere end ending enough entirely especially et etc even ever evermore every everybody everyone everything everywhere ex exactly example except f fairly far farther few fewer fifth first five followed following follows for forever former formerly forth forward found four from further furthermore g get gets getting given gives go goes going gone got gotten greetings h had hadn't half happens hardly has hasn't have haven't having he he'd he'll hello help hence her here hereafter hereby herein here's hereupon hers herself he's hi him himself his hither hopefully how howbeit however hundred i i'd ie if ignored i'll i'm immediate in inasmuch inc inc. indeed indicate indicated indicates inner inside insofar instead into inward is isn't it it'd it'll its it's itself i've j just k keep keeps kept know known knows l last lately later latter latterly least less lest let let's like liked likely likewise little look looking looks low lower ltd m made mainly make makes many may maybe mayn't me mean meantime meanwhile merely might mightn't mine minus miss more moreover most mostly mr mrs much must mustn't my myself n name namely nd near nearly necessary need needn't needs neither never neverf neverless nevertheless new next nine ninety no nobody non none nonetheless noone no-one nor normally not nothing notwithstanding novel now nowhere o obviously of off often oh ok okay old on once one ones one's only onto opposite or other others otherwise ought oughtn't our ours ourselves out outside over overall own p particular particularly past per perhaps placed please plus possible presumably probably provided provides q que quite qv r rather rd re really reasonably recent recently regarding regardless regards relatively respectively right round s said same saw say saying says second secondly see seeing seem seemed seeming seems seen self selves sensible sent serious seriously seven several shall shan't she she'd she'll she's should shouldn't since six so some somebody someday somehow someone something sometime sometimes somewhat somewhere soon sorry specified specify specifying still sub such sup sure t take taken taking tell tends th than thank thanks thanx that that'll thats that's that've the their theirs them themselves then thence there thereafter thereby there'd therefore therein there'll there're theres there's thereupon there've these they they'd they'll they're they've thing things think third thirty this thorough thoroughly those though three through throughout thru thus till to together too took toward towards tried tries truly try trying t's twice two u un under underneath undoing unfortunately unless unlike unlikely until unto up upon upwards us use used useful uses using usually v value various versus very via viz vs w want wants was wasn't way we we'd welcome well we'll went were we're weren't we've what whatever what'll what's what've when whence whenever where whereafter whereas whereby wherein where's whereupon wherever whether which whichever while whilst whither who who'd whoever whole who'll whom whomever who's whose why will willing wish with within without wonder won't would wouldn't x y yes yet you you'd you'll your you're yours yourself yourselves you've z zero Why index";

$searchString= preg_replace("/\.$/","",$searchString);
$searchString= preg_replace("/\?$/","",$searchString);
        $stopwords =explode(" ", $stopwords);

         $searchString=  preg_replace('/\b('.implode('|',$stopwords).')\b/','',$searchString); 
       $searchString=  trim($searchString);
       $search_array= explode(" ", $searchString);
      
       $str='';
        $count=count($search_array);
       foreach ($search_array as $key => $value) {
        if ($count==$key+1) {
            if ($value!='') {
              $str.="content like '% ".$value." %' ";
            }
         
        }else{
if ($value!='') {
   $str.="content like '% ".$value." %' OR ";
}
         
        }
       }
        $str=rtrim($str, 'OR');
        if ($type=='api') {
           $sql = $this->db->query("SELECT * FROM `tbl_files` WHERE user_id=".$user_id ." AND (".  $str.")");
        }else{
            $sql = $this->db->query("SELECT * FROM `tbl_files` WHERE ".  $str);
        }
     
        $res = $sql->result_array();
        return $res;
    }


     public function sendMail($user,$qid,$aid,$question)
    {
      $to = $user->email;
            //$to = 'ilt.hardikpatel@gmail.com';
            $subject = 'Sokrates You have received an answer to your question.';
            $from = 'no-reply@sokrets.com';
            // To send HTML mail, the Content-type header must be set
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            // Create email headers
             $headers .= 'From: ' . $from . "\r\n" .
                    'Reply-To: ' . $from . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();

        $message='';
        $message.="<p>Hi ".$user->firstName.", You have received an answer to your question:</p>";
        $message.="<p style='color:red;'>".$question."</p>";
        $message.="<a href='http://cmldemo.com/new_sokrets/ask_questions/question_answer/".$qid."/".$aid."'>(click to see the answer)</a> <br>";
        $message.="<img src='http://cmldemo.com/new_sokrets/assets/images//login-logo.png' style='width:9%; display: block;max-width: 100%;height: auto;'>"; 
        mail($to, $subject, $message, $headers);
        
    }


    public function deleteNotifyComments($arr){

    $this->db->where('answerBy', $arr->answerBy);
    $this->db->where('questionID', $arr->questionID);
    $this->db->where('is_final', 1);
    $this ->db->delete('tbl_mycomments');

    }

    public function deleteQuestion($qid){
        $this->db->where('questionID', $qid);
        $this->db->delete('answer');
        $this->db->where('questionID', $qid);
        $this->db->delete('tbl_researcher_current_questions');
        $this->db->where('id', $qid);
        $this->db->delete('questions');
    }

    
    
}
