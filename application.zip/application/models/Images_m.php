<?php

class Images_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function insert_file($data) {
        
        $this->db->insert('tbl_files', $data);
        return TRUE;
    }

}
