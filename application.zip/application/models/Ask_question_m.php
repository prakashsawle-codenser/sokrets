<?php

class Ask_question_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function question_insert($ary,$user) {
        $ary['answer_source']=$user->answerSource;
        $this->db->insert('questions', $ary);
        $insert_id = $this->db->insert_id();
        //$ary1['questionID'] = $insert_id;
        //$ary1['questionBy'] = $ary['userID'];
        //$this->db->insert('tbl_progress_status', $ary1);
        return $insert_id;
    }
    public function  addQuestion_current($input,$user,$qid){

         $ary['questionBy']=$user->id;
         $ary['answerBy']=0;
         $ary['questionID']=$qid;
         $ary['answerId']=0;
         $ary['start_time']=date("Y-m-d H:i:s");
         $ary['process_indicator']="progress-12";
         
         
        $this->db->insert('tbl_researcher_current_questions', $ary);
        $insert_id = $this->db->insert_id();
    }

//    public function last_activity($id) {
//        //print_r($ary); exit;
//        //$this->load->database();
//        $this->db->where('id', $id);
//        $this->db->set('lastActivity', date('Y-m-d H:i:s'));
//        $this->db->update('user');
//        return TRUE;
//    }

    public function get_home_data($id) {
        //$sql_q = "SELECT a.questionID, a.questionBy, a.answerBy, a.answer, a.sourceURL, b.questionTitle, b.sources, b.followUpQuestionsID FROM answer a, questions b WHERE a.isDeleted = 0 AND a.questionBy = 2 AND a.replyType = 'Answer' AND a.questionID = b.id GROUP BY a.answerBy, a.questionID ORDER BY a.id";
        $sql = $this->db->query("SELECT a.id as answer_id, a.questionID, a.questionBy, a.answerBy, a.answer, a.sourceURL, b.questionTitle, b.sources, b.followUpQuestionsID FROM answer a, questions b WHERE a.isDeleted = 0 AND a.isRead = 0 AND a.questionBy = $id AND a.replyType = 'Answer' AND a.questionID = b.id ORDER BY a.id DESC");
        //$sql = $this->db->query("SELECT a.id AS answer_id, a.answer, b.id AS question_id, b.questionTitle, b.sources FROM answer a, questions b WHERE a.questionID = b.id and a.replyType = 'Answer' and a.questionBy = $id ORDER BY a.id DESC LIMIT 5");
        $res = $sql->result_array();
        return $res;
    }

//                                    a.replyType = 'Answer' AND 
//                                    a.progress_status = 1 AND 
    public function get_home_data_model($data) {
        // echo $sql_q = "SELECT a.id as answer_id, a.questionID, a.questionBy, a.answerBy, a.answer, a.sourceURL, b.questionTitle, b.sources, b.followUpQuestionsID FROM answer a, questions b WHERE a.isDeleted = 0 AND a.isRead = 0 AND a.questionBy = $id AND a.replyType = 'Answer' AND a.questionID = b.id ORDER BY a.id DESC";
        $id = $data['id'];
        $sort_date = $data['sort_date'];
        $sort_abc = $data['sort_abc'];
        $ser = $data['ser'];
        $order = "";

        $whr = "";
        if ($sort_date != "") {
            $order = "ORDER BY b.created $sort_date";
        } else if ($sort_abc != "") {
            $order = "ORDER BY b.questionTitle $sort_abc";
        } else if ($ser != "") {
            $whr = "AND (b.questionTitle like '%$ser%' OR a.answer like '%$ser%') ";
        }

        $sql = $this->db->query("SELECT 
                                    a.id as answer_id, 
                                    b.id as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer, 
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.created,
                                    b.followUpQuestionsID,
                                    b.answer_source,
                                    b.ans_accept ,
                                    a.replyType 
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 AND 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 0 AND 
                                    a.questionBy = $id AND 
                                    a.questionID = b.id 
                                $whr                                
                                $order
                                ");
        $res = $sql->result_array();
        return $res;
    }

    public function get_questions($id) {

        if ($this->session->userdata('userType') == 2) {
            $whr = "";
        } else {
            $whr = "AND a.userID = $id";
        }
        //echo "SELECT a.*, b.firstName FROM questions a, user b WHERE a.isDeleted = 0 $whr AND a.userID = b.id ORDER BY a.id DESC"; exit;
        $sql = $this->db->query("SELECT a.*, b.id as questionBy, b.firstName FROM questions a, user b WHERE a.isDeleted = 0 $whr AND a.userID = b.id ORDER BY a.id DESC");

        $res = $sql->result_array();

        return $res;
    }

    public function get_questions_ans($data) {
        $id = $data['id'];
        $sort_date = $data['sort_date'];
        $sort_abc = $data['sort_abc'];
        $ser = $data['ser'];
        $order = "";

        $whr = "";
        if ($sort_date != "") {
            $order = "ORDER BY b.created $sort_date";
        } else if ($sort_abc != "") {
            $order = "ORDER BY b.questionTitle $sort_abc";
        } else if ($ser != "") {
            $whr = "AND (b.questionTitle like '%$ser%' OR a.answer like '%$ser%') ";
        }

        $sql = $this->db->query("SELECT 
                                    a.id as answer_id,
                                    a.questionID as question_id, 
                                    a.questionBy, 
                                    a.answerBy, 
                                    a.answer,
                                    b.created,
                                    a.sourceURL, 
                                    b.questionTitle, 
                                    b.sources, 
                                    b.followUpQuestionsID 
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    b.isDeleted = 0 AND 
                                    a.isRead = 1 AND 
                                    a.questionBy = $id 
                                AND 
                                    a.questionID = b.id 
                                $whr                                
                                $order
                                ");

        $res = $sql->result_array();
//        foreach ($res as $q){
//            $key = array($q['created']);
//            
//        }

        return $res;
    }

    public function get_question_data($q_id) {
        //echo 'SELECT a.*, b.firstName FROM `questions` a INNER JOIN `user` b ON a.userID = ' . $id . ' AND a.userID = b.id and a.id = ' . $q_id . ' order by a.id desc';

        $sql = $this->db->query('SELECT a.*, b.firstName FROM `questions` a, `user` b WHERE a.id = ' . $q_id . ' AND a.userID = b.id order by a.id desc');

        $res = $sql->first_row();

        return $res;
    }

    public function get_answers($id) {

        $sql = $this->db->query("SELECT a.*,b.firstName FROM `answer` a, `user` b WHERE a.isDeleted = 0 AND a.questionID =  $id  and a.answerBy = b.id order by a.id asc");
        $res = $sql->result_array();
        return $res;
    }

    public function get_answers_count($id) {
        //echo 'SELECT a.*, b.firstName FROM `questions` a INNER JOIN `user` b ON a.userID = ' . $id . ' AND a.userID = b.id and a.id = '.$q_id.' order by a.id desc';
        $sql = $this->db->query('SELECT * FROM `answer` where questionID = ' . $id . ' and answerBy != "" and isDeleted = 0');

        $res = $sql->num_rows();

        return $res;
    }

    public function get_search_answers($id, $ser) {
        //$this->load->database();
        //echo "SELECT a.*,b.firstName FROM `answer` a, `user` b WHERE a.isDeleted = 0 AND a.questionID = $id  and a.answerBy = b.id and a.answer LIKE '%$ser%' order by a.id desc";
        $sql = $this->db->query("SELECT a.*,b.firstName FROM `answer` a, `user` b WHERE a.isDeleted = 0 AND a.questionID =  $id  and a.answerBy = b.id and a.answer LIKE '%$ser%' order by a.id desc ");


        $res = $sql->result_array();

        return $res;
    }

    public function get_serch_questions($id, $ser) {
        if ($this->session->userdata('userType') == 2) {
            $whr = "";
        } else {
            $whr = "AND a.userID = $id";
        }
        //$this->load->database();
        // echo "SELECT a.*, b.firstName FROM `questions` a INNER JOIN `user` b ON a.userID = '$id' AND a.userID = b.id AND a.questionTitle LIKE '%$ser%' order by a.id desc";
        $sql = $this->db->query("SELECT a.*, b.id as questionBy, b.firstName FROM questions a, user b WHERE a.isDeleted = 0 $whr AND a.userID = b.id AND a.questionTitle LIKE '%$ser%' order by a.id desc ");


        $res = $sql->result_array();

        return $res;
    }

    public function reply_insert($ary) {

        $this->db->insert('tbl_answer_reply', $ary);
        return TRUE;
    }

    public function answer_insert($ary) {
        //print_r($ary); exit;
        //$this->load->database();
        $this->db->insert('answer', $ary);
        return TRUE;
    }

    public function get_user_and_question($q_id) {
        $sql = $this->db->query("SELECT a.userID, a.questionTitle, b.firstName, b.email FROM questions a, user b WHERE a.userID = b.id and a.id = $q_id AND a.isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }

    public function get_question_row($q_id) {
        $sql = $this->db->query("SELECT * FROM `questions` WHERE id = $q_id and isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }

    public function post_comment($ary) {

        $this->db->insert('answer', $ary);
        return TRUE;
    }

    public function get_question_ans($qid, $aBy) {

        $this->db->where('questionID', $qid);
        $this->db->where('answerBy', $aBy);
        $result = $this->db->get('answer');
        if ($result->num_rows() == 1) {

            return true;
        } else {

            return false;
        }
    }

    public function p_status_insert($ary) {

        $this->db->insert('tbl_progress_status', $ary);
        return TRUE;
    }

    public function p_status_dateto($id, $date) {

        $this->db->where('id', $id);
        $this->db->set('DateTimeTo', $date);
        $this->db->update('tbl_progress_status');
        return true;
    }

    public function p_status_update($qid, $qBy, $aBy, $array) {
        //print_r($array);  exit;
        $this->db->where('questionID', $qid);
        $this->db->where('answerBy', $aBy);
        $this->db->where('questionBy', $qBy);
        $this->db->update('answer', $array);
        return true;
    }

    public function get_q_user($id) {
        //echo 'SELECT a.questionBy, b.id, b.firstName, b.email, a.progress_status FROM answer a, user b WHERE a.questionBy = $id AND a.questionBy = b.id';  exit;
        $sql = $this->db->query("SELECT a.questionBy, b.id, b.firstName, b.email, a.progress_status FROM answer a, user b WHERE a.questionBy = $id AND a.questionBy = b.id");
        $res = $sql->first_row();
        return $res;
    }

    public function get_p_status($id) {
        $sql = $this->db->query("SELECT * FROM tbl_progress_messages WHERE id = $id AND isDeleted = 0");
        $res = $sql->first_row();
        return $res;
    }

    public function get_user_pro_status($q_id, $id) {
        $sql = $this->db->query("SELECT MAX(progress_status) AS progress_status FROM tbl_progress_status WHERE questionID = $q_id AND answerBy = $id");
        $res = $sql->first_row();
        return $res;
    }

    public function check_p_status($q_id, $id, $progress_status) {
        $sql = $this->db->query("SELECT progress_status FROM tbl_progress_status WHERE questionID = $q_id AND answerBy = $id and progress_status = $progress_status");
        $res = $sql->first_row();
        return $res;
    }

    public function get_last_status($q_id, $id, $progress_status) {
        $sql = $this->db->query("SELECT  max(DateTime) as DateTime, max(id) as id  FROM tbl_progress_status WHERE questionID = $q_id AND answerBy = $id ");
        $res = $sql->first_row();
        return $res;
    }

    public function get_researcher() {
        if (@$this->input->post('ser') != "") {
            $ser = $this->input->post('ser');
            $whr = "and firstName LIKE '%$ser%' or email LIKE '%$ser%'";
        } else {
            $whr = "";
        }
        $sql = $this->db->query("SELECT * FROM user WHERE userType = 2 AND isDeleted = 0 $whr order by firstName ASC");
        $res = $sql->result_array();
        return $res;
    }

    public function transfer_other_researcher($ary) {
        $this->db->insert('tbl_question_assign', $ary);
        return true;
    }

    public function read_questions($uid) {
        //print_r($array);  exit;
        $this->db->where('userID', $uid);
        $this->db->set('isRead', 1);
        $this->db->update('questions');
        return true;
    }

    public function insert_follow_up_questions($data,$user) {
        $data['answer_source']=$user->answerSource;
        $this->db->insert('questions', $data);
         $insert_id = $this->db->insert_id();
        return $insert_id;
        
    }

    public function get_que_ans($id, $q_id, $a_id) {
        //echo "SELECT a.id as question_id, a.questionTitle, a.created,b.id as answer_id, b.answer, b.sourceURL FROM questions a,answer b WHERE a.id = $q_id and b.id = $a_id AND a.isDeleted = 0"; exit;
        $sql = $this->db->query("SELECT a.id as question_id, a.questionTitle, a.created,b.id as answer_id, b.answer, b.sourceURL, a.answer_source, a.ans_accept,b.replyType,b.confidence_score FROM questions a INNER JOIN  answer b on a.id=b.questionID  WHERE a.id = $q_id and b.id = $a_id AND a.isDeleted = 0");
        $res = $sql->result_array();
        return $res;
    }


     public function getall_que_ans($id) {
        //echo "SELECT a.id as question_id, a.questionTitle, a.created,b.id as answer_id, b.answer, b.sourceURL FROM questions a,answer b WHERE a.id = $q_id and b.id = $a_id AND a.isDeleted = 0"; exit;
        $sql = $this->db->query("SELECT a.id as question_id, a.questionTitle, a.created,b.id as answer_id, b.answer, b.sourceURL, a.answer_source, a.ans_accept,b.replyType,b.confidence_score FROM  questions a INNER JOIN  answer b on a.id=b.questionID  WHERE b.isRead=0 AND a.userID=$id AND a.isDeleted = 0");
        $res = $sql->result_array();
        return $res;
    }

    public function updateReadAns($a_id) {
        $this->db->where('id', $a_id);
        $this->db->set('isRead', 1);
        $this->db->update('answer');
        return true;
    }
    
     public function updatefollowReadAns($id) {
        //echo "UPDATE `answer` SET `isRead`= 1 where `questionID` IN($id) "; exit;
        $sql = $this->db->query("UPDATE `answer` SET `isRead`= 1 where `id` IN($id) ");
        return true;
    }
    
    public function getFollowup($id){
        //echo "SELECT id FROM `questions` WHERE followUpQuestionsID =  '".$id."' and isDeleted = 0 "; exit;
        $sql = $this->db->query("SELECT GROUP_CONCAT(id)id FROM answer WHERE questionID IN (SELECT id FROM questions WHERE followUpQuestionsID = (SELECT questionID FROM `answer` WHERE id = '".$id."' AND isDeleted = 0)) ");
        $res = $sql->first_row();
        return $res;
    }

    public function updateProcess($id) {
        $this->db->where('id', $id);
        $this->db->set('isCompleted', 1);
        $this->db->update('tbl_researcher_current_questions');
        return true;
    }

    public function updateAnswerStatus($id) {
        $this->db->where('id', $id);
        $this->db->set('progress_status', 1);
        $this->db->update('answer');
        return true;
    }

    public function get_ans_count($uid) {
        //echo "SELECT count(*) as ans_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa";  exit;
        //$sql = $this->db->query("SELECT count(*) as ans_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa");

        $sql = $this->db->query("SELECT 
                                    count(*) as ans_count 
                                FROM 
                                    answer a, 
                                    questions b 
                                WHERE 
                                    a.isDeleted = 0 
                                AND 
                                    a.isRead = 0 
                                AND 
                                    a.questionBy = $uid                                
                                AND 
                                    a.questionID = b.id 
                                ORDER BY 
                                    a.id 
                                DESC");

        $res = $sql->first_row();
        return $res;
    }

    public function get_progress_count($uid) {
        // $sql = $this->db->query("SELECT count(*) as progress_count FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = $uid AND a.isDeleted = 0 ORDER BY a.id DESC");
        //echo "SELECT count(*) as progress_count FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID WHERE a.userID = '".$uid."' AND (b.isCompleted IS NULL OR b.isCompleted = 0) AND a.isDeleted = 0 ORDER BY a.id DESC "; exit;
        $sql = $this->db->query("SELECT count(*) as progress_count FROM questions a LEFT JOIN tbl_researcher_current_questions b ON a.id = b.questionID LEFT JOIN answer ON a.id=answer.questionID WHERE a.userID = $uid AND (answer.isRead=0 OR answer.isRead IS NULL ) AND a.isDeleted = 0 ORDER BY a.id DESC ");

        // $sql = $this->db->query("SELECT count(*) as ans_count FROM (SELECT * FROM `answer` WHERE isDeleted = 0 and isRead = 0 AND questionBy = $uid AND replyType = 'Answer' ORDER BY id) as aaa");
        $res = $sql->first_row();
        return $res;
    }

    public function get_dialogue($uid, $q_id) {
        $sql = $this->db->query("SELECT a.*,b.questionTitle FROM `answer` a, questions b WHERE a.questionBy = $uid and a.questionID = $q_id AND a.replyType != 'Answer' AND a.questionID = b.id ORDER BY id DESC");
        $res = $sql->result_array();
        return $res;
    }

    public function get_comment($uid) {
        //$sql = $this->db->query("SELECT a.questionID,a.questionBy,a.answerBy,a.messageBy,a.comment,b.questionTitle FROM tbl_mycomments a, questions b WHERE a.id = '".$comment_id."' AND a.questionID = b.id");        
        $sql = $this->db->query("SELECT a.*,b.questionTitle FROM tbl_mycomments a, questions b WHERE a.questionBy = $uid AND a.messageBy != $uid AND a.isRead = 0 AND a.questionID = b.id AND a.isDeleted = 0 AND a.is_final = 0 group by a.questionID");
        $res = $sql->result_array();
        return $res;
    }

    public function get_process_comment($uid, $q_id, $a_by) {
        //$sql = $this->db->query("SELECT a.*,b.questionTitle FROM tbl_mycomments a, questions b WHERE a.questionID = $q_id AND a.questionBy = $uid AND a.messageBy != $uid AND a.answerBy = $a_by AND a.isRead = 0 AND a.questionID = b.id AND a.isDeleted = 0 group by a.questionID");
      $sql = $this->db->query("SELECT a.*,b.questionTitle FROM tbl_mycomments a, questions b WHERE a.questionID = $q_id AND a.questionBy = $uid  AND a.answerBy = $a_by AND  a.questionID = b.id AND a.isDeleted = 0 group by a.questionID");
        $res = $sql->result_array();
        // echo $this->db->last_query(); die;
        return $res;
    }

    public function submitUserComment($data) {
        $this->db->insert('tbl_mycomments', $data);

        $this->db->where('questionID', $data['questionID']);
        $this->db->where('questionBy', $data['questionBy']);
        $this->db->where('answerBy', $data['answerBy']);
        $this->db->where('messageBy', $data['answerBy']);
        $this->db->set('isRead', 1);
        $this->db->update('tbl_mycomments');

        return true;
    }

    public function delete_question($qestionid) {

        $this->db->where('id', $qestionid);
        $this->db->set('isDeleted', 1);
        $this->db->update('questions');
        return true;
    }

//    public function updateAcceptAnswer(){
//        $this->db->where('id', $qestionid);
//        $this->db->set('accept_user', 1);
//        $this->db->update('answer');
//        return true;
//    }

    public function get_u_cmnt_cnt($uid) {
        $sql_gn = $this->db->query("SELECT count(*) AS comment_count FROM(SELECT * FROM tbl_mycomments WHERE questionBy = '" . $uid . "' AND messageBy != '" . $uid . "' AND isRead = 0 AND isDeleted = 0 GROUP BY questionID) AS aaa");
        return $sql_gn->first_row();
    }

    public function updatePermission($id, $per) {
        $this->db->where('id', $id);
        $this->db->set('sokrates_permission', $per);
        $this->db->update('user');
        return true;
    }

    public function getUser($id) {
        $sql_gn = $this->db->query("SELECT * FROM `user` where id = '" . $id . "' ");
        return $sql_gn->first_row();
    }

    public function addquestiontag($input)
    {
        $arr['qid']=$input['qid'];
        $arr['tag']=$input['tag'];
         $arr['createDate']=date('Y-m-d H:i:s');
       $this->db->insert('question_tag', $arr);
        return true;  
    }

    public  function getQuestionTag($input)
    {
         $sql_gn = $this->db->query("SELECT * FROM question_tag WHERE qid=".$input['qid']);
        return $sql_gn->result_array();
    }
    public function removequestiontag($input)
    {
         $sql_gn = $this->db->query("DELETE FROM question_tag WHERE id =".$input['id']);
         return  $sql_gn;
    }

       
    public function updateAnswerSource($input)
    {
        $this->db->where('id', $this->session->userdata('user_id'));
        $this->db->set($input);
        $this->db->update('user');
        return true;
      
    }
    public function getQuestionforApi($user_id){
         $sql_gn = $this->db->query("SELECT * FROM questions INNER JOIN tbl_researcher_current_questions ON questions.id=tbl_researcher_current_questions.questionID WHERE questions.userID=".$user_id." AND questions.answer_source='A' AND tbl_researcher_current_questions.isCompleted=0");
        return $sql_gn->result_array();
    }
      

}
