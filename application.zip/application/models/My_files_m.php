<?php

class My_files_m extends CI_Model {

    public function __construct() {
        parent::__construct();
        //$this->load->database();
    }

    public function insert_files($ary) {
        //print_r($ary); exit;
        //$this->load->database();


        $this->db->insert('tbl_files', $ary);
        return TRUE;
    }

    public function delete_files($id, $f_name) {
        $this->db->where('user_id', $id);
        $this->db->where('file_name', $f_name);
        $this->db->delete('tbl_files');
//        $sql = $this->db->query("DELETE FROM `tbl_files` WHERE user_id = $id  and file_name = ".$f_name." ");
//        return true;
    }

    public function get_files_count($id) {

        $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id = $id  and isDeleted = 0");
        $res = $sql->num_rows();
        return $res;
    }

    public function get_files($id) {

        $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id =  $id  and isDeleted = 0 order by id desc ");
        $res = $sql->result_array();
        return $res;
    }

    public function get_filesContents($id)
    {
         $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id =  $id   order by id desc ");
        $res = $sql->result_array();
        $strcount=0;
        foreach ($res as $key => $value) {
            $str_arr=explode(" ", $value['content']);
            $strcount= $strcount+count($str_arr);
        }
      return $strcount;
    }

    public function get_serch_file($id, $ser) {

        $sql = $this->db->query("SELECT * FROM `tbl_files` where user_id =  $id  and isDeleted = 0 AND (file_name LIKE '%$ser%' or tagName LIKE '%$ser%' or comment LIKE '%$ser%') order by id desc");

        $res = $sql->result_array();

        return $res;
    }

    public function get_library_data($data) {
        $whr = "";
        $id = $data['id'];
        $ser = $data['ser'];
        $file_name = $data['file_name'];
        $tagName = $data['tagName'];
        $comment = $data['comment'];
        $created = $data['created'];

        if ($data['ser'] != "") {
            $whr = "AND (file_name like '%$ser%' OR tagName like '%$ser%' OR comment like '%$ser%') ";
        }
        if ($file_name != "") {
            $whr .= "order by file_name $file_name";
        } else if ($tagName != "") {
            $whr .= "order by tagName $tagName";
        } else if ($comment != "") {
            $whr .= "order by comment $comment";
        } else if ($created != "") {
            $whr .= "order by created $created";
        } else {
            $whr .= "order by id DESC";
        }
        //echo "SELECT * FROM `tbl_files` WHERE user_id = $id AND isDeleted = 0 $whr"; exit;
        $sql = $this->db->query("SELECT * FROM `tbl_files` WHERE user_id = $id AND isDeleted = 0 $whr");
        $res = $sql->result_array();
        return $res;
    }

    public function delete_lib_file($id) {
      
         $sql = $this->db->query("DELETE FROM `tbl_files` WHERE `id` ='".$id."'");  
        return true;
    }

    public function update_lib_file($data) {
        rtrim($data["editval"]);
        if($data["column"] == 'created'){
            $data["editval"] = date('Y-m-d', strtotime($data["editval"]));
        }
        //echo "UPDATE tbl_files set " . $data["column"] . " = '" . $data["editval"] . "' WHERE  id=" . $data["id"];  exit;
        $sql = $this->db->query("UPDATE tbl_files set " . $data["column"] . " = '" . $data["editval"] . "' WHERE  id=" . $data["id"]);
        return true;
    }

}
